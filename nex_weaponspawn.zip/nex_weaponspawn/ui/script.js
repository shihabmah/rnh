const resourceName = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'nex_weaponspawn';

const $ = (selector) => document.querySelector(selector);
const app = $('#app');
const menuTitle = $('#menuTitle');
const adminName = $('#adminName');
const adminMeta = $('#adminMeta');
const gangSearch = $('#gangSearch');
const gangList = $('#gangList');
const refreshBtn = $('#refreshBtn');
const closeBtn = $('#closeBtn');
const selectedItemPreview = $('#selectedItemPreview');
const amountInput = $('#amountInput');
const amountHelp = $('#amountHelp');
const randomSerialBtn = $('#randomSerialBtn');
const customSerialBtn = $('#customSerialBtn');
const customSerialInput = $('#customSerialInput');
const serialHelp = $('#serialHelp');
const prefixInput = $('#prefixInput');
const prefixHelp = $('#prefixHelp');
const savePrefixBtn = $('#savePrefixBtn');
const serialPreview = $('#serialPreview');
const spawnBtn = $('#spawnBtn');
const categoryTabs = $('#categoryTabs');
const itemSearch = $('#itemSearch');
const itemCount = $('#itemCount');
const itemGrid = $('#itemGrid');
const resultOutput = $('#resultOutput');
const copySerialsBtn = $('#copySerialsBtn');
const toast = $('#toast');

const state = {
    title: 'Gang Weapon Armory',
    admin: {},
    gangs: [],
    items: [],
    categories: {},
    selectedGang: 'nogang',
    selectedItem: null,
    activeCategory: 'weapon',
    serialMode: 'random',
    maxSpawnAmount: 50,
    imagePath: 'nui://ox_inventory/web/images',
    serial: {
        randomLength: 15,
        customMaxLength: 20,
        customRecommendedLength: 15,
        serialForCategories: { weapon: true, melee: true, throwable: true, ammo: false }
    }
};

async function post(endpoint, data = {}) {
    const response = await fetch(`https://${resourceName}/${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data)
    });
    return response.json();
}

function showToast(message, type = 'inform') {
    toast.textContent = message;
    toast.className = `toast ${type === 'success' ? 'good' : type === 'error' ? 'bad' : type === 'warning' ? 'warn' : ''}`;
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 3600);
}

function imageUrl(item) {
    const base = (state.imagePath || 'nui://ox_inventory/web/images').replace(/\/$/, '');
    let image = item?.image || `${item?.name || 'unknown'}.png`;
    if (!image.includes('.')) image = `${image}.png`;
    return `${base}/${image}`;
}

function categoryLabel(category) {
    return state.categories?.[category]?.label || category;
}

function selectedGangObject() {
    if (state.selectedGang === 'nogang') return null;
    return state.gangs.find((gang) => gang.name === state.selectedGang) || null;
}

function serialAppliesToSelectedItem() {
    if (!state.selectedItem) return false;
    return Boolean(state.serial?.serialForCategories?.[state.selectedItem.category]);
}

function updateFromPayload(payload) {
    state.title = payload.title || state.title;
    state.admin = payload.admin || {};
    state.gangs = Array.isArray(payload.gangs) ? payload.gangs : [];
    state.items = Array.isArray(payload.items) ? payload.items : [];
    state.categories = payload.categories || {};
    state.maxSpawnAmount = Number(payload.maxSpawnAmount || 50);
    state.imagePath = payload.imagePath || state.imagePath;
    state.serial = payload.serial || state.serial;

    if (!state.gangs.some((gang) => gang.name === state.selectedGang)) {
        state.selectedGang = 'nogang';
    }

    if (!state.items.some((item) => state.selectedItem && item.name === state.selectedItem.name)) {
        state.selectedItem = null;
    }

    const availableCategories = [...new Set(state.items.map((item) => item.category))];
    if (!availableCategories.includes(state.activeCategory)) {
        state.activeCategory = availableCategories[0] || 'weapon';
    }

    menuTitle.textContent = state.title;
    adminName.textContent = state.admin.characterName || state.admin.name || 'Admin';
    adminMeta.textContent = `ID: ${state.admin.source ?? '--'} • Discord: ${state.admin.discord && state.admin.discord !== 'not linked' ? state.admin.discord : 'not linked'}`;
    amountInput.max = String(state.maxSpawnAmount);
    amountHelp.textContent = `Max ${state.maxSpawnAmount} per spawn`;

    renderAll();
}

function renderAll() {
    renderGangs();
    renderCategories();
    renderItems();
    renderSelectedItem();
    renderPrefixEditor();
    renderSerialControls();
    renderSerialPreview();
}

function renderGangs() {
    const search = gangSearch.value.trim().toLowerCase();
    const rows = [
        {
            name: 'nogang',
            label: 'No Gang',
            prefix: 'RND',
            gangCode: '---',
            grades: 0
        },
        ...state.gangs
    ].filter((gang) => !search || gang.label.toLowerCase().includes(search) || gang.name.toLowerCase().includes(search) || gang.prefix.toLowerCase().includes(search));

    gangList.innerHTML = '';

    for (const gang of rows) {
        const button = document.createElement('button');
        button.className = `gang-row ${state.selectedGang === gang.name ? 'active' : ''}`;
        button.innerHTML = `
            <div class="gang-title">
                <span>${gang.label}</span>
                <span class="prefix-pill">${gang.prefix}</span>
            </div>
            <div class="gang-meta">${gang.name === 'nogang' ? 'Pure random serials' : `ID ${gang.gangCode} • ${gang.grades || 0} grades`}</div>
        `;
        button.addEventListener('click', () => {
            state.selectedGang = gang.name;
            renderGangs();
            renderPrefixEditor();
            renderSerialPreview();
        });
        gangList.appendChild(button);
    }

    if (!rows.length) {
        gangList.innerHTML = '<div class="empty-state">No gangs matched.</div>';
    }
}

function renderCategories() {
    const counts = state.items.reduce((acc, item) => {
        acc[item.category] = (acc[item.category] || 0) + 1;
        return acc;
    }, {});

    const categoryOrder = ['weapon', 'ammo', 'throwable', 'melee'];
    const categories = categoryOrder.filter((category) => counts[category]);

    categoryTabs.innerHTML = '';
    for (const category of categories) {
        const button = document.createElement('button');
        button.className = `tab ${state.activeCategory === category ? 'active' : ''}`;
        button.textContent = `${categoryLabel(category)} (${counts[category]})`;
        button.addEventListener('click', () => {
            state.activeCategory = category;
            renderCategories();
            renderItems();
            renderSerialControls();
            renderSerialPreview();
        });
        categoryTabs.appendChild(button);
    }
}

function filteredItems() {
    const search = itemSearch.value.trim().toLowerCase();
    return state.items.filter((item) => {
        const matchesCategory = item.category === state.activeCategory;
        const matchesSearch = !search || item.name.toLowerCase().includes(search) || item.label.toLowerCase().includes(search);
        return matchesCategory && matchesSearch;
    });
}

function renderItems() {
    const items = filteredItems();
    itemCount.textContent = `${items.length} item${items.length === 1 ? '' : 's'}`;
    itemGrid.innerHTML = '';

    for (const item of items) {
        const card = document.createElement('button');
        card.className = `item-card ${state.selectedItem?.name === item.name ? 'active' : ''}`;
        card.innerHTML = `
            <div class="item-image-wrap">
                <img src="${imageUrl(item)}" alt="${item.label}" loading="lazy" />
            </div>
            <span class="category-chip">${categoryLabel(item.category)}</span>
            <strong>${item.label}</strong>
            <small>${item.name}</small>
        `;
        card.querySelector('img').addEventListener('error', (event) => {
            event.currentTarget.style.display = 'none';
            event.currentTarget.parentElement.textContent = item.name.slice(0, 3).toUpperCase();
        });
        card.addEventListener('click', () => {
            state.selectedItem = item;
            renderItems();
            renderSelectedItem();
            renderSerialControls();
            renderSerialPreview();
        });
        itemGrid.appendChild(card);
    }

    if (!items.length) {
        itemGrid.innerHTML = '<div class="empty-state">No ox_inventory items in this category.</div>';
    }
}

function renderSelectedItem() {
    if (!state.selectedItem) {
        selectedItemPreview.className = 'selected-empty';
        selectedItemPreview.textContent = 'Choose an item from the grid.';
        return;
    }

    selectedItemPreview.className = 'selected-filled';
    selectedItemPreview.innerHTML = `
        <img src="${imageUrl(state.selectedItem)}" alt="${state.selectedItem.label}" />
        <div>
            <strong>${state.selectedItem.label}</strong>
            <small>${state.selectedItem.name} • ${categoryLabel(state.selectedItem.category)}</small>
        </div>
    `;
    selectedItemPreview.querySelector('img').addEventListener('error', (event) => {
        event.currentTarget.style.display = 'none';
    });
}

function renderPrefixEditor() {
    const gang = selectedGangObject();
    const disabled = !gang;

    prefixInput.disabled = disabled;
    savePrefixBtn.disabled = disabled;
    prefixInput.value = gang ? gang.prefix : '';
    prefixHelp.textContent = gang
        ? `Editing ${gang.label}. Serial prefix + gang ID: ${gang.prefix}${gang.gangCode}`
        : 'Select a gang to edit its 3-character prefix.';
}

function renderSerialControls() {
    const applies = serialAppliesToSelectedItem();

    randomSerialBtn.classList.toggle('active', state.serialMode === 'random');
    customSerialBtn.classList.toggle('active', state.serialMode === 'custom');
    customSerialInput.classList.toggle('hidden', state.serialMode !== 'custom');

    randomSerialBtn.disabled = !applies;
    customSerialBtn.disabled = !applies;
    customSerialInput.disabled = !applies || state.serialMode !== 'custom';

    if (!state.selectedItem) {
        serialHelp.textContent = 'Select an item to preview serial metadata.';
    } else if (!applies) {
        serialHelp.textContent = `${categoryLabel(state.selectedItem.category)} does not receive weapon serial metadata by default.`;
    } else if (state.serialMode === 'custom') {
        serialHelp.textContent = `Custom serial: 1-${state.serial.customMaxLength} chars. ${state.serial.customRecommendedLength} recommended.`;
    } else {
        serialHelp.textContent = `Random serial: ${state.serial.randomLength} chars. Gang format uses prefix + 3-digit gang ID.`;
    }
}

function renderSerialPreview() {
    if (!state.selectedItem) {
        serialPreview.textContent = 'No item selected';
        return;
    }

    if (!serialAppliesToSelectedItem()) {
        serialPreview.textContent = 'No serial for this category';
        return;
    }

    if (state.serialMode === 'custom') {
        serialPreview.textContent = customSerialInput.value.trim().toUpperCase() || 'CUSTOM-SERIAL';
        return;
    }

    const gang = selectedGangObject();
    if (gang) {
        const suffixLength = Math.max((state.serial.randomLength || 15) - 6, 1);
        serialPreview.textContent = `${gang.prefix}${gang.gangCode}${'•'.repeat(suffixLength)}`;
    } else {
        serialPreview.textContent = `${state.serial.randomLength || 15} random characters`;
    }
}

function setSerialMode(mode) {
    state.serialMode = mode;
    renderSerialControls();
    renderSerialPreview();
}

function validateSpawn() {
    if (!state.selectedItem) return 'Select an item first.';

    const amount = Number(amountInput.value);
    if (!Number.isInteger(amount) || amount < 1 || amount > state.maxSpawnAmount) {
        return `Amount must be between 1 and ${state.maxSpawnAmount}.`;
    }

    if (serialAppliesToSelectedItem() && state.serialMode === 'custom') {
        const custom = customSerialInput.value.trim();
        if (!custom || custom.length > state.serial.customMaxLength || !/^[A-Za-z0-9_-]+$/.test(custom)) {
            return `Custom serial must be 1-${state.serial.customMaxLength} characters and only A-Z, 0-9, - or _.`;
        }
    }

    return null;
}

async function spawnSelected() {
    const error = validateSpawn();
    if (error) {
        showToast(error, 'error');
        await post('notify', { message: error, type: 'error' });
        return;
    }

    spawnBtn.disabled = true;
    spawnBtn.textContent = 'Spawning...';

    try {
        const result = await post('spawn', {
            itemName: state.selectedItem.name,
            amount: Number(amountInput.value),
            gangName: state.selectedGang,
            serialMode: state.serialMode,
            customSerial: customSerialInput.value.trim()
        });

        if (!result.ok) {
            showToast(result.message || 'Spawn failed.', 'error');
            return;
        }

        const serials = Array.isArray(result.serials) && result.serials.length ? result.serials.join('\n') : 'No serial metadata for this category.';
        resultOutput.value = `${result.message}\n\nItem: ${result.item?.label || state.selectedItem.label} (${result.item?.name || state.selectedItem.name})\nGang: ${result.gang?.label || 'No Gang'}\nSerials:\n${serials}`;
        showToast(result.message, 'success');
    } finally {
        spawnBtn.disabled = false;
        spawnBtn.textContent = 'Spawn item(s)';
    }
}

async function savePrefix() {
    const gang = selectedGangObject();
    if (!gang) {
        showToast('Select a gang first.', 'error');
        return;
    }

    const prefix = prefixInput.value.trim().toUpperCase();
    if (!/^[A-Z0-9]{3}$/.test(prefix)) {
        showToast('Prefix must be exactly 3 letters/numbers.', 'error');
        return;
    }

    savePrefixBtn.disabled = true;
    try {
        const result = await post('savePrefix', { gangName: gang.name, prefix });
        if (!result.ok) {
            showToast(result.message || 'Could not save prefix.', 'error');
            return;
        }
        if (Array.isArray(result.gangs)) state.gangs = result.gangs;
        showToast(result.message, 'success');
        renderAll();
    } finally {
        savePrefixBtn.disabled = false;
    }
}

async function refreshData() {
    refreshBtn.disabled = true;
    try {
        const result = await post('refresh');
        if (!result.ok) {
            showToast(result.message || 'Refresh failed.', 'error');
            return;
        }
        updateFromPayload(result);
        showToast('Live data refreshed.', 'success');
    } finally {
        refreshBtn.disabled = false;
    }
}

window.addEventListener('message', (event) => {
    const data = event.data || {};
    if (data.action === 'open') {
        updateFromPayload(data.payload || {});
        app.classList.remove('hidden');
        setTimeout(() => itemSearch.focus(), 40);
    }

    if (data.action === 'close') {
        app.classList.add('hidden');
    }
});

gangSearch.addEventListener('input', renderGangs);
itemSearch.addEventListener('input', renderItems);
amountInput.addEventListener('input', renderSerialPreview);
prefixInput.addEventListener('input', () => {
    prefixInput.value = prefixInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3);
    renderSerialPreview();
});
customSerialInput.addEventListener('input', () => {
    customSerialInput.value = customSerialInput.value.toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, state.serial.customMaxLength || 20);
    renderSerialPreview();
});
randomSerialBtn.addEventListener('click', () => setSerialMode('random'));
customSerialBtn.addEventListener('click', () => setSerialMode('custom'));
savePrefixBtn.addEventListener('click', savePrefix);
spawnBtn.addEventListener('click', spawnSelected);
refreshBtn.addEventListener('click', refreshData);
closeBtn.addEventListener('click', () => post('close'));
copySerialsBtn.addEventListener('click', async () => {
    const value = resultOutput.value;
    if (!value) return;
    try {
        await navigator.clipboard.writeText(value);
        showToast('Copied last result.', 'success');
    } catch (_) {
        showToast('Clipboard is not available in this NUI.', 'warning');
    }
});

document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        post('close');
    }
});
