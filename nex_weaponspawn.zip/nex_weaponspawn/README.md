# nex_weaponspawn v2.0.0

Advanced Qbox/QBX admin armory for ox_inventory.

## Features

- Admin-only NUI opened with `/mafia`, `/weaponspawn`, `/wepspawn`, or `/armoryadmin`.
- Live gang list loaded server-side from `qbx_core/shared/gangs.lua`.
- Gang sidebar with editable 3-character prefixes stored in SQL.
- ox_inventory item catalogue with images from `nui://ox_inventory/web/images`.
- Categories: Weapons, Ammo, Throwables, Melee.
- Max 50 items per spawn.
- Random serials: 15 characters total.
- Gang random serial format: `PPP###XXXXXXXXX`
  - `PPP` = gang prefix
  - `###` = stable 3-digit gang code
  - `XXXXXXXXX` = random A-Z/0-9 suffix
- Custom serial mode: 1-20 characters, 15 recommended.
- Discord webhook logging with admin name, ID, Discord, item/model, amount, gang, and serials.
- Optional SQL spawn log table.

## Dependencies

Start order should be:

```cfg
ensure oxmysql
ensure ox_lib
ensure qbx_core
ensure ox_inventory
ensure nex_weaponspawn
```

## Permissions

ACE permission is recommended.

```cfg
add_ace group.admin nex_weaponspawn.admin allow
```

Then make sure your admins are in `group.admin`, or add the ACE directly to the relevant principal.

If you really need old Qbox permissions, set this in `config.lua`:

```lua
Config.AllowQboxDeprecatedPermissions = true
Config.QboxPermission = 'admin'
```

## SQL

The resource can auto-create the SQL tables when `Config.Database.AutoCreate = true`.

You can also import `install.sql` manually.

## Discord logs

Set your webhook in `config.lua`:

```lua
Config.Discord.Webhook = 'https://discord.com/api/webhooks/...'
```

## Notes

- Ammo does not receive serial metadata by default. Change `Config.Serial.SerialForCategories.ammo = true` if you want serials on ammo too.
- Custom weapon items are included automatically when their ox_inventory item name starts with `weapon_`.
- Add extra melee or throwable custom weapon item names to `Config.MeleeWeapons` or `Config.ThrowableWeapons`.
- Block dangerous or unwanted items with `Config.BlockedItems`.
