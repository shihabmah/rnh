fx_version 'cerulean'
game 'gta5'
lua54 'yes'
use_experimental_fxv2_oal 'yes'

name 'nex_weaponspawn'
description 'Advanced Qbox/QBX admin armory with gang prefixes, serials, ox_inventory images, SQL persistence, and Discord logs.'
author 'Mohaim Shihab / rebuilt by ChatGPT'
version '2.0.0'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/script.js'
}

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/server.lua'
}

dependencies {
    'ox_lib',
    'ox_inventory',
    'qbx_core',
    'oxmysql'
}
