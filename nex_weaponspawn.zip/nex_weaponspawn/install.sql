CREATE TABLE IF NOT EXISTS `nex_weaponspawn_prefixes` (
    `gang_name` varchar(64) NOT NULL,
    `prefix` varchar(3) NOT NULL,
    `updated_by` varchar(128) DEFAULT NULL,
    `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
    PRIMARY KEY (`gang_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nex_weaponspawn_logs` (
    `id` int unsigned NOT NULL AUTO_INCREMENT,
    `admin_source` int DEFAULT NULL,
    `admin_name` varchar(128) DEFAULT NULL,
    `admin_identifier` varchar(128) DEFAULT NULL,
    `admin_discord` varchar(64) DEFAULT NULL,
    `item_name` varchar(96) NOT NULL,
    `item_label` varchar(128) DEFAULT NULL,
    `category` varchar(32) DEFAULT NULL,
    `amount` int NOT NULL DEFAULT 1,
    `gang_name` varchar(64) DEFAULT NULL,
    `gang_label` varchar(128) DEFAULT NULL,
    `serial_mode` varchar(20) DEFAULT NULL,
    `serials` longtext DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`id`),
    KEY `idx_created_at` (`created_at`),
    KEY `idx_admin_identifier` (`admin_identifier`),
    KEY `idx_item_name` (`item_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
