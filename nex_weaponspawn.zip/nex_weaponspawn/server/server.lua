local RESOURCE = GetCurrentResourceName()
local GangCache = {}
local GangByName = {}
local PrefixCache = {}
local ItemCache = {}
local ItemByName = {}
local lastItemRefresh = 0

math.randomseed(os.time() + (GetGameTimer and GetGameTimer() or 0))

local function trim(value)
    return tostring(value or ''):gsub('^%s+', ''):gsub('%s+$', '')
end

local function lower(value)
    return string.lower(tostring(value or ''))
end

local function notify(source, description, notifyType)
    notifyType = notifyType or 'inform'

    if source == 0 then
        print(('[%s] %s'):format(RESOURCE, description))
        return
    end

    local ok = pcall(function()
        exports[Config.QboxResource]:Notify(source, description, notifyType, 5000)
    end)

    if not ok then
        TriggerClientEvent('ox_lib:notify', source, {
            title = Config.MenuTitle,
            description = description,
            type = notifyType
        })
    end
end

local function hexToDecimal(hex)
    hex = tostring(hex or '#14213a'):gsub('#', '')
    return tonumber(hex, 16) or 1319226
end

local function getIdentifiers(source)
    local identifiers = {
        license = 'unknown',
        discord = 'not linked',
        steam = 'not linked',
        fivem = 'not linked'
    }

    if source == 0 then
        identifiers.license = 'console'
        return identifiers
    end

    for i = 0, GetNumPlayerIdentifiers(source) - 1 do
        local identifier = GetPlayerIdentifier(source, i)
        if identifier then
            local prefix, value = identifier:match('([^:]+):(.+)')
            if prefix and value then
                identifiers[prefix] = value
            end
        end
    end

    return identifiers
end

local function getPlayer(source)
    local ok, player = pcall(function()
        return exports[Config.QboxResource]:GetPlayer(source)
    end)

    if ok then return player end
end

local function getAdminInfo(source)
    local identifiers = getIdentifiers(source)
    local player = source ~= 0 and getPlayer(source) or nil
    local playerData = player and player.PlayerData or {}
    local charinfo = playerData.charinfo or {}
    local charName = trim(('%s %s'):format(charinfo.firstname or '', charinfo.lastname or ''))

    if charName == '' then
        charName = source == 0 and 'Console' or GetPlayerName(source) or ('ID %s'):format(source)
    end

    return {
        source = source,
        name = source == 0 and 'Console' or (GetPlayerName(source) or charName),
        characterName = charName,
        citizenid = playerData.citizenid or 'unknown',
        license = identifiers.license,
        discord = identifiers.discord,
        steam = identifiers.steam,
        fivem = identifiers.fivem
    }
end

local function isAdmin(source)
    if source == 0 then return true end

    if Config.AdminAce and Config.AdminAce ~= '' and IsPlayerAceAllowed(source, Config.AdminAce) then
        return true
    end

    if IsPlayerAceAllowed(source, ('command.%s'):format(Config.Command)) then
        return true
    end

    if Config.AllowQboxDeprecatedPermissions then
        local ok, allowed = pcall(function()
            return exports[Config.QboxResource]:HasPermission(source, Config.QboxPermission)
        end)

        if ok and allowed then return true end
    end

    return false
end

local function ensureTables()
    if not Config.Database.Enabled or not Config.Database.AutoCreate then return end

    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `nex_weaponspawn_prefixes` (
            `gang_name` varchar(64) NOT NULL,
            `prefix` varchar(3) NOT NULL,
            `updated_by` varchar(128) DEFAULT NULL,
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`gang_name`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ]])

    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `nex_weaponspawn_logs` (
            `id` int unsigned NOT NULL AUTO_INCREMENT,
            `admin_source` int DEFAULT NULL,
            `admin_name` varchar(128) DEFAULT NULL,
            `admin_identifier` varchar(128) DEFAULT NULL,
            `admin_discord` varchar(64) DEFAULT NULL,
            `item_name` varchar(96) NOT NULL,
            `item_label` varchar(128) DEFAULT NULL,
            `category` varchar(32) DEFAULT NULL,
            `amount` int NOT NULL DEFAULT 1,
            `gang_name` varchar(64) DEFAULT NULL,
            `gang_label` varchar(128) DEFAULT NULL,
            `serial_mode` varchar(20) DEFAULT NULL,
            `serials` longtext DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `idx_created_at` (`created_at`),
            KEY `idx_admin_identifier` (`admin_identifier`),
            KEY `idx_item_name` (`item_name`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ]])
end

local function loadPrefixCache()
    PrefixCache = {}
    if not Config.Database.Enabled then return end

    local rows = MySQL.query.await('SELECT gang_name, prefix FROM nex_weaponspawn_prefixes') or {}
    for _, row in ipairs(rows) do
        if row.gang_name and row.prefix then
            PrefixCache[lower(row.gang_name)] = string.upper(row.prefix)
        end
    end
end

local function sanitizePrefix(prefix)
    prefix = string.upper(trim(prefix)):gsub('[^A-Z0-9]', '')
    if #prefix ~= Config.Serial.PrefixLength then return nil end
    return prefix
end

local function makeDefaultPrefix(gangName, gangLabel)
    local clean = string.upper(tostring(gangLabel or gangName or 'GNG')):gsub('[^A-Z0-9]', '')
    if #clean < Config.Serial.PrefixLength then
        clean = (clean .. tostring(gangName or 'GNG'):upper():gsub('[^A-Z0-9]', '') .. 'XXX')
    end
    return clean:sub(1, Config.Serial.PrefixLength)
end

local function gangCode(gangName)
    local hash = 0
    local value = tostring(gangName or 'nogang')

    for i = 1, #value do
        hash = (hash * 31 + value:byte(i)) % 1000
    end

    return ('%03d'):format(hash)
end

local function loadGangTableFromResource(resourceName)
    if GetResourceState(resourceName) == 'missing' then return nil end

    local raw = LoadResourceFile(resourceName, Config.QboxGangFile)
    if not raw then return nil end

    local env = { QBShared = {} }
    local chunk, err = load(raw, ('@%s/%s'):format(resourceName, Config.QboxGangFile), 't', env)
    if not chunk then
        print(('^1[%s]^7 Could not parse %s gangs.lua: %s'):format(RESOURCE, resourceName, err or 'unknown error'))
        return nil
    end

    local ok, result = pcall(chunk)
    if not ok then
        print(('^1[%s]^7 Could not run %s gangs.lua: %s'):format(RESOURCE, resourceName, result or 'unknown error'))
        return nil
    end

    if type(result) == 'table' then return result end
    if type(env.QBShared) == 'table' and type(env.QBShared.Gangs) == 'table' then return env.QBShared.Gangs end
end

local function refreshGangs()
    local sourceResource = Config.QboxResource
    local gangs = loadGangTableFromResource(sourceResource)

    if not gangs then
        gangs = loadGangTableFromResource('qb-core')
        sourceResource = 'qb-core'
    end

    GangCache = {}
    GangByName = {}

    if type(gangs) ~= 'table' then
        print(('^3[%s]^7 No gang table found from qbx_core/shared/gangs.lua. The gang sidebar will be empty.'):format(RESOURCE))
        return GangCache
    end

    for gangName, data in pairs(gangs) do
        local key = lower(gangName)
        if not Config.ExcludeGangs[key] then
            local label = type(data) == 'table' and data.label or tostring(gangName)
            local prefix = PrefixCache[key] or makeDefaultPrefix(key, label)
            local grades = 0

            if type(data) == 'table' and type(data.grades) == 'table' then
                for _ in pairs(data.grades) do grades = grades + 1 end
            end

            local gang = {
                name = key,
                label = label or key,
                prefix = prefix,
                defaultPrefix = makeDefaultPrefix(key, label),
                gangCode = gangCode(key),
                grades = grades,
                source = sourceResource
            }

            GangCache[#GangCache + 1] = gang
            GangByName[key] = gang
        end
    end

    table.sort(GangCache, function(a, b)
        return a.label:lower() < b.label:lower()
    end)

    return GangCache
end

local function classifyItem(itemName)
    local name = lower(itemName)

    if Config.BlockedItems[name] then return nil end
    if Config.MeleeWeapons[name] then return 'melee' end
    if Config.ThrowableWeapons[name] then return 'throwable' end
    if name:match('^ammo%-') or name:match('^ammo_') or name == 'ammo' then return 'ammo' end
    if name:match('^weapon_') then return 'weapon' end

    return nil
end

local function normaliseImage(itemName, itemData)
    local image = type(itemData) == 'table' and itemData.image or nil
    image = image and tostring(image) or (itemName .. '.png')

    if not image:find('%.') then
        image = image .. '.png'
    end

    return image
end

local function addCatalogItem(list, map, itemName, data, forcedCategory)
    itemName = lower(itemName)
    if map[itemName] or Config.BlockedItems[itemName] then return end

    local category = forcedCategory or classifyItem(itemName)
    if not category or not Config.ItemCategories[category] then return end

    local label = type(data) == 'table' and (data.label or data.name) or nil
    local item = {
        name = itemName,
        label = label or itemName,
        category = category,
        description = type(data) == 'table' and data.description or nil,
        weight = type(data) == 'table' and data.weight or nil,
        stack = type(data) == 'table' and data.stack or nil,
        image = normaliseImage(itemName, data or {})
    }

    list[#list + 1] = item
    map[itemName] = item
end

local function refreshItems(force)
    local now = os.time()
    if not force and (now - lastItemRefresh) < 5 and #ItemCache > 0 then
        return ItemCache, ItemByName
    end

    local list, map = {}, {}
    local ok, items = pcall(function()
        return exports[Config.OxInventoryResource]:Items()
    end)

    if ok and type(items) == 'table' then
        for itemName, data in pairs(items) do
            addCatalogItem(list, map, itemName, data)
        end
    end

    if #list == 0 then
        for _, item in ipairs(Config.FallbackItems) do
            addCatalogItem(list, map, item.name, item, item.category)
        end
    end

    table.sort(list, function(a, b)
        if a.category == b.category then
            return a.label:lower() < b.label:lower()
        end
        return a.category < b.category
    end)

    ItemCache = list
    ItemByName = map
    lastItemRefresh = now

    return ItemCache, ItemByName
end

local function randomString(length)
    local chars = Config.Serial.Charset
    local output = {}

    for i = 1, length do
        local index = math.random(1, #chars)
        output[i] = chars:sub(index, index)
    end

    return table.concat(output)
end

local function generateRandomSerial(gang)
    local totalLength = Config.Serial.RandomLength

    if gang then
        local used = Config.Serial.PrefixLength + Config.Serial.GangCodeLength
        local suffixLength = math.max(totalLength - used, 1)
        return (gang.prefix .. gang.gangCode .. randomString(suffixLength)):sub(1, totalLength)
    end

    return randomString(totalLength)
end

local function sanitizeCustomSerial(serial)
    serial = trim(serial)
    if #serial < 1 or #serial > Config.Serial.CustomMaxLength then return nil end
    if not serial:match(Config.Serial.CustomPattern) then return nil end
    return string.upper(serial)
end

local function makeMetadata(serial, gang, admin, category)
    local metadata = {
        adminSpawned = true,
        spawnedCategory = category,
        generatedBy = admin.name,
        generatedAt = os.date('!%Y-%m-%dT%H:%M:%SZ')
    }

    if gang then
        metadata.gang = gang.name
        metadata.gangLabel = gang.label
        metadata.gangPrefix = gang.prefix
        metadata.registered = gang.label
    end

    if serial then
        metadata.serial = serial
    end

    return metadata
end

local function sendDiscordLog(kind, payload)
    local webhook = Config.Discord.Webhook
    if not webhook or webhook == '' then return end

    local admin = payload.admin or {}
    local serialText = payload.serials and table.concat(payload.serials, ', ') or 'N/A'
    if serialText == '' then serialText = 'N/A' end

    local fields = {
        { name = 'Admin', value = ('%s (ID: %s)'):format(admin.name or 'Unknown', admin.source or 'unknown'), inline = true },
        { name = 'Character', value = admin.characterName or 'Unknown', inline = true },
        { name = 'Discord', value = admin.discord and admin.discord ~= 'not linked' and ('<@%s>'):format(admin.discord) or 'Not linked', inline = true },
        { name = 'License', value = ('`%s`'):format(admin.license or 'unknown'), inline = false }
    }

    if kind == 'spawn' then
        fields[#fields + 1] = { name = 'Item / Model', value = ('%s (`%s`)'):format(payload.itemLabel or 'Unknown', payload.itemName or 'unknown'), inline = true }
        fields[#fields + 1] = { name = 'Category / Amount', value = ('%s x%s'):format(payload.category or 'unknown', payload.amount or 0), inline = true }
        fields[#fields + 1] = { name = 'Gang', value = payload.gangLabel and ('%s (`%s`)'):format(payload.gangLabel, payload.gangName) or 'No Gang', inline = true }
        fields[#fields + 1] = { name = 'Serial Mode', value = payload.serialMode or 'random', inline = true }
        fields[#fields + 1] = { name = 'Serials', value = ('```%s```'):format(serialText:sub(1, 980)), inline = false }
    elseif kind == 'prefix' then
        fields[#fields + 1] = { name = 'Gang', value = ('%s (`%s`)'):format(payload.gangLabel or payload.gangName, payload.gangName), inline = true }
        fields[#fields + 1] = { name = 'New Prefix', value = ('`%s`'):format(payload.prefix), inline = true }
    end

    local body = {
        username = Config.Discord.Username or 'NEX Weapon Spawn',
        avatar_url = Config.Discord.Avatar ~= '' and Config.Discord.Avatar or nil,
        embeds = {{
            title = kind == 'prefix' and 'Gang Prefix Updated' or 'Admin Item Spawned',
            color = hexToDecimal(Config.Discord.Color or Config.AccentColor),
            fields = fields,
            footer = { text = RESOURCE },
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ')
        }}
    }

    PerformHttpRequest(webhook, function(status)
        if status < 200 or status >= 300 then
            print(('^3[%s]^7 Discord webhook returned HTTP %s'):format(RESOURCE, status))
        end
    end, 'POST', json.encode(body), { ['Content-Type'] = 'application/json' })
end

local function saveSpawnLog(payload)
    if not Config.Database.Enabled or not Config.Database.SaveSpawnLogs then return end

    local admin = payload.admin or {}
    MySQL.insert.await([[ 
        INSERT INTO nex_weaponspawn_logs
        (admin_source, admin_name, admin_identifier, admin_discord, item_name, item_label, category, amount, gang_name, gang_label, serial_mode, serials)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]], {
        admin.source,
        admin.name,
        admin.license,
        admin.discord,
        payload.itemName,
        payload.itemLabel,
        payload.category,
        payload.amount,
        payload.gangName,
        payload.gangLabel,
        payload.serialMode,
        json.encode(payload.serials or {})
    })
end

local function bootstrap(source)
    loadPrefixCache()
    refreshGangs()
    local items = refreshItems(true)
    local admin = getAdminInfo(source)

    return {
        ok = true,
        title = Config.MenuTitle,
        admin = admin,
        gangs = GangCache,
        items = items,
        categories = Config.ItemCategories,
        maxSpawnAmount = Config.MaxSpawnAmount,
        defaultAmount = Config.DefaultAmount,
        accentColor = Config.AccentColor,
        imagePath = Config.InventoryImagePath,
        serial = {
            randomLength = Config.Serial.RandomLength,
            prefixLength = Config.Serial.PrefixLength,
            customMaxLength = Config.Serial.CustomMaxLength,
            customRecommendedLength = Config.Serial.CustomRecommendedLength,
            serialForCategories = Config.Serial.SerialForCategories
        }
    }
end

lib.callback.register('nex_weaponspawn:server:getBootstrap', function(source)
    if not isAdmin(source) then
        notify(source, 'Access denied. You do not have weapon spawn permission.', 'error')
        return { ok = false, message = 'Access denied.' }
    end

    return bootstrap(source)
end)

lib.callback.register('nex_weaponspawn:server:savePrefix', function(source, data)
    if not isAdmin(source) then
        return { ok = false, message = 'Access denied.' }
    end

    data = type(data) == 'table' and data or {}
    local gangName = lower(data.gangName)
    local prefix = sanitizePrefix(data.prefix)

    loadPrefixCache()
    refreshGangs()

    local gang = GangByName[gangName]
    if not gang then
        return { ok = false, message = 'Invalid gang selected.' }
    end

    if not prefix then
        return { ok = false, message = ('Prefix must be exactly %s letters/numbers.'):format(Config.Serial.PrefixLength) }
    end

    local admin = getAdminInfo(source)
    PrefixCache[gangName] = prefix

    if Config.Database.Enabled then
        MySQL.query.await([[ 
            INSERT INTO nex_weaponspawn_prefixes (gang_name, prefix, updated_by)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE prefix = VALUES(prefix), updated_by = VALUES(updated_by)
        ]], { gangName, prefix, admin.license })
    end

    refreshGangs()
    gang = GangByName[gangName]

    sendDiscordLog('prefix', {
        admin = admin,
        gangName = gangName,
        gangLabel = gang.label,
        prefix = prefix
    })

    return {
        ok = true,
        message = ('Saved %s prefix as %s.'):format(gang.label, prefix),
        gangs = GangCache
    }
end)

lib.callback.register('nex_weaponspawn:server:spawnItem', function(source, data)
    if not isAdmin(source) then
        return { ok = false, message = 'Access denied.' }
    end

    data = type(data) == 'table' and data or {}
    local itemName = lower(data.itemName)
    local amount = tonumber(data.amount)
    local gangName = lower(data.gangName or 'nogang')
    local serialMode = lower(data.serialMode or 'random')

    if not amount or amount < 1 or amount > Config.MaxSpawnAmount then
        return { ok = false, message = ('Amount must be between 1 and %s.'):format(Config.MaxSpawnAmount) }
    end

    loadPrefixCache()
    refreshGangs()
    refreshItems(true)

    local item = ItemByName[itemName]
    if not item then
        return { ok = false, message = 'Invalid item selected or item is blocked.' }
    end

    local gang = nil
    if gangName ~= 'nogang' and gangName ~= '' then
        gang = GangByName[gangName]
        if not gang then
            return { ok = false, message = 'Invalid gang selected.' }
        end
    end

    local serialEnabled = Config.Serial.SerialForCategories[item.category] == true
    local customSerial = nil

    if serialEnabled and serialMode == 'custom' then
        customSerial = sanitizeCustomSerial(data.customSerial)
        if not customSerial then
            return { ok = false, message = ('Custom serial must be 1-%s characters and only A-Z, 0-9, - or _.'):format(Config.Serial.CustomMaxLength) }
        end
    else
        serialMode = serialEnabled and 'random' or 'none'
    end

    local canCarry = true
    local okCarry, carryResult = pcall(function()
        return exports[Config.OxInventoryResource]:CanCarryItem(source, itemName, amount)
    end)

    if okCarry then canCarry = carryResult end
    if not canCarry then
        return { ok = false, message = 'Inventory does not have enough space/weight.' }
    end

    local admin = getAdminInfo(source)
    local serials = {}
    local successCount = 0
    local lastResponse = nil

    if serialEnabled then
        local generatedThisSpawn = {}

        for i = 1, amount do
            local serial = customSerial
            if serialMode == 'random' then
                repeat
                    serial = generateRandomSerial(gang)
                until not generatedThisSpawn[serial]
                generatedThisSpawn[serial] = true
            end

            local metadata = makeMetadata(serial, gang, admin, item.category)
            local success, response = exports[Config.OxInventoryResource]:AddItem(source, itemName, 1, metadata)
            lastResponse = response

            if not success then break end
            successCount = successCount + 1
            serials[#serials + 1] = serial
        end
    else
        local success, response = exports[Config.OxInventoryResource]:AddItem(source, itemName, amount)
        lastResponse = response
        if success then successCount = amount end
    end

    if successCount < 1 then
        return { ok = false, message = ('Failed to spawn item: %s'):format(lastResponse or 'inventory_full') }
    end

    local payload = {
        admin = admin,
        itemName = item.name,
        itemLabel = item.label,
        category = item.category,
        amount = successCount,
        gangName = gang and gang.name or nil,
        gangLabel = gang and gang.label or nil,
        serialMode = serialMode,
        serials = serials
    }

    saveSpawnLog(payload)
    sendDiscordLog('spawn', payload)

    local partial = successCount < amount and (' Spawned %s/%s; inventory may be full.'):format(successCount, amount) or ''
    notify(source, ('Spawned %sx %s.%s'):format(successCount, item.label, partial), successCount == amount and 'success' or 'warning')

    return {
        ok = true,
        message = ('Spawned %sx %s.%s'):format(successCount, item.label, partial),
        amount = successCount,
        item = item,
        gang = gang,
        serialMode = serialMode,
        serials = serials
    }
end)

CreateThread(function()
    Wait(1000)
    ensureTables()
    loadPrefixCache()
    refreshGangs()
    refreshItems(true)
    print(('^2[%s]^7 Loaded %s gangs and %s spawnable items.'):format(RESOURCE, #GangCache, #ItemCache))
end)
