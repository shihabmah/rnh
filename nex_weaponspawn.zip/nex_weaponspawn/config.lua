Config = {}

-- Command used to open the admin armory. Aliases are optional.
Config.Command = 'mafia'
Config.CommandAliases = { 'weaponspawn', 'wepspawn', 'armoryadmin' }
Config.Keybind = '' -- Example: 'F7'. Leave empty to disable key mapping.

-- ACE is the recommended Qbox permission method.
-- Add this to server.cfg: add_ace group.admin nex_weaponspawn.admin allow
Config.AdminAce = 'nex_weaponspawn.admin'

-- Deprecated fallback only. Qbox docs recommend ACE permissions instead.
Config.AllowQboxDeprecatedPermissions = false
Config.QboxPermission = 'admin'

-- Resource names / live data sources.
Config.QboxResource = 'qbx_core'
Config.QboxGangFile = 'shared/gangs.lua'
Config.OxInventoryResource = 'ox_inventory'
Config.InventoryImagePath = 'nui://ox_inventory/web/images'

-- Spawn limits.
Config.MaxSpawnAmount = 50
Config.DefaultAmount = 1

-- UI theme.
Config.AccentColor = '#14213a'
Config.MenuTitle = 'Gang Weapon Armory'

-- SQL persistence. AutoCreate creates the two small tables below on resource start.
Config.Database = {
    Enabled = true,
    AutoCreate = true,
    SaveSpawnLogs = true
}

-- Discord logging. Leave Webhook empty to disable.
Config.Discord = {
    Webhook = '',
    Username = 'NEX Weapon Spawn',
    Avatar = '',
    Color = '#14213a'
}

-- Gangs hidden from the sidebar.
Config.ExcludeGangs = {
    none = true,
    unemployed = true
}

-- Serial settings.
Config.Serial = {
    RandomLength = 15,
    PrefixLength = 3,
    GangCodeLength = 3,
    CustomMaxLength = 20,
    CustomRecommendedLength = 15,
    Charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
    CustomPattern = '^[A-Za-z0-9_-]+$',

    -- Random gang serial format: 3-char prefix + 3-digit gang code + random chars = total 15.
    -- Example: BAL0427G9K2XQ1M
    SerialForCategories = {
        weapon = true,
        melee = true,
        throwable = true,
        ammo = false
    }
}

-- Category detection for ox_inventory items. Custom weapons are picked up automatically if their item name starts with weapon_.
Config.ItemCategories = {
    weapon = {
        label = 'Weapons',
        icon = 'rifle',
        description = 'Firearms and custom weapon_ items'
    },
    ammo = {
        label = 'Ammo',
        icon = 'ammo',
        description = 'ammo-* / ammo_* inventory items'
    },
    throwable = {
        label = 'Throwables',
        icon = 'grenade',
        description = 'Throwable weapon items'
    },
    melee = {
        label = 'Melee',
        icon = 'knife',
        description = 'Close-combat weapon items'
    }
}

Config.MeleeWeapons = {
    weapon_dagger = true,
    weapon_bat = true,
    weapon_bottle = true,
    weapon_crowbar = true,
    weapon_flashlight = true,
    weapon_golfclub = true,
    weapon_hammer = true,
    weapon_hatchet = true,
    weapon_knuckle = true,
    weapon_knife = true,
    weapon_machete = true,
    weapon_switchblade = true,
    weapon_nightstick = true,
    weapon_wrench = true,
    weapon_battleaxe = true,
    weapon_poolcue = true,
    weapon_stone_hatchet = true,
    weapon_candycane = true
}

Config.ThrowableWeapons = {
    weapon_grenade = true,
    weapon_bzgas = true,
    weapon_molotov = true,
    weapon_stickybomb = true,
    weapon_proxmine = true,
    weapon_snowball = true,
    weapon_pipebomb = true,
    weapon_ball = true,
    weapon_smokegrenade = true,
    weapon_flare = true,
    weapon_acidpackage = true
}

-- Optional item filters.
Config.BlockedItems = {
    -- weapon_minigun = true
}

Config.FallbackItems = {
    { name = 'weapon_pistol', label = 'Pistol', category = 'weapon' },
    { name = 'weapon_combatpistol', label = 'Combat Pistol', category = 'weapon' },
    { name = 'weapon_heavypistol', label = 'Heavy Pistol', category = 'weapon' },
    { name = 'weapon_smg', label = 'SMG', category = 'weapon' },
    { name = 'weapon_combatpdw', label = 'Combat PDW', category = 'weapon' },
    { name = 'weapon_assaultrifle', label = 'Assault Rifle', category = 'weapon' },
    { name = 'weapon_knife', label = 'Knife', category = 'melee' },
    { name = 'weapon_molotov', label = 'Molotov', category = 'throwable' },
    { name = 'ammo-9', label = '9mm Ammo', category = 'ammo' },
    { name = 'ammo-rifle', label = 'Rifle Ammo', category = 'ammo' }
}
