local isOpen = false

local function showNotify(message, notifyType)
    lib.notify({
        title = Config.MenuTitle,
        description = message,
        type = notifyType or 'inform'
    })
end

local function closeMenu()
    if not isOpen then return end
    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

local function openMenu()
    if isOpen then return end

    local result = lib.callback.await('nex_weaponspawn:server:getBootstrap', false)
    if not result or not result.ok then
        showNotify(result and result.message or 'Unable to open armory.', 'error')
        return
    end

    isOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        payload = result
    })
end

RegisterCommand(Config.Command, function()
    openMenu()
end, false)

for _, alias in ipairs(Config.CommandAliases or {}) do
    RegisterCommand(alias, function()
        openMenu()
    end, false)
end

if Config.Keybind and Config.Keybind ~= '' then
    RegisterKeyMapping(Config.Command, Config.MenuTitle, 'keyboard', Config.Keybind)
end

RegisterNUICallback('close', function(_, cb)
    closeMenu()
    cb({ ok = true })
end)

RegisterNUICallback('refresh', function(_, cb)
    local result = lib.callback.await('nex_weaponspawn:server:getBootstrap', false)
    cb(result or { ok = false, message = 'Refresh failed.' })
end)

RegisterNUICallback('savePrefix', function(data, cb)
    local result = lib.callback.await('nex_weaponspawn:server:savePrefix', false, data)
    cb(result or { ok = false, message = 'Could not save prefix.' })
end)

RegisterNUICallback('spawn', function(data, cb)
    local result = lib.callback.await('nex_weaponspawn:server:spawnItem', false, data)
    cb(result or { ok = false, message = 'Spawn failed.' })
end)

RegisterNUICallback('notify', function(data, cb)
    showNotify(data and data.message or 'Notification', data and data.type or 'inform')
    cb({ ok = true })
end)

CreateThread(function()
    while GetResourceState(Config.OxInventoryResource) ~= 'started' do
        Wait(1000)
    end

    pcall(function()
        exports.ox_inventory:displayMetadata({
            serial = 'Serial',
            gangLabel = 'Gang',
            gangPrefix = 'Prefix',
            generatedBy = 'Spawned By',
            generatedAt = 'Generated At'
        })
    end)
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        SetNuiFocus(false, false)
    end
end)
