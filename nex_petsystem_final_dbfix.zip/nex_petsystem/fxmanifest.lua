fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Nex Scripts'
description 'Nex Pet System - Qbox/QB Core premium pet shop and companion system'
version '1.0.0'

ui_page 'web/index.html'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua',
    'shared/pets.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/server.lua'
}

files {
    'web/index.html',
    'web/style.css',
    'web/app.js',
    'web/img/*.png'
}

dependencies {
    'ox_lib',
    'oxmysql'
}
