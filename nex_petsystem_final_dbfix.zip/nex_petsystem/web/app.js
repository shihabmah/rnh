const app = document.getElementById('app');
const title = document.getElementById('title');
const eyebrow = document.getElementById('eyebrow');
const subtitle = document.getElementById('subtitle');
const tabs = document.getElementById('tabs');
const content = document.getElementById('content');
const closeBtn = document.getElementById('closeBtn');
const refreshBtn = document.getElementById('refreshBtn');

let state = {
    visible: false,
    mode: null,
    tab: 'dogs',
    shop: null,
    petmenu: null
};

const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'nex_petsystem';

function post(name, data = {}) {
    return fetch(`https://${resource}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data)
    }).then(res => res.json()).catch(() => ({ ok: false, message: 'NUI callback failed.' }));
}

function imagePath(img) {
    return `img/${img || 'pet.png'}`;
}

function money(amount, currency) {
    currency = currency || { symbol: '$', position: 'before' };
    amount = Number(amount || 0);
    return currency.position === 'after' ? `${amount}${currency.symbol}` : `${currency.symbol}${amount}`;
}

function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
}

function statusText(pet) {
    const map = {
        ready: 'Ready', world: 'World', vehicle: 'Vehicle', stay: 'Stay', attack: 'Attack', run: 'Quick Run', tired: 'Tired', dead: 'Dead'
    };
    return map[pet.status] || 'Ready';
}

function hungerColor(value) {
    value = Number(value || 0);
    const hue = Math.max(0, Math.min(120, value * 1.2));
    return `hsl(${hue} 86% 62%)`;
}

function setTabs(list) {
    tabs.innerHTML = list.map(t => `<button class="tab ${state.tab === t.id ? 'active' : ''}" data-tab="${t.id}">${escapeHtml(t.label)}</button>`).join('');
    tabs.querySelectorAll('.tab').forEach(btn => {
        btn.addEventListener('click', () => {
            state.tab = btn.dataset.tab;
            render();
        });
    });
}

function cardTop(item, badge) {
    return `
        <div class="card-top">
            <span class="badge">${escapeHtml(badge)}</span>
            <img src="${imagePath(item.image)}" alt="${escapeHtml(item.label || item.name)}" />
        </div>
    `;
}

function renderShop() {
    const data = state.shop;
    title.textContent = data?.title || 'Nex Pet Shop';
    eyebrow.textContent = 'NEX PET SHOP';
    subtitle.textContent = 'Buy pets, sell owned companions, and purchase supplies.';

    setTabs([
        { id: 'dogs', label: 'Dogs' },
        { id: 'cats', label: 'Cats' },
        { id: 'sell', label: 'Sell Owned' },
        { id: 'supplies', label: 'Food & Medicine' }
    ]);

    if (!data) {
        content.innerHTML = `<div class="empty">Shop data is not loaded.</div>`;
        return;
    }

    if (state.tab === 'sell') {
        const owned = data.owned || [];
        if (!owned.length) {
            content.innerHTML = `<div class="empty">You do not own any pets to sell.</div>`;
            return;
        }
        content.innerHTML = `<div class="grid">${owned.map(pet => `
            <article class="card">
                ${cardTop(pet, pet.category === 'cats' ? 'Cat' : 'Dog')}
                <div class="card-body">
                    <div class="card-title"><h3>${escapeHtml(pet.name)}</h3><span class="price">${money(pet.sellPrice, data.currency)}</span></div>
                    <p class="muted">${escapeHtml(pet.label)} companion</p>
                    <button class="btn danger" data-sell="${pet.id}" data-name="${escapeHtml(pet.name)}" data-price="${pet.sellPrice}">Sell Pet</button>
                </div>
            </article>
        `).join('')}</div>`;
        content.querySelectorAll('[data-sell]').forEach(btn => btn.addEventListener('click', async () => {
            const ok = confirm(`Are you sure you want to sell ${btn.dataset.name} for ${money(btn.dataset.price, data.currency)}?`);
            if (!ok) return;
            const result = await post('sellPet', { petId: Number(btn.dataset.sell) });
            if (result.ok) refreshShop();
        }));
        return;
    }

    if (state.tab === 'supplies') {
        const supplies = data.supplies || [];
        content.innerHTML = `<div class="grid">${supplies.map(item => `
            <article class="card">
                ${cardTop(item, item.category)}
                <div class="card-body">
                    <div class="card-title"><h3>${escapeHtml(item.label)}</h3><span class="price">${money(item.price, data.currency)}</span></div>
                    <p class="muted">${escapeHtml(item.description || '')}</p>
                    <button class="btn primary" data-buy-item="${escapeHtml(item.item)}" data-name="${escapeHtml(item.label)}" data-price="${item.price}">Buy Item</button>
                </div>
            </article>
        `).join('')}</div>`;
        content.querySelectorAll('[data-buy-item]').forEach(btn => btn.addEventListener('click', async () => {
            const ok = confirm(`Are you sure you want to buy ${btn.dataset.name} for ${money(btn.dataset.price, data.currency)}?`);
            if (!ok) return;
            await post('buySupply', { item: btn.dataset.buyItem });
        }));
        return;
    }

    const pets = (data.pets || []).filter(p => p.category === state.tab);
    if (!pets.length) {
        content.innerHTML = `<div class="empty">No pets in this category.</div>`;
        return;
    }

    content.innerHTML = `<div class="grid">${pets.map(pet => {
        const owned = data.ownedKeys && data.ownedKeys[pet.key];
        return `
            <article class="card">
                ${cardTop(pet, pet.category === 'cats' ? 'Cat' : 'Dog')}
                <div class="card-body">
                    <div class="card-title"><h3>${escapeHtml(pet.label)}</h3><span class="price">${money(pet.buyPrice, data.currency)}</span></div>
                    <p class="muted">Premium companion. One purchase per pet type.</p>
                    <button class="btn ${owned ? 'ghost' : 'primary'}" ${owned ? 'disabled' : ''} data-buy-pet="${escapeHtml(pet.key)}" data-name="${escapeHtml(pet.label)}" data-price="${pet.buyPrice}">${owned ? 'Already Owned' : 'Buy Pet'}</button>
                </div>
            </article>
        `;
    }).join('')}</div>`;

    content.querySelectorAll('[data-buy-pet]').forEach(btn => btn.addEventListener('click', async () => {
        const ok = confirm(`Are you sure you want to buy ${btn.dataset.name} for ${money(btn.dataset.price, data.currency)}?`);
        if (!ok) return;
        const result = await post('buyPet', { petKey: btn.dataset.buyPet });
        if (result.ok) refreshShop();
    }));
}

function renderPetMenu() {
    const data = state.petmenu;
    title.textContent = 'My Pet Menu';
    eyebrow.textContent = 'OWNED COMPANIONS';
    subtitle.textContent = 'Call, return, feed, and manage your pets.';

    setTabs([
        { id: 'all', label: 'All Owned' },
        { id: 'dogs', label: 'Dogs' },
        { id: 'cats', label: 'Cats' }
    ]);

    if (!data) {
        content.innerHTML = `<div class="empty">Pet menu data is not loaded.</div>`;
        return;
    }

    let pets = data.owned || [];
    if (state.tab === 'dogs') pets = pets.filter(p => p.category === 'dogs');
    if (state.tab === 'cats') pets = pets.filter(p => p.category === 'cats');

    if (!pets.length) {
        content.innerHTML = `<div class="empty">You do not have pets in this category.</div>`;
        return;
    }

    content.innerHTML = `<div class="grid">${pets.map(pet => {
        const hunger = Number(pet.hunger || 0);
        const isTired = pet.status === 'tired';
        const isDead = pet.status === 'dead';
        const canCall = !pet.spawned && !isTired && !isDead;
        const canBringCar = pet.spawned && pet.ownerInVehicle && !pet.inVehicle && !isDead;
        const canTakeOut = pet.spawned && pet.inVehicle;
        return `
            <article class="card">
                ${cardTop(pet, pet.category === 'cats' ? 'Cat' : 'Dog')}
                <div class="card-body">
                    <div class="card-title"><h3>${escapeHtml(pet.name)}</h3><span class="hunger-number" style="color:${hungerColor(hunger)}">${Math.floor(hunger)}%</span></div>
                    <div class="hunger-row"><span>Hunger Status</span><span>${escapeHtml(statusText(pet))}</span></div>
                    <div class="bar"><div class="bar-fill" style="width:${Math.max(0, Math.min(100, hunger))}%; background:${hungerColor(hunger)}"></div></div>
                    <div class="actions">
                        ${pet.spawned ? `<button class="btn danger" data-return="${pet.id}">Bring Back</button>` : `<button class="btn primary" ${canCall ? '' : 'disabled'} data-call="${pet.id}">Call Pet</button>`}
                        ${canBringCar ? `<button class="btn ghost" data-vehicle="bringToCar" data-id="${pet.id}">Bring To Car</button>` : ''}
                        ${canTakeOut ? `<button class="btn green" data-vehicle="takeOut" data-id="${pet.id}">Take Out From Car</button>` : ''}
                    </div>
                </div>
            </article>
        `;
    }).join('')}</div>`;

    content.querySelectorAll('[data-call]').forEach(btn => btn.addEventListener('click', async () => {
        const pet = pets.find(p => String(p.id) === String(btn.dataset.call));
        if (!pet) return;
        await post('callPet', { pet });
    }));

    content.querySelectorAll('[data-return]').forEach(btn => btn.addEventListener('click', async () => {
        await post('returnPet', { petId: Number(btn.dataset.return) });
        refreshPetMenu();
    }));

    content.querySelectorAll('[data-vehicle]').forEach(btn => btn.addEventListener('click', async () => {
        await post('vehicleAction', { petId: Number(btn.dataset.id), action: btn.dataset.vehicle });
        setTimeout(refreshPetMenu, 700);
    }));
}

function render() {
    if (state.mode === 'shop') renderShop();
    if (state.mode === 'petmenu') renderPetMenu();
}

async function refreshShop() {
    const result = await post('refreshShop');
    if (result && result.ok) {
        state.shop = result;
        render();
    }
}

async function refreshPetMenu() {
    const result = await post('refreshPetMenu');
    if (result && result.ok) {
        state.petmenu = result;
        render();
    }
}

refreshBtn.addEventListener('click', () => {
    if (state.mode === 'shop') refreshShop();
    if (state.mode === 'petmenu') refreshPetMenu();
});

closeBtn.addEventListener('click', () => post('close'));

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') post('close');
});

window.addEventListener('message', (event) => {
    const msg = event.data || {};
    if (msg.action === 'setVisible') {
        state.visible = true;
        state.mode = msg.mode;
        state.tab = msg.mode === 'shop' ? 'dogs' : 'all';
        app.classList.remove('hidden');
        render();
    }
    if (msg.action === 'close') {
        state.visible = false;
        app.classList.add('hidden');
    }
    if (msg.action === 'openShop') {
        state.mode = 'shop';
        state.shop = msg.data;
        state.tab = 'dogs';
        app.classList.remove('hidden');
        render();
    }
    if (msg.action === 'openPetMenu') {
        state.mode = 'petmenu';
        state.petmenu = msg.data;
        state.tab = 'all';
        app.classList.remove('hidden');
        render();
    }
});
