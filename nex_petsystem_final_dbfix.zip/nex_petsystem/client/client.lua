local callbacks, callbackId = {}, 0
local activePets = {}
local shopNPCs = {}
local shopZones = {}
local textUiShown = false
local nuiOpen = false
local currentNuiMode = nil
local currentShopId = nil
local relationshipReady = false

local function dprint(...)
    if Config.Debug then print('[nex_petsystem:client]', ...) end
end

local function notify(title, description, nType)
    if lib and lib.notify then
        lib.notify({ title = title or 'Nex Pet System', description = description or '', type = nType or 'inform', position = Config.Notifications.position })
    else
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName((title or 'Nex Pet System') .. ': ' .. (description or ''))
        EndTextCommandThefeedPostTicker(false, true)
    end
end

RegisterNetEvent('nex_petsystem:client:notify', notify)

local function serverCallback(name, cb, ...)
    callbackId = callbackId + 1
    local id = callbackId
    callbacks[id] = cb
    TriggerServerEvent('nex_petsystem:server:callback', name, id, ...)
    SetTimeout(12000, function()
        if callbacks[id] then
            callbacks[id] = nil
            cb(false, 'timeout')
        end
    end)
end

RegisterNetEvent('nex_petsystem:client:callback', function(id, ok, result)
    local cb = callbacks[id]
    if not cb then return end
    callbacks[id] = nil
    cb(ok, result)
end)

local function fmtMoney(amount, currency)
    currency = currency or Config.Currency
    amount = tonumber(amount) or 0
    if currency.position == 'after' then return tostring(amount) .. currency.symbol end
    return currency.symbol .. tostring(amount)
end

local function loadModel(model)
    local hash = type(model) == 'number' and model or joaat(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local timeout = GetGameTimer() + 8000
    while not HasModelLoaded(hash) do
        Wait(10)
        if GetGameTimer() > timeout then return nil end
    end
    return hash
end

local function loadAnimDict(dict)
    RequestAnimDict(dict)
    local timeout = GetGameTimer() + 5000
    while not HasAnimDictLoaded(dict) do
        Wait(10)
        if GetGameTimer() > timeout then return false end
    end
    return true
end

local function getPetConfig(key)
    return NexPet_GetPetConfig(key)
end

local function targetSystem()
    local wanted = Config.Shop.targetSystem or 'auto'
    if wanted == 'ox_target' or (wanted == 'auto' and GetResourceState('ox_target') == 'started') then return 'ox_target' end
    if wanted == 'qb-target' or (wanted == 'auto' and GetResourceState('qb-target') == 'started') then return 'qb-target' end
    return nil
end

local function setNui(open, mode)
    nuiOpen = open
    currentNuiMode = open and mode or nil
    SetNuiFocus(open, open)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = open and 'setVisible' or 'close', mode = mode })
end

local function isNearShop()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    for _, loc in ipairs(Config.Shop.locations) do
        local pos = loc.coords
        if Config.Shop.useNPC and loc.npc and loc.npc.enabled and loc.npc.coords then
            pos = vec3(loc.npc.coords.x, loc.npc.coords.y, loc.npc.coords.z)
        end
        if #(coords - pos) <= (Config.Shop.openDistance + 2.0) then
            return true, loc.id
        end
    end
    return false, nil
end

local function enrichOwned(owned)
    local list = {}
    for _, pet in ipairs(owned or {}) do
        local active = activePets[tonumber(pet.id)]
        local status = 'ready'
        local inVehicle = false
        local spawned = false
        if pet.dead then
            status = 'dead'
        elseif pet.hunger and pet.hunger <= Config.Hunger.tiredAt then
            status = 'tired'
        end
        if active and DoesEntityExist(active.ped) then
            spawned = true
            inVehicle = IsPedInAnyVehicle(active.ped, false)
            if active.dead then status = 'dead'
            elseif inVehicle then status = 'vehicle'
            elseif active.state == 'stay' then status = 'stay'
            elseif active.state == 'combat' then status = 'attack'
            elseif active.state == 'quickrun' then status = 'run'
            elseif active.state == 'tired' then status = 'tired'
            else status = 'world' end
            pet.hunger = math.floor(active.hunger or pet.hunger or 100)
            pet.health = math.max(0, GetEntityHealth(active.ped) or pet.health or Config.Pet.spawnHealth)
        end
        pet.spawned = spawned
        pet.inVehicle = inVehicle
        pet.status = status
        pet.ownerInVehicle = IsPedInAnyVehicle(PlayerPedId(), false)
        list[#list + 1] = pet
    end
    return list
end

local function openShop(shopId)
    currentShopId = shopId
    serverCallback('getShopData', function(ok, result)
        if not ok or not result or result.ok == false then
            notify('Nex Pet System', (result and result.error) or 'Shop data could not be loaded. Check oxmysql/server console for nex_petsystem errors.', 'error')
            return
        end
        setNui(true, 'shop')
        SendNUIMessage({ action = 'openShop', data = result })
    end)
end

local function openPetMenu()
    serverCallback('getPetMenuData', function(ok, result)
        if not ok or not result or result.ok == false then
            notify('Nex Pet System', (result and result.error) or 'Pet menu data could not be loaded.', 'error')
            return
        end
        result.owned = enrichOwned(result.owned)
        setNui(true, 'petmenu')
        SendNUIMessage({ action = 'openPetMenu', data = result })
    end)
end

RegisterCommand(Config.Commands.petMenu, function()
    openPetMenu()
end, false)

local function progress(label, duration, anim, propModel)
    local ped = PlayerPedId()
    local prop
    if anim then
        if loadAnimDict('amb@medic@standing@kneel@base') then
            TaskPlayAnim(ped, 'amb@medic@standing@kneel@base', 'base', 4.0, -4.0, -1, 1, 0.0, false, false, false)
        end
    end

    if propModel then
        local hash = loadModel(propModel)
        if hash then
            local coords = GetEntityCoords(ped)
            prop = CreateObject(hash, coords.x, coords.y, coords.z + 0.2, true, true, false)
            AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 57005), 0.12, 0.02, -0.02, 80.0, 160.0, 20.0, true, true, false, true, 1, true)
            SetModelAsNoLongerNeeded(hash)
        end
    end

    local success
    if Config.Progress.type == 'circle' then
        success = lib.progressCircle({ duration = duration, label = label, position = 'bottom', useWhileDead = false, canCancel = true, disable = Config.Progress.disable })
    else
        success = lib.progressBar({ duration = duration, label = label, useWhileDead = false, canCancel = true, disable = Config.Progress.disable })
    end

    ClearPedTasks(ped)
    if prop and DoesEntityExist(prop) then DeleteEntity(prop) end
    return success
end

local function ensureRelationship()
    if relationshipReady then return end
    AddRelationshipGroup(Config.Pet.defaultRelationshipGroup)
    local group = joaat(Config.Pet.defaultRelationshipGroup)
    SetRelationshipBetweenGroups(0, group, group)
    SetRelationshipBetweenGroups(0, group, joaat('PLAYER'))
    relationshipReady = true
end

local function updatePetServerState(active, dead)
    if not active or not active.data then return end
    local health = 0
    if active.ped and DoesEntityExist(active.ped) then
        health = math.max(0, GetEntityHealth(active.ped))
    end
    serverCallback('updatePetState', function() end, active.data.id, active.hunger or 100, health, dead or active.dead or false)
end

local function deleteActivePet(petId, updateState)
    local active = activePets[tonumber(petId)]
    if not active then return end
    if updateState then updatePetServerState(active, active.dead) end
    if active.blip then RemoveBlip(active.blip) end
    if active.ped and DoesEntityExist(active.ped) then
        SetEntityAsMissionEntity(active.ped, true, true)
        DeleteEntity(active.ped)
    end
    activePets[tonumber(petId)] = nil
end

local function ensureFollow(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) or active.dead then return end
    if active.hunger <= Config.Hunger.tiredAt then return end
    if IsPedInAnyVehicle(active.ped, false) then return end
    local owner = PlayerPedId()
    ClearPedTasks(active.ped)
    TaskFollowToOffsetOfEntity(active.ped, owner, 0.0, -Config.Pet.followDistance, 0.0, Config.Pet.followSpeed, -1, Config.Pet.followDistance, true)
    active.state = 'follow'
end

local function stayPet(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) or active.dead then return end
    ClearPedTasks(active.ped)
    TaskStandStill(active.ped, -1)
    active.state = 'stay'
    notify('Nex Pet System', active.data.name .. ' will stay here.', 'inform')
end

local function stopPetAttack(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) then return end
    active.target = nil
    ClearPedTasks(active.ped)
    if active.hunger > Config.Hunger.tiredAt and not active.dead then
        ensureFollow(petId)
    else
        active.state = 'tired'
    end
end

local function stopAllPetAttacks()
    for id in pairs(activePets) do stopPetAttack(id) end
    notify('Nex Pet System', 'Your pets stopped attacking.', 'success')
end

RegisterCommand(Config.Commands.stopAttack, function()
    stopAllPetAttacks()
end, false)

local function makePetAttack(petId, target)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) or active.dead then return end
    if active.hunger <= Config.Hunger.tiredAt then
        notify('Nex Pet System', active.data.name .. ' is too tired to attack.', 'error')
        return
    end
    if not DoesEntityExist(target) or target == active.ped then return end
    if IsPedInAnyVehicle(active.ped, false) then return end

    ClearPedTasks(active.ped)
    SetPedCombatAttributes(active.ped, 46, true)
    SetPedCombatAttributes(active.ped, 5, true)
    SetPedCombatAbility(active.ped, 2)
    SetPedCombatRange(active.ped, 1)
    SetPedCombatMovement(active.ped, 2)
    TaskCombatPed(active.ped, target, 0, 16)
    active.target = target
    active.state = 'combat'

    SetTimeout(Config.Combat.combatTimeoutSeconds * 1000, function()
        local latest = activePets[tonumber(petId)]
        if latest and latest.state == 'combat' then stopPetAttack(petId) end
    end)
end

local function allPetsAttack(target)
    if not Config.Combat.enabled then return end
    for id in pairs(activePets) do makePetAttack(id, target) end
end

AddEventHandler('gameEventTriggered', function(eventName, args)
    if eventName ~= 'CEventNetworkEntityDamage' or not Config.Combat.protectOwner then return end
    local victim = args[1]
    local attacker = args[2]
    if victim ~= PlayerPedId() then return end
    if not attacker or attacker == 0 or attacker == victim or not DoesEntityExist(attacker) then return end
    if IsEntityAPed(attacker) then
        if IsPedAPlayer(attacker) and not Config.Combat.allowAttackPlayers then return end
        if not IsPedAPlayer(attacker) and not Config.Combat.allowAttackNPCs then return end
        allPetsAttack(attacker)
    end
end)

local function openAttackMenu(petId)
    local active = activePets[tonumber(petId)]
    if not active then return end
    local options = {}
    local myPed = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)
    for _, player in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(player)
        if ped ~= myPed and DoesEntityExist(ped) and #(GetEntityCoords(ped) - myCoords) <= Config.Combat.nearbyAttackListDistance then
            local sid = GetPlayerServerId(player)
            options[#options + 1] = {
                title = ('ID %s'):format(sid),
                description = GetPlayerName(player) or 'Nearby player',
                icon = 'crosshairs',
                onSelect = function() makePetAttack(petId, ped) end
            }
        end
    end
    if #options == 0 then
        notify('Nex Pet System', 'No nearby players found.', 'error')
        return
    end
    lib.registerContext({ id = 'nex_pet_attack_' .. petId, title = 'Attack Nearby Player', options = options })
    lib.showContext('nex_pet_attack_' .. petId)
end

local function quickRunPet(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) or active.dead then return end
    if active.hunger <= Config.Hunger.tiredAt then
        notify('Nex Pet System', active.data.name .. ' is too tired to run.', 'error')
        return
    end
    local owner = PlayerPedId()
    local coords = GetEntityCoords(owner)
    local angle = math.random() * math.pi * 2.0
    local radius = math.random(3, math.floor(Config.QuickRun.radius * 10)) / 10.0
    local dest = vec3(coords.x + math.cos(angle) * radius, coords.y + math.sin(angle) * radius, coords.z)
    ClearPedTasks(active.ped)
    TaskGoStraightToCoord(active.ped, dest.x, dest.y, dest.z, Config.QuickRun.speed, Config.QuickRun.durationSeconds * 1000, 0.0, 0.1)
    active.state = 'quickrun'
    SetTimeout(Config.QuickRun.durationSeconds * 1000, function()
        if activePets[tonumber(petId)] and activePets[tonumber(petId)].state == 'quickrun' then ensureFollow(petId) end
    end)
end

local function freeSeat(vehicle)
    local seats = GetVehicleModelNumberOfSeats(GetEntityModel(vehicle))
    for seat = 0, seats - 2 do
        if IsVehicleSeatFree(vehicle, seat) then return seat end
    end
    return nil
end

local function bringPetToVehicle(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) or active.dead then return end
    local owner = PlayerPedId()
    if not IsPedInAnyVehicle(owner, false) then
        notify('Nex Pet System', 'You must be inside a vehicle.', 'error')
        return
    end
    local vehicle = GetVehiclePedIsIn(owner, false)
    local dist = #(GetEntityCoords(active.ped) - GetEntityCoords(vehicle))
    if dist > Config.Vehicle.callDistance then
        notify('Nex Pet System', ('Pet must be within %.1fm of your vehicle.'):format(Config.Vehicle.callDistance), 'error')
        return
    end
    local seat = freeSeat(vehicle)
    if seat == nil then
        notify('Nex Pet System', 'No free vehicle seat found.', 'error')
        return
    end
    if progress('Bringing pet into vehicle...', Config.Progress.bringVehicleSeconds * 1000, false, nil) then
        ClearPedTasks(active.ped)
        TaskEnterVehicle(active.ped, vehicle, Config.Vehicle.enterTimeout, seat, 2.0, 1, 0)
        SetTimeout(Config.Vehicle.enterTimeout, function()
            if activePets[tonumber(petId)] and not IsPedInAnyVehicle(active.ped, false) and IsVehicleSeatFree(vehicle, seat) then
                SetPedIntoVehicle(active.ped, vehicle, seat)
            end
            if activePets[tonumber(petId)] then activePets[tonumber(petId)].state = 'vehicle' end
        end)
    end
end

local function takePetOutVehicle(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) then return end
    if not IsPedInAnyVehicle(active.ped, false) then
        notify('Nex Pet System', 'This pet is not inside a vehicle.', 'error')
        return
    end
    local owner = PlayerPedId()
    local coords = GetOffsetFromEntityInWorldCoords(owner, Config.Vehicle.exitOffset.x, Config.Vehicle.exitOffset.y, Config.Vehicle.exitOffset.z)
    TaskLeaveVehicle(active.ped, GetVehiclePedIsIn(active.ped, false), 0)
    SetTimeout(900, function()
        if activePets[tonumber(petId)] and DoesEntityExist(active.ped) then
            SetEntityCoords(active.ped, coords.x, coords.y, coords.z, false, false, false, true)
            ensureFollow(petId)
        end
    end)
end

local function feedPet(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) or active.dead then return end
    local petCfg = getPetConfig(active.data.petKey)
    local label = petCfg and petCfg.category == 'cats' and 'Feed Cat' or 'Feed Dog'
    local duration = math.random(Config.Progress.feedSecondsMin, Config.Progress.feedSecondsMax) * 1000
    local prop = Config.FeedingProps[math.random(1, #Config.FeedingProps)]
    if not progress(label .. '...', duration, true, prop) then return end

    serverCallback('feedPet', function(ok, result)
        if not ok or not result or not result.ok then
            notify('Nex Pet System', (result and result.message) or 'Could not feed pet.', 'error')
            return
        end
        active.hunger = result.hunger or math.min(100, (active.hunger or 100) + Config.Hunger.feedAmount)
        active.warned = {}
        if active.hunger > Config.Hunger.tiredAt and active.state == 'tired' then ensureFollow(petId) end
        notify('Nex Pet System', result.message or 'Your pet has been fed.', 'success')
    end, petId, petCfg and petCfg.category or active.data.category, active.hunger)
end

local function petPet(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) or active.dead then return end
    if progress('Petting ' .. active.data.name .. '...', Config.Progress.petSeconds * 1000, true, nil) then
        local coords = GetEntityCoords(PlayerPedId())
        TaskTurnPedToFaceCoord(active.ped, coords.x, coords.y, coords.z, 1000)
        notify('Nex Pet System', active.data.name .. ' feels loved.', 'success')
    end
end

local function revivePet(petId)
    local active = activePets[tonumber(petId)]
    if not active or not DoesEntityExist(active.ped) then return end
    if not active.dead and not IsEntityDead(active.ped) then
        notify('Nex Pet System', 'This pet is not dead.', 'error')
        return
    end
    if not progress('Reviving pet...', Config.Progress.reviveSeconds * 1000, true, nil) then return end
    serverCallback('revivePet', function(ok, result)
        if not ok or not result or not result.ok then
            notify('Nex Pet System', (result and result.message) or 'Could not revive pet.', 'error')
            return
        end
        ResurrectPed(active.ped)
        ClearPedTasksImmediately(active.ped)
        SetEntityHealth(active.ped, result.health or Config.Pet.spawnHealth)
        active.dead = false
        active.hunger = result.hunger or 50
        active.data.dead = false
        active.data.health = result.health or Config.Pet.spawnHealth
        active.data.hunger = active.hunger
        ensureFollow(petId)
        local category = (getPetConfig(active.data.petKey) or {}).category == 'cats' and 'cat' or 'dog'
        notify('Nex Pet System', ('Your %s is revived.'):format(category), 'success')
    end, petId)
end

local function addPetTarget(petId, ped)
    local active = activePets[tonumber(petId)]
    if not active then return end
    local petCfg = getPetConfig(active.data.petKey)
    local feedLabel = petCfg and petCfg.category == 'cats' and 'Feed Cat' or 'Feed Dog'
    local system = targetSystem()
    if system == 'ox_target' then
        exports.ox_target:addLocalEntity(ped, {
            { label = 'Follow', icon = 'fa-solid fa-paw', distance = 2.5, onSelect = function() ensureFollow(petId) end, canInteract = function() return not active.dead end },
            { label = 'Stay Here', icon = 'fa-solid fa-hand', distance = 2.5, onSelect = function() stayPet(petId) end, canInteract = function() return not active.dead end },
            { label = feedLabel, icon = 'fa-solid fa-bowl-food', distance = 2.5, onSelect = function() feedPet(petId) end, canInteract = function() return not active.dead end },
            { label = 'Pet', icon = 'fa-solid fa-heart', distance = 2.5, onSelect = function() petPet(petId) end, canInteract = function() return not active.dead end },
            { label = 'Bring To Car', icon = 'fa-solid fa-car', distance = 3.0, onSelect = function() bringPetToVehicle(petId) end, canInteract = function() return not active.dead and IsPedInAnyVehicle(PlayerPedId(), false) and not IsPedInAnyVehicle(ped, false) end },
            { label = 'Bring Out Of Car', icon = 'fa-solid fa-right-from-bracket', distance = 3.0, onSelect = function() takePetOutVehicle(petId) end, canInteract = function() return IsPedInAnyVehicle(ped, false) end },
            { label = 'Quick Run', icon = 'fa-solid fa-bolt', distance = 2.5, onSelect = function() quickRunPet(petId) end, canInteract = function() return not active.dead end },
            { label = 'Attack Someone', icon = 'fa-solid fa-crosshairs', distance = 2.5, onSelect = function() openAttackMenu(petId) end, canInteract = function() return not active.dead end },
            { label = 'Stop Attack', icon = 'fa-solid fa-shield', distance = 2.5, onSelect = function() stopPetAttack(petId) end, canInteract = function() return true end },
            { label = 'Revive Pet', icon = 'fa-solid fa-syringe', distance = 2.5, onSelect = function() revivePet(petId) end, canInteract = function() return active.dead or IsEntityDead(ped) end }
        })
    elseif system == 'qb-target' then
        exports['qb-target']:AddTargetEntity(ped, {
            options = {
                { label = 'Follow', icon = 'fas fa-paw', action = function() ensureFollow(petId) end },
                { label = 'Stay Here', icon = 'fas fa-hand', action = function() stayPet(petId) end },
                { label = feedLabel, icon = 'fas fa-bowl-food', action = function() feedPet(petId) end },
                { label = 'Pet', icon = 'fas fa-heart', action = function() petPet(petId) end },
                { label = 'Bring To Car', icon = 'fas fa-car', action = function() bringPetToVehicle(petId) end },
                { label = 'Bring Out Of Car', icon = 'fas fa-right-from-bracket', action = function() takePetOutVehicle(petId) end },
                { label = 'Quick Run', icon = 'fas fa-bolt', action = function() quickRunPet(petId) end },
                { label = 'Attack Someone', icon = 'fas fa-crosshairs', action = function() openAttackMenu(petId) end },
                { label = 'Stop Attack', icon = 'fas fa-shield', action = function() stopPetAttack(petId) end },
                { label = 'Revive Pet', icon = 'fas fa-syringe', action = function() revivePet(petId) end }
            },
            distance = 2.5
        })
    end
end

local function spawnPet(data)
    local id = tonumber(data.id)
    if activePets[id] and DoesEntityExist(activePets[id].ped) then
        notify('Nex Pet System', 'This pet is already spawned.', 'error')
        return false
    end
    if data.dead then
        notify('Nex Pet System', 'This pet is dead. Revive the body if it is still in world.', 'error')
        return false
    end
    if (tonumber(data.hunger) or 100) <= Config.Hunger.tiredAt then
        notify('Nex Pet System', data.name .. ' is too tired and hungry to be called.', 'error')
        return false
    end

    local petCfg = getPetConfig(data.petKey)
    local model = data.model or (petCfg and petCfg.model)
    local hash = loadModel(model)
    if not hash then
        notify('Nex Pet System', ('Pet model %s could not be loaded. Check shared/pets.lua.'):format(tostring(model)), 'error')
        return false
    end

    ensureRelationship()
    local owner = PlayerPedId()
    local coords = GetEntityCoords(owner)
    local forward = GetEntityForwardVector(owner)
    local spawn = coords + (forward * Config.Pet.spawnDistance)
    local ped = CreatePed(28, hash, spawn.x, spawn.y, spawn.z, GetEntityHeading(owner), true, true)

    SetEntityAsMissionEntity(ped, true, true)
    SetPedRelationshipGroupHash(ped, joaat(Config.Pet.defaultRelationshipGroup))
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedFleeAttributes(ped, 0, false)
    SetPedCanRagdoll(ped, true)
    SetPedDiesWhenInjured(ped, false)
    SetEntityMaxHealth(ped, Config.Pet.maxHealth)
    SetEntityHealth(ped, math.max(1, tonumber(data.health) or Config.Pet.spawnHealth))
    SetPedArmour(ped, Config.Pet.armor)

    if data.component then
        pcall(function() SetPedComponentVariation(ped, 0, tonumber(data.component) or 0, 0, 0) end)
    end

    SetModelAsNoLongerNeeded(hash)

    local blip
    if Config.Blips.spawnedPet.enabled then
        blip = AddBlipForEntity(ped)
        SetBlipSprite(blip, Config.Blips.spawnedPet.sprite)
        SetBlipColour(blip, Config.Blips.spawnedPet.color)
        SetBlipScale(blip, Config.Blips.spawnedPet.scale)
        SetBlipAsShortRange(blip, Config.Blips.spawnedPet.shortRange)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString(data.name or 'Pet')
        EndTextCommandSetBlipName(blip)
    end

    activePets[id] = {
        ped = ped,
        data = data,
        hunger = tonumber(data.hunger) or Config.Hunger.max,
        warned = {},
        dead = false,
        state = 'follow',
        blip = blip
    }

    addPetTarget(id, ped)
    ensureFollow(id)
    notify('Nex Pet System', 'Your pet spawned nearby.', 'success')
    return true
end

RegisterNUICallback('close', function(_, cb)
    setNui(false)
    cb({ ok = true })
end)

RegisterNUICallback('refreshShop', function(_, cb)
    serverCallback('getShopData', function(ok, result)
        cb(ok and result or { ok = false })
    end)
end)

RegisterNUICallback('refreshPetMenu', function(_, cb)
    serverCallback('getPetMenuData', function(ok, result)
        if ok and result and result.ok then result.owned = enrichOwned(result.owned) end
        cb(ok and result or { ok = false })
    end)
end)

RegisterNUICallback('buyPet', function(data, cb)
    serverCallback('buyPet', function(ok, result)
        cb(ok and result or { ok = false, message = 'Could not buy pet.' })
    end, data.petKey)
end)

RegisterNUICallback('sellPet', function(data, cb)
    local petId = tonumber(data.petId)
    local nearShop = isNearShop()
    serverCallback('sellPet', function(ok, result)
        if ok and result and result.ok and activePets[petId] then
            deleteActivePet(petId, false)
        end
        cb(ok and result or { ok = false, message = 'Could not sell pet.' })
    end, petId, nearShop)
end)

RegisterNUICallback('buySupply', function(data, cb)
    serverCallback('buySupply', function(ok, result)
        cb(ok and result or { ok = false, message = 'Could not buy item.' })
    end, data.item)
end)

RegisterNUICallback('callPet', function(data, cb)
    local pet = data.pet
    if not pet then cb({ ok = false, message = 'Missing pet data.' }) return end
    local success = spawnPet(pet)
    if success then
        setNui(false)
        cb({ ok = true })
    else
        cb({ ok = false })
    end
end)

RegisterNUICallback('returnPet', function(data, cb)
    local petId = tonumber(data.petId)
    if activePets[petId] then
        deleteActivePet(petId, true)
        notify('Nex Pet System', 'Pet brought back.', 'success')
        cb({ ok = true })
    else
        cb({ ok = false, message = 'Pet is not spawned.' })
    end
end)

RegisterNUICallback('vehicleAction', function(data, cb)
    local petId = tonumber(data.petId)
    if data.action == 'takeOut' then
        takePetOutVehicle(petId)
    elseif data.action == 'bringToCar' then
        bringPetToVehicle(petId)
    end
    cb({ ok = true })
end)

local function addShopTargetEntity(entity, loc)
    local system = targetSystem()
    if system == 'ox_target' then
        exports.ox_target:addLocalEntity(entity, {
            { label = 'Open Nex Pet Shop', icon = 'fa-solid fa-paw', distance = Config.Shop.openDistance, onSelect = function() openShop(loc.id) end }
        })
        return true
    elseif system == 'qb-target' then
        exports['qb-target']:AddTargetEntity(entity, {
            options = { { label = 'Open Nex Pet Shop', icon = 'fas fa-paw', action = function() openShop(loc.id) end } },
            distance = Config.Shop.openDistance
        })
        return true
    end
    return false
end

local function createShopZone(loc)
    local system = targetSystem()
    if system == 'ox_target' then
        local height = (loc.maxZ and loc.minZ) and (loc.maxZ - loc.minZ) or 1.0
        local z = (loc.maxZ and loc.minZ) and ((loc.maxZ + loc.minZ) / 2.0) or loc.coords.z
        local id = exports.ox_target:addBoxZone({
            coords = vec3(loc.coords.x, loc.coords.y, z),
            size = vec3(loc.length or 1.2, loc.width or 1.2, height),
            rotation = loc.heading or 0.0,
            debug = loc.debugPoly or false,
            options = {
                { label = 'Open Nex Pet Shop', icon = 'fa-solid fa-paw', distance = Config.Shop.openDistance, onSelect = function() openShop(loc.id) end }
            }
        })
        shopZones[#shopZones + 1] = { system = 'ox_target', id = id }
        return true
    elseif system == 'qb-target' then
        exports['qb-target']:AddBoxZone(loc.id, loc.coords, loc.length or 1.2, loc.width or 1.2, {
            name = loc.id,
            heading = loc.heading or 0.0,
            debugPoly = loc.debugPoly or false,
            minZ = loc.minZ,
            maxZ = loc.maxZ
        }, {
            options = { { label = 'Open Nex Pet Shop', icon = 'fas fa-paw', action = function() openShop(loc.id) end } },
            distance = Config.Shop.openDistance
        })
        shopZones[#shopZones + 1] = { system = 'qb-target', id = loc.id }
        return true
    end
    return false
end

local function createShopBlips()
    for _, loc in ipairs(Config.Shop.locations) do
        if loc.blip and loc.blip.enabled then
            local blip = AddBlipForCoord(loc.coords.x, loc.coords.y, loc.coords.z)
            SetBlipSprite(blip, loc.blip.sprite or 273)
            SetBlipColour(blip, loc.blip.color or 38)
            SetBlipScale(blip, loc.blip.scale or 0.75)
            SetBlipAsShortRange(blip, loc.blip.shortRange ~= false)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentString(loc.blip.name or 'Nex Pet Shop')
            EndTextCommandSetBlipName(blip)
        end
    end
end

local function setupShops()
    createShopBlips()
    local anyTargetFailed = false

    for _, loc in ipairs(Config.Shop.locations) do
        local targetCreated = false
        if Config.Shop.useNPC and loc.npc and loc.npc.enabled then
            local hash = loadModel(loc.npc.model or 'a_f_y_business_02')
            if hash then
                local c = loc.npc.coords
                local npc = CreatePed(4, hash, c.x, c.y, c.z, c.w, false, true)
                SetEntityInvincible(npc, true)
                FreezeEntityPosition(npc, true)
                SetBlockingOfNonTemporaryEvents(npc, true)
                if loc.npc.scenario then TaskStartScenarioInPlace(npc, loc.npc.scenario, 0, true) end
                shopNPCs[#shopNPCs + 1] = npc
                SetModelAsNoLongerNeeded(hash)
                if Config.Shop.interaction == 'target' then targetCreated = addShopTargetEntity(npc, loc) end
            end
        elseif Config.Shop.interaction == 'target' then
            targetCreated = createShopZone(loc)
        end

        if Config.Shop.interaction == 'target' and not targetCreated then
            anyTargetFailed = true
            print('[nex_petsystem] Target shop could not be created for ' .. loc.id .. '. Check ox_target/qb-target or use Config.Shop.interaction = textui.')
        end
    end

    if Config.Shop.interaction == 'textui' or Config.Shop.interaction == 'marker' or (Config.Shop.interaction == 'target' and Config.Shop.fallbackToTextUi and anyTargetFailed) then
        CreateThread(function()
            while true do
                local sleep = 750
                local ped = PlayerPedId()
                local coords = GetEntityCoords(ped)
                local closest, closestDist
                for _, loc in ipairs(Config.Shop.locations) do
                    local pos = loc.coords
                    if Config.Shop.useNPC and loc.npc and loc.npc.enabled and loc.npc.coords then
                        pos = vec3(loc.npc.coords.x, loc.npc.coords.y, loc.npc.coords.z)
                    end
                    local dist = #(coords - pos)
                    if not closestDist or dist < closestDist then closest, closestDist = loc, dist end
                end

                if closest and closestDist <= Config.Shop.markerDistance then
                    sleep = 0
                    if Config.Shop.interaction == 'marker' then
                        DrawMarker(Config.Shop.markerType, closest.coords.x, closest.coords.y, closest.coords.z + 0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Config.Shop.markerScale.x, Config.Shop.markerScale.y, Config.Shop.markerScale.z, Config.Shop.markerColor.r, Config.Shop.markerColor.g, Config.Shop.markerColor.b, Config.Shop.markerColor.a, false, false, 2, false, nil, nil, false)
                    end
                    if closestDist <= Config.Shop.openDistance then
                        if not textUiShown then
                            lib.showTextUI('[E] Open Nex Pet Shop', { icon = 'paw' })
                            textUiShown = true
                        end
                        if IsControlJustReleased(0, 38) then openShop(closest.id) end
                    elseif textUiShown then
                        lib.hideTextUI(); textUiShown = false
                    end
                elseif textUiShown then
                    lib.hideTextUI(); textUiShown = false
                end

                Wait(sleep)
            end
        end)
    end
end

CreateThread(function()
    Wait(1000)
    setupShops()
end)

CreateThread(function()
    local tickMs = math.max(10, Config.Hunger.tickSeconds) * 1000
    local hungerLoss = Config.Hunger.max / ((Config.Hunger.drainHoursFromFullToZero * 3600) / Config.Hunger.tickSeconds)
    while true do
        Wait(tickMs)
        for id, active in pairs(activePets) do
            if active.ped and DoesEntityExist(active.ped) then
                if not active.dead and IsEntityDead(active.ped) then
                    active.dead = true
                    active.state = 'dead'
                    updatePetServerState(active, true)
                    notify('Nex Pet System', active.data.name .. ' is down. Use a pet revive injection on the body.', 'error')
                end

                if not active.dead and Config.Hunger.enabled and not IsPedInAnyVehicle(active.ped, false) then
                    active.hunger = math.max(0, (active.hunger or Config.Hunger.max) - hungerLoss)
                    for _, threshold in ipairs(Config.Hunger.lowWarnings) do
                        if active.hunger <= threshold and not active.warned[threshold] then
                            active.warned[threshold] = true
                            notify('Nex Pet System', ('%s is hungry and getting tired (%d%%).'):format(active.data.name, math.floor(active.hunger)), 'warning')
                        end
                    end

                    if active.hunger <= 0 then
                        serverCallback('removeDeadPet', function() end, id)
                        notify('Nex Pet System', active.data.name .. ' died from hunger and was removed from your pets.', 'error')
                        deleteActivePet(id, false)
                    elseif active.hunger <= Config.Hunger.tiredAt then
                        if active.state ~= 'tired' then
                            ClearPedTasks(active.ped)
                            TaskStartScenarioInPlace(active.ped, Config.Hunger.sleepScenario, 0, true)
                            active.state = 'tired'
                        end
                        updatePetServerState(active, false)
                    else
                        if active.state == 'follow' then
                            local dist = #(GetEntityCoords(active.ped) - GetEntityCoords(PlayerPedId()))
                            if dist > 4.0 then ensureFollow(id) end
                        end
                        updatePetServerState(active, false)
                    end
                end
            else
                activePets[id] = nil
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if textUiShown then lib.hideTextUI() end
    for id in pairs(activePets) do deleteActivePet(id, Config.Pet.deleteOnResourceStop) end
    for _, npc in ipairs(shopNPCs) do if DoesEntityExist(npc) then DeleteEntity(npc) end end
end)
