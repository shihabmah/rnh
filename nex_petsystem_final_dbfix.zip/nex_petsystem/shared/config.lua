Config = Config or {}

Config.Debug = false
Config.ResourceName = GetCurrentResourceName()

-- Framework support: auto / qbox / qbcore
Config.Framework = 'auto'

-- Inventory support: auto / ox_inventory / qb / q-inventory
Config.Inventory = 'auto'

Config.Currency = {
    symbol = '$', -- '$' or '€'
    position = 'before' -- before = $5000, after = 5000€
}

Config.Money = {
    account = 'cash', -- cash / bank
    reason = 'nex-petsystem'
}

Config.Database = {
    table = 'nex_player_pets',
    autoCreate = true,
    autoMigrate = true
}

Config.Commands = {
    petMenu = 'petmenu',
    stopAttack = 'stoppetattack'
}

Config.UI = {
    width = 1400,
    height = 850,
    blurBackground = true
}

Config.Shop = {
    enabled = true,
    title = 'Nex Pet Shop',
    interaction = 'target', -- target / textui / marker
    targetSystem = 'auto', -- auto / ox_target / qb-target
    useNPC = true, -- true = spawn NPC for shop, false = use zone/coords only
    fallbackToTextUi = false, -- true = if target is missing, show E-key TextUI fallback
    openDistance = 2.0,
    markerDistance = 18.0,
    markerType = 2,
    markerScale = vec3(0.35, 0.35, 0.35),
    markerColor = { r = 0, g = 145, b = 255, a = 120 },

    supplies = {
        { item = 'dogfood', label = 'Dog Food', category = 'dog', price = 350, image = 'dogfood.png', description = 'Food for dogs only.' },
        { item = 'catfood', label = 'Cat Food', category = 'cat', price = 350, image = 'catfood.png', description = 'Food for cats only.' },
        { item = 'pet_revive_injection', label = 'Pet Revive Injection', category = 'medical', price = 1500, image = 'pet_revive_injection.png', description = 'Revives a dead pet.' }
    },

    locations = {
        {
            id = 'petshop_moreo',
            label = 'Nex Pet Shop - Moreo',
            coords = vec3(233.85, -17.19, 74.99),
            length = 0.8,
            width = 0.6,
            heading = 340.0,
            minZ = 74.79,
            maxZ = 75.59,
            debugPoly = false,

            npc = {
                enabled = true,
                coords = vec4(234.26, -16.5, 73.99, 153.77),
                model = 'a_f_y_business_02',
                scenario = 'WORLD_HUMAN_STAND_IMPATIENT'
            },

            blip = {
                enabled = true,
                sprite = 273,
                color = 38,
                scale = 0.75,
                name = 'Nex Pet Shop',
                shortRange = true
            }
        }
    }
}

Config.Buying = {
    minPrice = 5000,
    maxPrice = 10000,
    onePerPetModel = true
}

Config.Selling = {
    enabled = true,
    minPrice = 1500,
    maxPrice = 3000,
    requireNearShop = true,
    allowSellSpawnedPets = true
}

Config.Pet = {
    spawnDistance = 1.3, -- pet spawns/follows this close to owner
    followDistance = 1.4,
    followSpeed = 3.0,
    maxHealth = 200,
    spawnHealth = 200,
    armor = 0,
    defaultRelationshipGroup = 'NEX_PETS',
    deleteOnResourceStop = true
}

Config.Hunger = {
    enabled = true,
    max = 100,
    feedAmount = 20,
    drainHoursFromFullToZero = 4,
    tickSeconds = 60,
    tiredAt = 10,
    lowWarnings = { 30, 25, 20, 10, 5 },
    sleepScenario = 'WORLD_DOG_SITTING'
}

Config.Progress = {
    type = 'bar', -- bar = ox_lib progressBar, circle = ox_lib progressCircle
    feedSecondsMin = 10,
    feedSecondsMax = 15,
    petSeconds = 5,
    reviveSeconds = 10,
    bringVehicleSeconds = 3,
    disable = { move = true, car = true, combat = true }
}

Config.Items = {
    dogFood = 'dogfood',
    catFood = 'catfood',
    reviveInjection = 'pet_revive_injection',
    rottenQualityAtOrBelow = 0
}

Config.FeedingProps = {
    'prop_ch_donut_01',
    'prop_food_cb_bag_01',
    'prop_food_bs_burger2',
    'prop_food_cb_donuts'
}

Config.Vehicle = {
    enabled = true,
    callDistance = 5.0,
    seatSearch = true,
    enterTimeout = 4500,
    exitOffset = vec3(1.5, -1.0, 0.0)
}

Config.Combat = {
    enabled = true,
    protectOwner = true,
    allowAttackPlayers = true,
    allowAttackNPCs = true,
    nearbyAttackListDistance = 20.0,
    stopCommandStopsAll = true,
    combatTimeoutSeconds = 60
}

Config.QuickRun = {
    enabled = true,
    radius = 10.0,
    durationSeconds = 12,
    speed = 6.0
}

Config.Blips = {
    spawnedPet = {
        enabled = false,
        sprite = 273,
        color = 38,
        scale = 0.55,
        shortRange = false
    }
}

Config.Notifications = {
    position = 'top-right'
}
