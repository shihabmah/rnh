Config = Config or {}

-- Tebex/customer friendly pet list.
-- Add new pets here only. No need to edit client/server logic.
-- componentCount = how many component variations the animal supports.
-- propCount = prop variations; these models currently use 0.
Config.Pets = {
    {
        key = 'westy',
        label = 'Westy',
        category = 'dogs',
        model = 'a_c_westy',
        propCount = 0,
        componentCount = 4,
        buyPrice = 5200,
        sellPrice = 1600,
        image = 'westy.png',
        names = { 'Max', 'Buddy', 'Rocky', 'Milo', 'Charlie', 'Cooper' }
    },
    {
        key = 'shepherd',
        label = 'Shepherd',
        category = 'dogs',
        model = 'a_c_shepherd',
        propCount = 0,
        componentCount = 4,
        buyPrice = 9200,
        sellPrice = 2800,
        image = 'shepherd.png',
        names = { 'Rex', 'Diesel', 'Ace', 'Shadow', 'Hunter', 'Major' }
    },
    {
        key = 'retriever',
        label = 'Retriever',
        category = 'dogs',
        model = 'a_c_retriever',
        propCount = 0,
        componentCount = 5,
        buyPrice = 7600,
        sellPrice = 2300,
        image = 'retriever.png',
        names = { 'Bailey', 'Lucky', 'Sunny', 'Teddy', 'Benji', 'Goldie' }
    },
    {
        key = 'rottweiler',
        label = 'Rottweiler',
        category = 'dogs',
        model = 'a_c_rottweiler',
        propCount = 0,
        componentCount = 4,
        buyPrice = 10000,
        sellPrice = 3000,
        image = 'rottweiler.png',
        names = { 'Bruno', 'Tank', 'Kane', 'Rocco', 'Bear', 'Zeus' }
    },
    {
        key = 'rottweiler_02',
        label = 'Rottweiler 02',
        category = 'dogs',
        model = 'a_c_rottweiler_02',
        propCount = 0,
        componentCount = 4,
        buyPrice = 9800,
        sellPrice = 2900,
        image = 'rottweiler2.png',
        names = { 'Duke', 'Boss', 'Axel', 'Thor', 'King', 'Titan' }
    },
    {
        key = 'pug',
        label = 'Pug',
        category = 'dogs',
        model = 'a_c_pug',
        propCount = 0,
        componentCount = 4,
        buyPrice = 6100,
        sellPrice = 1800,
        image = 'pug.png',
        names = { 'Pablo', 'Peanut', 'Winston', 'Otis', 'Biscuit', 'Nugget' }
    },
    {
        key = 'husky',
        label = 'Husky',
        category = 'dogs',
        model = 'a_c_husky',
        propCount = 0,
        componentCount = 3,
        buyPrice = 8800,
        sellPrice = 2600,
        image = 'husky.png',
        names = { 'Luna', 'Ghost', 'Koda', 'Storm', 'Nova', 'Sky' }
    },
    {
        key = 'chop',
        label = 'Chop',
        category = 'dogs',
        model = 'a_c_chop',
        propCount = 0,
        componentCount = 4,
        buyPrice = 9500,
        sellPrice = 2700,
        image = 'chop.png',
        names = { 'Chop', 'Buster', 'Bolt', 'Chief', 'Maverick', 'Champ' }
    },
    {
        key = 'cat_01',
        label = 'Cat',
        category = 'cats',
        model = 'a_c_cat_01',
        propCount = 0,
        componentCount = 3,
        buyPrice = 5400,
        sellPrice = 1600,
        image = 'cat01.png',
        names = { 'Mochi', 'Mittens', 'Loki', 'Coco', 'Simba', 'Nala' }
    },
    {
        key = 'cat_02',
        label = 'Cat 02',
        category = 'cats',
        model = 'a_c_cat_02',
        propCount = 0,
        componentCount = 3,
        buyPrice = 6800,
        sellPrice = 2000,
        image = 'cat02.png',
        names = { 'Leo', 'Misty', 'Oreo', 'Pumpkin', 'Shadow', 'Willow' }
    }
}

function NexPet_GetPetConfig(key)
    for _, pet in ipairs(Config.Pets) do
        if pet.key == key then return pet end
    end
end

function NexPet_GetPetByModel(model)
    for _, pet in ipairs(Config.Pets) do
        if joaat and joaat(pet.model) == model or pet.model == model then return pet end
    end
end
