-- Add these to ox_inventory/data/items.lua
['dogfood'] = {
    label = 'Dog Food',
    weight = 250,
    stack = true,
    close = true,
    description = 'Fresh food for dogs.',
    client = { image = 'dogfood.png' }
},

['catfood'] = {
    label = 'Cat Food',
    weight = 250,
    stack = true,
    close = true,
    description = 'Fresh food for cats.',
    client = { image = 'catfood.png' }
},

['pet_revive_injection'] = {
    label = 'Pet Revive Injection',
    weight = 200,
    stack = true,
    close = true,
    description = 'Medicine used to revive a dead pet.',
    client = { image = 'pet_revive_injection.png' }
},
