-- Add these to qb-core/shared/items.lua or q-inventory item config
['dogfood'] = {
    name = 'dogfood',
    label = 'Dog Food',
    weight = 250,
    type = 'item',
    image = 'dogfood.png',
    unique = false,
    useable = false,
    shouldClose = true,
    combinable = nil,
    description = 'Fresh food for dogs.'
},

['catfood'] = {
    name = 'catfood',
    label = 'Cat Food',
    weight = 250,
    type = 'item',
    image = 'catfood.png',
    unique = false,
    useable = false,
    shouldClose = true,
    combinable = nil,
    description = 'Fresh food for cats.'
},

['pet_revive_injection'] = {
    name = 'pet_revive_injection',
    label = 'Pet Revive Injection',
    weight = 200,
    type = 'item',
    image = 'pet_revive_injection.png',
    unique = false,
    useable = false,
    shouldClose = true,
    combinable = nil,
    description = 'Medicine used to revive a dead pet.'
},
