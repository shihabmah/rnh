local dbReady = false
local QBCore = nil
math.randomseed(os.time())

local function dprint(...)
    if Config.Debug then print('[nex_petsystem:server]', ...) end
end

local function notify(src, title, description, nType)
    TriggerClientEvent('nex_petsystem:client:notify', src, title or 'Nex Pet System', description or '', nType or 'inform')
end

local function fmtMoney(amount)
    amount = tonumber(amount) or 0
    if Config.Currency.position == 'after' then
        return tostring(amount) .. Config.Currency.symbol
    end
    return Config.Currency.symbol .. tostring(amount)
end

local function getFramework()
    if Config.Framework ~= 'auto' then return Config.Framework end
    if GetResourceState('qbx_core') == 'started' then return 'qbox' end
    if GetResourceState('qb-core') == 'started' then return 'qbcore' end
    return 'standalone'
end

local function getQB()
    if not QBCore and GetResourceState('qb-core') == 'started' then
        local ok, core = pcall(function() return exports['qb-core']:GetCoreObject() end)
        if ok then QBCore = core end
    end
    return QBCore
end

local function getPlayer(src)
    local fw = getFramework()
    if fw == 'qbox' then
        local ok, player = pcall(function() return exports.qbx_core:GetPlayer(src) end)
        if ok and player then return player, 'qbox' end
    end

    if fw == 'qbcore' or GetResourceState('qb-core') == 'started' then
        local core = getQB()
        if core and core.Functions then
            local player = core.Functions.GetPlayer(src)
            if player then return player, 'qbcore' end
        end
    end

    return nil, fw
end

local function getIdentifier(src)
    local player = getPlayer(src)
    if player and player.PlayerData then
        if player.PlayerData.citizenid then return player.PlayerData.citizenid end
        if player.PlayerData.citizenId then return player.PlayerData.citizenId end
    end

    for _, identifier in ipairs(GetPlayerIdentifiers(src)) do
        if identifier:find('license:', 1, true) then return identifier end
    end
    return ('source:%s'):format(src)
end

local function removeMoney(src, amount)
    amount = tonumber(amount) or 0
    if amount <= 0 then return true end

    local player, fw = getPlayer(src)
    if player and player.Functions and player.Functions.RemoveMoney then
        local ok, result = pcall(function()
            return player.Functions.RemoveMoney(Config.Money.account, amount, Config.Money.reason)
        end)
        if ok then return result ~= false end
    end

    if fw == 'qbox' and GetResourceState('qbx_core') == 'started' then
        local ok, result = pcall(function()
            return exports.qbx_core:RemoveMoney(src, Config.Money.account, amount, Config.Money.reason)
        end)
        if ok then return result ~= false end
    end

    return false
end

local function addMoney(src, amount)
    amount = tonumber(amount) or 0
    if amount <= 0 then return true end

    local player, fw = getPlayer(src)
    if player and player.Functions and player.Functions.AddMoney then
        local ok, result = pcall(function()
            return player.Functions.AddMoney(Config.Money.account, amount, Config.Money.reason)
        end)
        if ok then return result ~= false end
    end

    if fw == 'qbox' and GetResourceState('qbx_core') == 'started' then
        local ok, result = pcall(function()
            return exports.qbx_core:AddMoney(src, Config.Money.account, amount, Config.Money.reason)
        end)
        if ok then return result ~= false end
    end

    return false
end

local function inventoryType()
    if Config.Inventory ~= 'auto' then return Config.Inventory end
    if GetResourceState('ox_inventory') == 'started' then return 'ox_inventory' end
    if GetResourceState('qb-inventory') == 'started' then return 'qb' end
    if GetResourceState('q-inventory') == 'started' then return 'qb' end
    return 'none'
end

local function getQuality(itemData)
    if not itemData then return 100 end
    local metadata = itemData.metadata or itemData.info or {}
    local quality = metadata.quality or metadata.durability or itemData.quality
    if quality == nil then return 100 end
    return tonumber(quality) or 0
end

local function addInventoryItem(src, item, count)
    count = tonumber(count) or 1
    local inv = inventoryType()

    if inv == 'ox_inventory' then
        local ok, result = pcall(function()
            return exports.ox_inventory:AddItem(src, item, count)
        end)
        return ok and result ~= false
    end

    local player = getPlayer(src)
    if player and player.Functions and player.Functions.AddItem then
        local ok, result = pcall(function() return player.Functions.AddItem(item, count) end)
        if ok and result ~= false then
            return true
        end
    end

    return false
end

local function removeInventoryItem(src, item, count, checkQuality)
    count = tonumber(count) or 1
    local inv = inventoryType()

    if inv == 'ox_inventory' then
        local ok, slots = pcall(function()
            return exports.ox_inventory:Search(src, 'slots', item)
        end)
        if not ok or type(slots) ~= 'table' then return false, 'missing' end

        local rottenFound = false
        for _, slotData in pairs(slots) do
            if slotData and (slotData.count or slotData.amount or 0) >= count then
                local quality = getQuality(slotData)
                if checkQuality and quality <= Config.Items.rottenQualityAtOrBelow then
                    rottenFound = true
                else
                    local slot = slotData.slot
                    local removedOk, removed = pcall(function()
                        return exports.ox_inventory:RemoveItem(src, item, count, nil, slot)
                    end)
                    return removedOk and removed ~= false, removedOk and nil or 'missing'
                end
            end
        end

        if rottenFound then return false, 'rotten' end
        return false, 'missing'
    end

    local player = getPlayer(src)
    if player and player.Functions then
        local itemData
        if player.Functions.GetItemByName then
            itemData = player.Functions.GetItemByName(item)
        end
        if not itemData then return false, 'missing' end
        if checkQuality and getQuality(itemData) <= Config.Items.rottenQualityAtOrBelow then
            return false, 'rotten'
        end
        if player.Functions.RemoveItem then
            local slot = itemData.slot
            local ok, result = pcall(function() return player.Functions.RemoveItem(item, count, slot) end)
            if ok and result ~= false then
                return true
            end
        end
    end

    return false, 'missing'
end

local function sqlReady()
    return MySQL and MySQL.query and MySQL.query.await
end

local function ensureDatabase()
    if dbReady then return true end
    if not sqlReady() then
        print('[nex_petsystem] oxmysql is not ready. Make sure ensure oxmysql is before nex_petsystem.')
        return false
    end

    local tableName = Config.Database.table or 'nex_player_pets'

    if Config.Database.autoCreate then
        local createSql = ([[
            CREATE TABLE IF NOT EXISTS `%s` (
                `id` INT NOT NULL AUTO_INCREMENT,
                `identifier` VARCHAR(80) NOT NULL,
                `pet_key` VARCHAR(60) NOT NULL,
                `pet_name` VARCHAR(60) NOT NULL,
                `category` VARCHAR(20) NOT NULL,
                `model` VARCHAR(80) NOT NULL,
                `component` INT NOT NULL DEFAULT 0,
                `prop` INT NOT NULL DEFAULT 0,
                `hunger` FLOAT NOT NULL DEFAULT 100,
                `health` INT NOT NULL DEFAULT 200,
                `dead` TINYINT(1) NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `unique_pet_per_player` (`identifier`, `pet_key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ]]):format(tableName)

        local ok, err = pcall(function()
            MySQL.query.await(createSql)
        end)

        if not ok then
            print(('[nex_petsystem] Database create failed for table %s: %s'):format(tableName, tostring(err)))
            print('[nex_petsystem] Import sql/install.sql manually or check your oxmysql connection string.')
            return false
        end
    end

    if Config.Database.autoMigrate then
        local function hasColumn(column)
            local ok, result = pcall(function()
                return MySQL.query.await(('SHOW COLUMNS FROM `%s` LIKE ?'):format(tableName), { column })
            end)
            return ok and result and result[1] ~= nil
        end

        local columns = {
            component = '`component` INT NOT NULL DEFAULT 0',
            prop = '`prop` INT NOT NULL DEFAULT 0',
            hunger = '`hunger` FLOAT NOT NULL DEFAULT 100',
            health = '`health` INT NOT NULL DEFAULT 200',
            dead = '`dead` TINYINT(1) NOT NULL DEFAULT 0',
            created_at = '`created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP'
        }

        for column, definition in pairs(columns) do
            if not hasColumn(column) then
                local ok, err = pcall(function()
                    MySQL.query.await(('ALTER TABLE `%s` ADD COLUMN %s'):format(tableName, definition))
                end)
                if not ok then
                    print(('[nex_petsystem] Migration warning: could not add column %s: %s'):format(column, tostring(err)))
                end
            end
        end

        pcall(function()
            MySQL.query.await(('ALTER TABLE `%s` ADD UNIQUE KEY `unique_pet_per_player` (`identifier`, `pet_key`)'):format(tableName))
        end)
    end

    dbReady = true
    print('[nex_petsystem] Database ready: ' .. tableName)
    return true
end

local function sanitizeRow(row)
    if not row then return nil end
    local petCfg = NexPet_GetPetConfig(row.pet_key)
    return {
        id = tonumber(row.id),
        petKey = row.pet_key,
        label = petCfg and petCfg.label or row.pet_key,
        category = row.category,
        model = row.model,
        name = row.pet_name,
        image = petCfg and petCfg.image or 'pet.png',
        sellPrice = petCfg and petCfg.sellPrice or Config.Selling.minPrice,
        hunger = math.max(0, math.min(100, math.floor((tonumber(row.hunger) or 100) + 0.5))),
        health = tonumber(row.health) or Config.Pet.spawnHealth,
        dead = tonumber(row.dead) == 1,
        component = tonumber(row.component) or 0,
        prop = tonumber(row.prop) or 0
    }
end

local function getOwnedRows(identifier)
    if not ensureDatabase() then return {} end
    return MySQL.query.await(('SELECT * FROM `%s` WHERE `identifier` = ? ORDER BY `id` ASC'):format(Config.Database.table), { identifier }) or {}
end

local function getOwnedPets(src)
    local identifier = getIdentifier(src)
    local rows = getOwnedRows(identifier)
    local owned = {}
    local keys = {}
    for _, row in ipairs(rows) do
        local item = sanitizeRow(row)
        owned[#owned + 1] = item
        keys[item.petKey] = true
    end
    return owned, keys
end

local callbacks = {}
local function registerCallback(name, cb)
    callbacks[name] = cb
end

RegisterNetEvent('nex_petsystem:server:callback', function(name, requestId, ...)
    local src = source
    local cb = callbacks[name]
    if not cb then
        TriggerClientEvent('nex_petsystem:client:callback', src, requestId, false, ('Missing server callback: %s'):format(name))
        return
    end

    local ok, result = pcall(cb, src, ...)
    if not ok then
        print(('[nex_petsystem] callback error %s: %s'):format(name, result))
        TriggerClientEvent('nex_petsystem:client:callback', src, requestId, false, result)
        return
    end

    TriggerClientEvent('nex_petsystem:client:callback', src, requestId, true, result)
end)

registerCallback('getShopData', function(src)
    if not ensureDatabase() then
        return { ok = false, error = 'Database is not ready. Check oxmysql/server console.' }
    end

    local owned, keys = getOwnedPets(src)
    return {
        ok = true,
        title = Config.Shop.title,
        pets = Config.Pets,
        owned = owned,
        ownedKeys = keys,
        supplies = Config.Shop.supplies,
        currency = Config.Currency,
        sellingEnabled = Config.Selling.enabled
    }
end)

registerCallback('getPetMenuData', function(src)
    if not ensureDatabase() then
        return { ok = false, error = 'Database is not ready. Check oxmysql/server console.' }
    end
    local owned = getOwnedPets(src)
    return { ok = true, owned = owned, currency = Config.Currency }
end)

registerCallback('buyPet', function(src, petKey)
    if not ensureDatabase() then return { ok = false, message = 'Database is not ready.' } end
    local pet = NexPet_GetPetConfig(petKey)
    if not pet then return { ok = false, message = 'Invalid pet.' } end

    local identifier = getIdentifier(src)
    local existing = MySQL.scalar.await(('SELECT `id` FROM `%s` WHERE `identifier` = ? AND `pet_key` = ? LIMIT 1'):format(Config.Database.table), { identifier, petKey })
    if existing then return { ok = false, message = 'You already own this pet.' } end

    local price = tonumber(pet.buyPrice) or Config.Buying.minPrice
    if price < Config.Buying.minPrice or price > Config.Buying.maxPrice then
        price = math.max(Config.Buying.minPrice, math.min(Config.Buying.maxPrice, price))
    end

    if not removeMoney(src, price) then
        return { ok = false, message = ('Not enough money. Required %s.'):format(fmtMoney(price)) }
    end

    local names = pet.names or { pet.label }
    local petName = names[math.random(1, #names)]
    local component = 0
    if (pet.componentCount or 0) > 0 then component = math.random(0, pet.componentCount - 1) end

    local insertId = MySQL.insert.await(([[
        INSERT INTO `%s` (`identifier`, `pet_key`, `pet_name`, `category`, `model`, `component`, `prop`, `hunger`, `health`, `dead`)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]]):format(Config.Database.table), {
        identifier, pet.key, petName, pet.category, pet.model, component, 0, Config.Hunger.max, Config.Pet.spawnHealth, 0
    })

    notify(src, 'Nex Pet Shop', ('You bought %s for %s.'):format(petName, fmtMoney(price)), 'success')
    return { ok = true, id = insertId, message = ('You bought %s.'):format(petName), owned = getOwnedPets(src) }
end)

registerCallback('sellPet', function(src, petId, nearShop)
    if not ensureDatabase() then return { ok = false, message = 'Database is not ready.' } end
    if Config.Selling.requireNearShop and not nearShop then
        return { ok = false, message = 'You must be near a pet shop to sell pets.' }
    end

    local identifier = getIdentifier(src)
    local row = MySQL.single.await(('SELECT * FROM `%s` WHERE `id` = ? AND `identifier` = ? LIMIT 1'):format(Config.Database.table), { petId, identifier })
    if not row then return { ok = false, message = 'Pet not found.' } end
    local pet = NexPet_GetPetConfig(row.pet_key)
    local price = pet and tonumber(pet.sellPrice) or Config.Selling.minPrice
    price = math.max(Config.Selling.minPrice, math.min(Config.Selling.maxPrice, price))

    MySQL.query.await(('DELETE FROM `%s` WHERE `id` = ? AND `identifier` = ?'):format(Config.Database.table), { petId, identifier })
    addMoney(src, price)

    notify(src, 'Nex Pet Shop', ('You sold %s for %s.'):format(row.pet_name or 'your pet', fmtMoney(price)), 'success')
    return { ok = true, message = ('Pet sold for %s.'):format(fmtMoney(price)), owned = getOwnedPets(src) }
end)

registerCallback('buySupply', function(src, itemName)
    local supply
    for _, item in ipairs(Config.Shop.supplies) do
        if item.item == itemName then supply = item break end
    end
    if not supply then return { ok = false, message = 'Invalid shop item.' } end

    local price = tonumber(supply.price) or 0
    if not removeMoney(src, price) then
        return { ok = false, message = ('Not enough money. Required %s.'):format(fmtMoney(price)) }
    end

    if not addInventoryItem(src, supply.item, 1) then
        addMoney(src, price)
        return { ok = false, message = 'Inventory error. Money refunded.' }
    end

    notify(src, 'Nex Pet Shop', ('You bought %s for %s.'):format(supply.label, fmtMoney(price)), 'success')
    return { ok = true, message = ('You bought %s.'):format(supply.label) }
end)

registerCallback('updatePetState', function(src, petId, hunger, health, dead)
    if not ensureDatabase() then return { ok = false } end
    local identifier = getIdentifier(src)
    hunger = math.max(0, math.min(100, tonumber(hunger) or 100))
    health = math.max(0, math.min(Config.Pet.maxHealth, tonumber(health) or Config.Pet.spawnHealth))
    dead = dead and 1 or 0
    MySQL.query.await(('UPDATE `%s` SET `hunger` = ?, `health` = ?, `dead` = ? WHERE `id` = ? AND `identifier` = ?'):format(Config.Database.table), { hunger, health, dead, petId, identifier })
    return { ok = true }
end)

registerCallback('removeDeadPet', function(src, petId)
    if not ensureDatabase() then return { ok = false } end
    local identifier = getIdentifier(src)
    MySQL.query.await(('DELETE FROM `%s` WHERE `id` = ? AND `identifier` = ?'):format(Config.Database.table), { petId, identifier })
    return { ok = true }
end)

registerCallback('feedPet', function(src, petId, category, currentHunger)
    local item = category == 'cats' and Config.Items.catFood or Config.Items.dogFood
    local ok, reason = removeInventoryItem(src, item, 1, true)
    if not ok then
        if reason == 'rotten' then
            return { ok = false, reason = 'rotten', message = 'Your pet does not like rotten pet food.' }
        end
        return { ok = false, reason = 'missing', message = ('You need %s.'):format(item) }
    end

    currentHunger = tonumber(currentHunger) or Config.Hunger.max
    local newHunger = math.min(Config.Hunger.max, currentHunger + Config.Hunger.feedAmount)
    if ensureDatabase() then
        local identifier = getIdentifier(src)
        MySQL.query.await(('UPDATE `%s` SET `hunger` = ? WHERE `id` = ? AND `identifier` = ?'):format(Config.Database.table), { newHunger, petId, identifier })
    end
    return { ok = true, hunger = newHunger, message = 'Your pet has been fed.' }
end)

registerCallback('revivePet', function(src, petId)
    local ok, reason = removeInventoryItem(src, Config.Items.reviveInjection, 1, true)
    if not ok then
        if reason == 'rotten' then
            return { ok = false, message = 'This revive injection is expired.' }
        end
        return { ok = false, message = ('You need %s.'):format(Config.Items.reviveInjection) }
    end

    local hunger = math.max(50, Config.Hunger.tiredAt + 20)
    if ensureDatabase() then
        local identifier = getIdentifier(src)
        MySQL.query.await(('UPDATE `%s` SET `hunger` = ?, `health` = ?, `dead` = 0 WHERE `id` = ? AND `identifier` = ?'):format(Config.Database.table), { hunger, Config.Pet.spawnHealth, petId, identifier })
    end
    return { ok = true, hunger = hunger, health = Config.Pet.spawnHealth, message = 'Your pet has been revived.' }
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    CreateThread(function()
        Wait(1000)
        local ok, err = pcall(ensureDatabase)
        if not ok then print('[nex_petsystem] Database init failed: ' .. tostring(err)) end
    end)
end)
