# nex_petsystem

Premium blue pet shop + companion system for Qbox and QB-Core.

## Ensure order

```cfg
ensure oxmysql
ensure ox_lib
ensure ox_target # or qb-target
ensure ox_inventory # or qb/q-inventory
ensure qbx_core # or qb-core
ensure nex_petsystem
```

## Database

## Fixed database note

This build fixes the previous shop-data error caused by a duplicate `model` column in `server/server.lua`. If you already imported an older broken build, restart `oxmysql` and `nex_petsystem`; the script will auto-create/migrate the table. You can also import `sql/install.sql` manually.


The script auto-creates and auto-migrates the table when `Config.Database.autoCreate = true`.
You can also import:

```txt
nex_petsystem/sql/install.sql
```

## Main config files

```txt
shared/config.lua  -- shops, NPCs, framework/inventory, hunger, vehicle, progress, currency
shared/pets.lua    -- pet models, prices, sell prices, images, component count, random names
```

Customers only need to edit these two shared files to add new pets or shop locations.

## Commands

```txt
/petmenu
/stoppetattack
```

There is no `/pedmenu` command.

## Shop modes

```lua
Config.Shop.interaction = 'target' -- target / textui / marker
Config.Shop.targetSystem = 'auto'  -- auto / ox_target / qb-target
Config.Shop.useNPC = true          -- true = NPC shop clerk, false = zone location
```

Default NPC location:

```lua
coords = vec4(234.26, -16.5, 73.99, 153.77)
```

Default shop id:

```lua
id = 'petshop_moreo'
```

If `interaction = 'target'`, no marker is drawn. If the target resource is missing and `fallbackToTextUi = true`, the script falls back to E-key TextUI.

## Items

Add item snippets from:

```txt
inventory/ox_inventory_items.lua
inventory/qb_q_inventory_items.lua
```

Copy item images from:

```txt
inventory/images/
```

## Features included

- Nex Pet Shop 1400x850 responsive minimal blue NUI
- Buy pets by dogs/cats category
- Sell owned pets for configurable sell prices
- Buy dog food, cat food, and revive injection from shop
- Confirmation popup for buy and sell with configurable currency display
- One owned copy per pet model; after sell, same model can be bought again
- `/petmenu` with owned pets, hunger status, call/bring back/vehicle actions
- Pet follows by default after spawning
- Hunger drains only while pet is spawned in world
- Dogs only eat dogfood, cats only eat catfood
- Rotten/0% quality food is rejected
- Feeding uses ox_lib progress bar, crouch animation, and random food prop
- Petting and reviving use crouch animation/progress
- Dead pets can be revived with pet revive injection if body exists
- Hunger 0 removes the pet from owned list so it can be bought again
- Pets protect owner if owner is attacked by player/NPC
- Attack nearby player list and `/stoppetattack`
- Bring pet into/out of vehicle, plus /petmenu Take Out button when pet is in car
- Quick Run action instead of broken jump action
- Qbox/QB-Core framework support
- ox_inventory/QB/q-inventory item support
- ox_target/qb-target support
