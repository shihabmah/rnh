CREATE TABLE IF NOT EXISTS `nex_player_pets` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(80) NOT NULL,
    `pet_key` VARCHAR(60) NOT NULL,
    `pet_name` VARCHAR(60) NOT NULL,
    `category` VARCHAR(20) NOT NULL,
    `model` VARCHAR(80) NOT NULL,
    `component` INT NOT NULL DEFAULT 0,
    `prop` INT NOT NULL DEFAULT 0,
    `hunger` FLOAT NOT NULL DEFAULT 100,
    `health` INT NOT NULL DEFAULT 200,
    `dead` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_pet_per_player` (`identifier`, `pet_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
