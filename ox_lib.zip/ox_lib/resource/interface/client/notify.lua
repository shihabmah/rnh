--[[
    https://github.com/overextended/ox_lib

    This file is licensed under LGPL-3.0 or higher <https://www.gnu.org/licenses/lgpl-3.0.en.html>

    Copyright © 2025 Linden <https://github.com/thelindat>
]]

---@alias NotificationPosition 'top' | 'top-right' | 'top-left' | 'bottom' | 'bottom-right' | 'bottom-left' | 'center-right' | 'center-left'
---@alias NotificationType 'info' | 'warning' | 'success' | 'error'
---@alias IconAnimationType 'spin' | 'spinPulse' | 'spinReverse' | 'pulse' | 'beat' | 'fade' | 'beatFade' | 'bounce' | 'shake'

---@class NotifyProps
---@field id? string
---@field title? string
---@field description? string
---@field duration? number
---@field showDuration? boolean
---@field position? NotificationPosition
---@field type? NotificationType
---@field style? { [string]: any }
---@field icon? string | { [1]: IconProp, [2]: string }
---@field iconAnimation? IconAnimationType
---@field iconColor? string
---@field alignIcon? 'top' | 'center'
---@field sound? { bank?: string, set: string, name: string }

local settings = require 'resource.settings'

---`client`
---@param data NotifyProps
---@diagnostic disable-next-line: duplicate-set-field

--Default Notify
-- function lib.notify(data)
--     local sound = settings.notification_audio and data.sound
--     data.sound = nil
--     data.position = data.position or settings.notification_position

--     SendNUIMessage({
--         action = 'notify',
--         data = data
--     })

--     if not sound then return end

--     if sound.bank then lib.requestAudioBank(sound.bank) end

--     local soundId = GetSoundId()
--     PlaySoundFrontend(soundId, sound.name, sound.set, true)
--     ReleaseSoundId(soundId)

--     if sound.bank then ReleaseNamedScriptAudioBank(sound.bank) end
-- end
--Default Notify End

-- MS Nex Notify
-- function lib.notify(data)
--     -- 1. Prepare the Data for ms-nexnotify
--     local notifyType = data.type or 'info'
    
--     if notifyType == 'inform' then notifyType = 'info' end

--     local duration = data.duration or 5000

--     -- 2. Logic to handle Title vs Description
--     local msgData = {
--         text = data.description,
--         caption = data.title
--     }

--     if not data.description and data.title then
--         msgData.text = data.title
--         msgData.caption = nil
--     end
    
--     if not msgData.text then msgData.text = "Notification" end

--     -- 3. Send to ms-nexnotify via Export
--     local success, err = pcall(function()
--         -- UPDATED NAME HERE:
--         exports['ms-nexnotify']:notify(msgData, notifyType, duration)
--     end)

--     if not success then
--         print('^1[ox_lib ERROR] Failed to redirect notification to ms-nexnotify. Is the resource started?^0')
--     end
-- end
-- MS Nex Notify End

--Wasabi Notify
function lib.notify(data)
    if data.type == 'inform' then data.type = 'info' end

    if data.position == 'top' or data.position == 'bottom' or
    data.position == 'bottom-right' or
    data.position == 'bottom-left' then
        data.position = 'center'
    end

    if data.position == 'center-right' then data.position = 'right' end
    if data.position == 'center-left' then data.position = 'left' end

    exports.wasabi_notify:advancedNotify({
        type = data.type,
        customType = data.iconColor and { color = data.iconColor, color2 = data.iconColor } or false,
        id = data.id or false,
        title = data.title,
        description = data.description,
        duration = data.duration,
        position = data.position,
        icon = data.icon,
        iconAnimation = data.iconAnimation and 'pulse' or false,
    })
end
--Wadabi Notify End

---@class DefaultNotifyProps
---@field title? string
---@field description? string
---@field duration? number
---@field position? NotificationPosition
---@field status? 'info' | 'warning' | 'success' | 'error'
---@field id? number

---@param data DefaultNotifyProps
function lib.defaultNotify(data)
    -- Backwards compat for v3
    data.type = data.status
    if data.type == 'inform' then data.type = 'info' end
    return lib.notify(data --[[@as NotifyProps]])
end

RegisterNetEvent('ox_lib:notify', lib.notify)
RegisterNetEvent('ox_lib:defaultNotify', lib.defaultNotify)