<?php
/**
 * @version    1.0
 * @package    zota
 * @author     Thembay Team <thembayteam@gmail.com>
 * @copyright  Copyright (C) 2021 Thembay.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: https://thembay.com
 */

add_action('wp_enqueue_scripts', 'zota_child_enqueue_styles', 10000);
function zota_child_enqueue_styles() {
	$parent_style = 'zota-style';
	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'zota-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get('Version')
    );
}