<?php

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

require_once ROOTDIR . '/modules/servers/hetznerstoragebox/lib/PricingEngine.php';
require_once ROOTDIR . '/modules/servers/hetznerstoragebox/lib/HetznerClient.php';
require_once ROOTDIR . '/modules/servers/hetznerstoragebox/lib/Common.php';

use HetznerStorageBox\Common;
use HetznerStorageBox\PricingEngine;
use Illuminate\Database\Capsule\Manager as Capsule;

function hetznerstoragebox_manager_config()
{
    return [
        'name' => 'Hetzner Storage Box Manager',
        'description' => 'Catalog sync, pricing automation, monitoring, and product defaults for the Hetzner Storage Box WHMCS module.',
        'author' => 'Codex',
        'language' => 'english',
        'version' => '1.0.0',
        'fields' => [
            'global_api_token' => [
                'FriendlyName' => 'Hetzner API Token',
                'Type' => 'password',
                'Size' => '64',
                'Description' => 'Global fallback API token used when the assigned server has no token.',
            ],
            'source_currency_code' => [
                'FriendlyName' => 'Catalog Currency Code',
                'Type' => 'text',
                'Size' => '8',
                'Default' => 'EUR',
                'Description' => 'Currency code matching the Hetzner project owner account, for example EUR.',
            ],
            'ready_email_template' => [
                'FriendlyName' => 'Ready Email Template',
                'Type' => 'text',
                'Size' => '64',
                'Default' => 'Product/Service Welcome Email',
                'Description' => 'Provisioning email template name.',
            ],
            'hold_email_template' => [
                'FriendlyName' => 'Hold Email Template',
                'Type' => 'text',
                'Size' => '64',
                'Default' => 'Service Suspension Notification',
                'Description' => 'Suspension email template name.',
            ],
            'completed_email_template' => [
                'FriendlyName' => 'Completed Email Template',
                'Type' => 'text',
                'Size' => '64',
                'Default' => 'Service Cancellation Request Confirmation',
                'Description' => 'Template sent for normal service completion.',
            ],
            'terminated_email_template' => [
                'FriendlyName' => 'Terminated Email Template',
                'Type' => 'text',
                'Size' => '64',
                'Default' => 'Service Cancellation Request Confirmation',
                'Description' => 'Template sent for non-normal termination.',
            ],
        ],
    ];
}

function hetznerstoragebox_manager_activate()
{
    Common::ensureSchema();
    return ['status' => 'success'];
}

function hetznerstoragebox_manager_deactivate()
{
    return ['status' => 'success'];
}

function hetznerstoragebox_manager_output($vars)
{
    Common::ensureSchema();

    if (isset($_GET['sbxAjax'])) {
        hetznerstoragebox_manager_handle_ajax();
        exit;
    }

    $products = Capsule::table('tblproducts')
        ->join('tblproductgroups', 'tblproducts.gid', '=', 'tblproductgroups.id')
        ->where('tblproducts.servertype', Common::SERVER_MODULE)
        ->select('tblproducts.id', 'tblproducts.name', 'tblproductgroups.name as group_name')
        ->orderBy('tblproductgroups.order', 'asc')
        ->orderBy('tblproducts.order', 'asc')
        ->orderBy('tblproducts.name', 'asc')
        ->get();

    $selectedProductId = isset($_GET['product_id']) ? (int) $_GET['product_id'] : 0;
    if ($selectedProductId <= 0 && isset($products[0])) {
        $selectedProductId = (int) $products[0]->id;
    }

    $selectedConfig = $selectedProductId > 0 ? Common::loadProductConfig($selectedProductId) : Common::defaultProductConfig();
    $catalogItems = Common::getCatalogItems();
    $currencies = Common::getWhmcsCurrencies();
    $locationOptions = hetznerstoragebox_manager_locations($catalogItems);
    $previewHtml = '';

    if ($selectedProductId > 0 && !empty($catalogItems)) {
        try {
            $previewHtml = hetznerstoragebox_manager_render_preview(Common::buildPricingPreview($selectedProductId));
        } catch (\Throwable $exception) {
            $previewHtml = '<div class="sbxm-notice error">' . htmlspecialchars($exception->getMessage()) . '</div>';
        }
    }

    $moduleLink = !empty($vars['modulelink'])
        ? (string) $vars['modulelink']
        : 'addonmodules.php?module=hetznerstoragebox_manager';

    if (strpos($moduleLink, 'token=') === false && !empty($_REQUEST['token'])) {
        $moduleLink .= '&token=' . urlencode((string) $_REQUEST['token']);
    }

    $baseUrl = $moduleLink;
    
    echo '<style>
        .sbxm-shell { font-family: inherit; color: #1f2937; width: 100%; box-sizing: border-box; font-size: 14px; }
        .sbxm-card { background: #fff; border: 1px solid #d0d7de; border-radius: 4px; padding: 20px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
        .sbxm-grid { display: grid; grid-template-columns: 1.1fr 0.9fr; gap: 20px; }
        .sbxm-row { display: grid; grid-template-columns: 200px 1fr; gap: 15px; align-items: center; margin-bottom: 15px; }
        .sbxm-row label { font-weight: 600; color: #374151; font-size: 14px; }
        .sbxm-row input[type=text], .sbxm-row input[type=number], .sbxm-row select, .sbxm-row textarea { width: 100%; padding: 10px 12px; border: 1px solid #c8d1dc; border-radius: 4px; transition: border-color 0.2s; outline: none; box-sizing: border-box; font-size: 14px; }
        .sbxm-row input:focus, .sbxm-row select:focus { border-color: #0f75bd; box-shadow: 0 0 0 3px rgba(15, 117, 189, 0.1); }
        .sbxm-checks { display: flex; gap: 10px; flex-wrap: wrap; }
        .sbxm-checks label { border: 1px solid #d0d7de; padding: 8px 12px; border-radius: 4px; background: #f9fafb; cursor: pointer; transition: 0.2s; display: flex; align-items: center; gap: 8px; font-size: 14px; }
        .sbxm-checks label:hover { background: #f3f4f6; border-color: #9ca3af; }
        .sbxm-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 20px; }
        .sbxm-btn { background: #0f75bd; color: #fff; border: 1px solid #0f75bd; padding: 12px 24px; border-radius: 4px; cursor: pointer; font-weight: 600; transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; font-size: 14px; }
        .sbxm-btn:hover:not(:disabled) { background: #0c5e99; border-color: #0c5e99; color: #fff; text-decoration: none; }
        .sbxm-btn:disabled { opacity: 0.6; cursor: not-allowed; }
        .sbxm-btn.alt { background: #fff; color: #0f75bd; }
        .sbxm-btn.alt:hover:not(:disabled) { background: #f0f7ff; }
        .sbxm-btn.warn { background: #fff; color: #d9822b; border-color: #d9822b; }
        .sbxm-btn.warn:hover:not(:disabled) { background: #fff5eb; }
        .sbxm-notice { padding: 14px 18px; border-radius: 4px; margin-bottom: 20px; border: 1px solid transparent; font-weight: 500; display: none; font-size: 14px; }
        .sbxm-notice.success { background: #eef9f2; border-color: #1f9d57; color: #146c43; display: block; }
        .sbxm-notice.error { background: #fff1f1; border-color: #d14343; color: #9b1c1c; display: block; }
        .sbxm-table { width: 100%; border-collapse: collapse; }
        .sbxm-table th, .sbxm-table td { padding: 14px 16px; border-bottom: 1px solid #e5e7eb; text-align: left; vertical-align: middle; font-size: 14px; }
        .sbxm-table th { color: #6b7280; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; position: sticky; top: 0; background: #fff; box-shadow: 0 1px 0 #e5e7eb; z-index: 10; font-weight: 700; }
        .sbxm-mini { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
        .sbxm-stat { border: 1px solid #d0d7de; padding: 20px; background: #fff; border-radius: 4px; }
        .sbxm-stat strong { display: block; font-size: 28px; margin-top: 8px; color: #111827; }
        .sbxm-muted { color: #6b7280; }
        .sbxm-filter-input { padding: 10px 14px; border: 1px solid #c8d1dc; border-radius: 4px; outline: none; transition: border-color 0.2s; font-size: 14px; }
        .sbxm-filter-input:focus { border-color: #0f75bd; box-shadow: 0 0 0 3px rgba(15, 117, 189, 0.1); }
        @media (max-width: 1100px) { .sbxm-grid { grid-template-columns: 1fr; } .sbxm-row { grid-template-columns: 1fr; gap: 8px; } .sbxm-row label { margin-bottom: 4px; } }
    </style>';

    echo '<div class="sbxm-shell">';
    echo '<h2 style="margin-bottom: 20px; font-weight: 700;">Hetzner Storage Box Manager</h2>';
    
    echo '<div id="sbxm-global-message" class="sbxm-notice"></div>';

    echo '<div class="sbxm-card">';
    echo '<div class="sbxm-row"><label>WHMCS Product</label><select id="sbxm-product-switch">';
    $currentGroup = '';
    foreach ($products as $product) {
        if ($currentGroup !== $product->group_name) {
            if ($currentGroup !== '') echo '</optgroup>';
            echo '<optgroup label="' . htmlspecialchars($product->group_name) . '">';
            $currentGroup = $product->group_name;
        }
        $selected = (int) $product->id === $selectedProductId ? ' selected' : '';
        echo '<option value="' . (int) $product->id . '"' . $selected . '>' . htmlspecialchars($product->name) . '</option>';
    }
    if ($currentGroup !== '') echo '</optgroup>';
    echo '</select></div>';
    
    echo '<div class="sbxm-actions">';
    echo '<button class="sbxm-btn" type="button" id="sbxm-sync-catalog">Sync Catalog</button>';
    echo '<button class="sbxm-btn alt" type="button" id="sbxm-sync-services">Sync Services</button>';
    echo '<button class="sbxm-btn warn" type="button" id="sbxm-run-overdue">Run Overdue Termination</button>';
    echo '</div>';
    echo '</div>';

    echo '<div class="sbxm-card">';
    echo hetznerstoragebox_manager_render_monitoring();
    echo '</div>';

    if ($selectedProductId > 0) {
        echo '<div class="sbxm-grid">';
        
        // Configuration Form
        echo '<div class="sbxm-card">';
        echo '<h3 style="margin-top:0; border-bottom: 1px solid #e5e7eb; padding-bottom: 15px; margin-bottom: 20px; font-size: 18px;">Product Defaults</h3>';
        echo '<form id="sbxm-config-form">';
        echo '<input type="hidden" name="product_id" value="' . (int) $selectedProductId . '">';
        echo '<div class="sbxm-row"><label>Default Location</label><select name="default_location">';
        foreach ($locationOptions as $location) {
            $selected = (string) ($selectedConfig['default_location'] ?? '') === $location ? ' selected' : '';
            echo '<option value="' . htmlspecialchars($location) . '"' . $selected . '>' . htmlspecialchars(strtoupper($location)) . '</option>';
        }
        echo '</select></div>';
        echo '<div class="sbxm-row"><label>Default Storage Type</label><select name="default_storage_box_type">';
        foreach ($catalogItems as $item) {
            $selected = (string) ($selectedConfig['default_storage_box_type'] ?? '') === (string) $item->type_name ? ' selected' : '';
            echo '<option value="' . htmlspecialchars($item->type_name) . '"' . $selected . '>' . htmlspecialchars($item->type_name . ' - ' . $item->description_text . ' (' . Common::humanBytes((int) $item->size_bytes) . ')') . '</option>';
        }
        echo '</select></div>';
        
        echo '<div class="sbxm-row"><label>Default Access</label><div class="sbxm-checks">';
        echo '<label><input type="checkbox" name="reachable_externally" value="1"' . (!empty($selectedConfig['default_access']['reachable_externally']) ? ' checked' : '') . '> External</label>';
        echo '<label><input type="checkbox" name="ssh_enabled" value="1"' . (!empty($selectedConfig['default_access']['ssh_enabled']) ? ' checked' : '') . '> SSH</label>';
        echo '<label><input type="checkbox" name="samba_enabled" value="1"' . (!empty($selectedConfig['default_access']['samba_enabled']) ? ' checked' : '') . '> SMB</label>';
        echo '<label><input type="checkbox" name="webdav_enabled" value="1"' . (!empty($selectedConfig['default_access']['webdav_enabled']) ? ' checked' : '') . '> WebDAV</label>';
        echo '<label><input type="checkbox" name="zfs_enabled" value="1"' . (!empty($selectedConfig['default_access']['zfs_enabled']) ? ' checked' : '') . '> ZFS</label>';
        echo '</div></div>';
        
        echo '<div class="sbxm-row"><label>Client Features</label><div class="sbxm-checks">';
        echo '<label><input type="checkbox" name="label_editor" value="1"' . (!empty($selectedConfig['client_features']['label_editor']) ? ' checked' : '') . '> Label editor</label>';
        echo '<label><input type="checkbox" name="password_reset" value="1"' . (!empty($selectedConfig['client_features']['password_reset']) ? ' checked' : '') . '> Password reset</label>';
        echo '</div></div>';
        
        echo '<div class="sbxm-row"><label>Billing Controls</label><div class="sbxm-checks">';
        echo '<label><input type="checkbox" name="auto_terminate_enabled" value="1"' . (!empty($selectedConfig['billing']['auto_terminate_enabled']) ? ' checked' : '') . '> Auto terminate unpaid</label>';
        echo '</div></div>';
        
        echo '<div class="sbxm-row"><label>Overdue Grace Days</label><input type="number" name="overdue_days" value="' . htmlspecialchars((string) ($selectedConfig['billing']['overdue_days'] ?? 3)) . '" min="0"></div>';
        
        echo '<h3 style="border-bottom: 1px solid #e5e7eb; padding-bottom: 15px; margin: 30px 0 20px; font-size: 18px;">Pricing Engine</h3>';
        echo '<div class="sbxm-row"><label>Price Base Mode</label><select name="pricing_base_price_mode">';
        foreach (['net' => 'Net', 'gross' => 'Gross'] as $key => $label) {
            $selected = (string) ($selectedConfig['pricing']['base_price_mode'] ?? 'net') === $key ? ' selected' : '';
            echo '<option value="' . htmlspecialchars($key) . '"' . $selected . '>' . htmlspecialchars($label) . '</option>';
        }
        echo '</select></div>';
        
        echo '<div class="sbxm-row"><label>Margin %</label><input type="number" step="0.01" name="pricing_margin_percent" value="' . htmlspecialchars((string) ($selectedConfig['pricing']['margin_percent'] ?? '15')) . '"></div>';
        
        echo '<div class="sbxm-row"><label>Currencies</label><div class="sbxm-checks">';
        foreach ($currencies as $currency) {
            $checked = in_array((int) $currency->id, (array) ($selectedConfig['pricing']['selected_currency_ids'] ?? []), true) ? ' checked' : '';
            echo '<label><input type="checkbox" name="pricing_selected_currency_ids[]" value="' . (int) $currency->id . '"' . $checked . '> ' . htmlspecialchars($currency->code) . '</label>';
        }
        echo '</div></div>';
        
        echo '<div class="sbxm-row"><label>Billing Periods</label><div class="sbxm-checks">';
        foreach (PricingEngine::periodMap() as $period => $months) {
            $checked = in_array($period, (array) ($selectedConfig['pricing']['selected_periods'] ?? []), true) ? ' checked' : '';
            echo '<label><input type="checkbox" name="pricing_selected_periods[]" value="' . htmlspecialchars($period) . '"' . $checked . '> ' . htmlspecialchars(PricingEngine::periodLabel($period)) . '</label>';
        }
        echo '</div></div>';
        
        echo '<div class="sbxm-row"><label>Daily Sync</label><div class="sbxm-checks">';
        echo '<label><input type="checkbox" name="pricing_apply_daily" value="1"' . (!empty($selectedConfig['pricing']['apply_daily']) ? ' checked' : '') . '> Auto apply during DailyCron</label>';
        echo '</div></div>';
        
        echo '<div class="sbxm-actions">';
        echo '<button class="sbxm-btn" type="button" id="sbxm-save-config">Save Configuration</button>';
        echo '<button class="sbxm-btn alt" type="button" id="sbxm-apply-pricing">Apply Pricing Now</button>';
        echo '</div>';
        echo '</form>';
        echo '</div>';

        // Right Column
        echo '<div class="sbxm-card">';
        echo '<h3 style="margin-top:0; font-size: 18px;">Pricing Preview</h3>';
        echo '<div id="sbxm-preview">' . $previewHtml . '</div>';
        echo '<hr style="border: 0; border-top: 1px solid #e5e7eb; margin: 30px 0;">';
        echo '<h3 style="font-size: 18px;">Synced Catalog</h3>';
        echo hetznerstoragebox_manager_render_catalog($catalogItems);
        echo '</div>';
        
        echo '</div>';
    } else {
        echo '<div class="sbxm-card">No WHMCS products are currently assigned to the `hetznerstoragebox` server module.</div>';
    }

    // New Active Services Section pushed to the very bottom
    echo '<hr style="border: 0; border-top: 2px solid #e5e7eb; margin: 40px 0;">';
    echo hetznerstoragebox_manager_render_active_services();

    echo '<script>
        (function(){
            const baseUrl = ' . json_encode($baseUrl . ($selectedProductId > 0 ? '&product_id=' . $selectedProductId : '')) . ';
            const productSwitch = document.getElementById("sbxm-product-switch");
            const form = document.getElementById("sbxm-config-form");
            const preview = document.getElementById("sbxm-preview");
            const globalMsg = document.getElementById("sbxm-global-message");

            function note(text, type) { 
                if (!globalMsg) return;
                if (!text) {
                    globalMsg.className = "sbxm-notice";
                    return;
                }
                globalMsg.textContent = text; 
                globalMsg.className = "sbxm-notice " + type;
            }

            async function post(action, withForm = true){
                const options = { method: "POST" };
                if (withForm && form) {
                    options.body = new FormData(form);
                }
                const response = await fetch(baseUrl + "&sbxAjax=" + encodeURIComponent(action), options);
                
                let data;
                try {
                    data = await response.json();
                } catch(e) {
                    throw new Error("Invalid response received from server. Make sure display_errors is off in WHMCS.");
                }
                
                if (!response.ok) {
                    throw new Error(data.message || "Request failed with HTTP " + response.status);
                }
                return data;
            }

            if (productSwitch) {
                productSwitch.addEventListener("change", function(){
                    window.location = ' . json_encode($baseUrl) . ' + "&product_id=" + encodeURIComponent(this.value);
                });
            }

            if (form) {
                let timer = null;
                form.querySelectorAll("input,select").forEach(function(el){
                    const refresh = function(){
                        clearTimeout(timer);
                        timer = setTimeout(async function(){
                            try {
                                const data = await post("preview");
                                if (data.preview_html && preview) { preview.innerHTML = data.preview_html; }
                            } catch (error) {
                                // Silent fail for preview
                            }
                        }, 400);
                    };
                    el.addEventListener("change", refresh);
                    el.addEventListener("input", refresh);
                });
            }

            async function handleAction(btnId, actionName, isForm, loadingText) {
                const btn = document.getElementById(btnId);
                if (!btn) return;
                
                const originalText = btn.innerHTML;
                btn.disabled = true;
                btn.innerHTML = loadingText;
                note(""); 
                
                try {
                    const data = await post(actionName, isForm);
                    if (data.preview_html && preview) { preview.innerHTML = data.preview_html; }
                    note(data.message || "Operation completed.", data.ok ? "success" : "error");
                    
                    if (data.ok && !isForm) {
                        setTimeout(() => window.location.reload(), 1500);
                    }
                } catch (error) {
                    note(error.message || "An unexpected error occurred.", "error");
                } finally {
                    btn.disabled = false;
                    btn.innerHTML = originalText;
                }
            }

            const bindBtn = (id, action, isForm, loadingText) => {
                const btn = document.getElementById(id);
                if (btn) btn.addEventListener("click", () => handleAction(id, action, isForm, loadingText));
            };

            bindBtn("sbxm-save-config", "save", true, "Saving...");
            bindBtn("sbxm-apply-pricing", "applyPricing", true, "Applying...");
            bindBtn("sbxm-sync-catalog", "syncCatalog", false, "Syncing Catalog...");
            bindBtn("sbxm-sync-services", "syncServices", false, "Syncing Services...");
            bindBtn("sbxm-run-overdue", "runOverdue", false, "Processing...");

            // Active Services Filtering Logic
            const searchInput = document.getElementById("sbx-service-search");
            const whmcsFilter = document.getElementById("sbx-whmcs-filter");
            const hetznerFilter = document.getElementById("sbx-hetzner-filter");
            const rows = document.querySelectorAll(".sbx-service-row");
            const noResults = document.getElementById("sbx-no-results");

            function filterServicesTable() {
                if (!searchInput) return;
                const term = searchInput.value.toLowerCase();
                const wStatus = whmcsFilter.value.toLowerCase();
                const hStatus = hetznerFilter.value.toLowerCase();

                let visibleCount = 0;
                rows.forEach(row => {
                    const searchData = row.getAttribute("data-search").toLowerCase();
                    const rowWStatus = row.getAttribute("data-whmcs").toLowerCase();
                    const rowHStatus = row.getAttribute("data-hetzner").toLowerCase();

                    let matchesSearch = searchData.includes(term);
                    let matchesW = wStatus === "" || rowWStatus === wStatus;
                    let matchesH = hStatus === "" || rowHStatus === hStatus;

                    if (hStatus === "inactive" && rowHStatus !== "active") {
                        matchesH = true; // Count anything non-active as inactive/hold
                    }

                    if (matchesSearch && matchesW && matchesH) {
                        row.style.display = "";
                        visibleCount++;
                    } else {
                        row.style.display = "none";
                    }
                });

                if (noResults) {
                    noResults.style.display = visibleCount === 0 ? "" : "none";
                }
            }

            if (searchInput) searchInput.addEventListener("input", filterServicesTable);
            if (whmcsFilter) whmcsFilter.addEventListener("change", filterServicesTable);
            if (hetznerFilter) hetznerFilter.addEventListener("change", filterServicesTable);

        })();
    </script>';
    echo '</div>';
}

function hetznerstoragebox_manager_handle_ajax()
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    header('Content-Type: application/json');

    try {
        $action = (string) ($_GET['sbxAjax'] ?? '');
        $productId = (int) ($_POST['product_id'] ?? $_GET['product_id'] ?? 0);
        $patch = $productId > 0 ? hetznerstoragebox_manager_patch_from_request() : [];
        $client = Common::getApiClient();

        switch ($action) {
            case 'syncCatalog':
                $summary = Common::syncCatalog($client);
                echo json_encode(['ok' => true, 'message' => 'Catalog synced successfully. Updated ' . (int) $summary['updated'] . ' storage box types.']);
                exit;

            case 'syncServices':
                // Custom Sync override to cleanly catch 404s and update WHMCS db directly
                $rows = Capsule::table('mod_hetznerstoragebox_services')->whereNotNull('storage_box_id')->get();
                $updatedCount = 0;
                $notFoundCount = 0;
                
                foreach ($rows as $row) {
                    try {
                        $response = $client->get('/storage_boxes/' . (int) $row->storage_box_id);
                        $box = (array) ($response['storage_box'] ?? []);
                        if (!empty($box)) {
                            Common::saveServiceRecord((int) $row->service_id, [
                                'status' => (string) ($box['status'] ?? 'active'),
                                'last_synced' => Common::now(),
                                'meta_json' => ['box' => $box],
                            ]);
                            Common::captureMetric((int) $row->service_id, (array) ($box['stats'] ?? []));
                            Common::updateServiceDetails((int) $row->service_id, $box);
                            $updatedCount++;
                        }
                    } catch (\Throwable $e) {
                        $err = strtolower($e->getMessage());
                        if (strpos($err, 'not found') !== false || strpos($err, '404') !== false) {
                            // Force database update explicitly to ensure the status is saved
                            Capsule::table('mod_hetznerstoragebox_services')
                                ->where('service_id', (int) $row->service_id)
                                ->update([
                                    'status' => 'not found',
                                    'last_synced' => Common::now()
                                ]);
                            $notFoundCount++;
                        } else {
                            Common::logEvent((int) $row->service_id, 'error', 'sync', 'Sync failed: ' . $e->getMessage());
                        }
                    }
                }
                
                $msg = "Service sync completed. Synced $updatedCount active services.";
                if ($notFoundCount > 0) $msg .= " Flagged $notFoundCount missing services as Not Found.";
                
                echo json_encode(['ok' => true, 'message' => $msg]);
                exit;

            case 'runOverdue':
                $summary = Common::autoTerminateOverdueServices();
                echo json_encode(['ok' => true, 'message' => 'Overdue termination job processed ' . count($summary) . ' services.']);
                exit;

            case 'preview':
                $preview = Common::buildPricingPreview($productId, $patch);
                echo json_encode(['ok' => true, 'preview_html' => hetznerstoragebox_manager_render_preview($preview)]);
                exit;

            case 'save':
                Common::saveProductConfig($productId, $patch);
                $preview = Common::buildPricingPreview($productId, $patch);
                echo json_encode(['ok' => true, 'preview_html' => hetznerstoragebox_manager_render_preview($preview), 'message' => 'Configuration saved successfully.']);
                exit;

            case 'applyPricing':
                Common::saveProductConfig($productId, $patch);
                $result = Common::applyPricingNow($productId, $patch);
                echo json_encode([
                    'ok' => true,
                    'preview_html' => hetznerstoragebox_manager_render_preview($result['preview']),
                    'message' => 'Pricing applied successfully to ' . count($result['changes']) . ' currency rows.',
                ]);
                exit;
        }

        throw new \RuntimeException('Unknown AJAX action.');
    } catch (\Throwable $exception) {
        echo json_encode(['ok' => false, 'message' => $exception->getMessage()]);
        exit;
    }
}

function hetznerstoragebox_manager_patch_from_request()
{
    return [
        'default_location' => (string) ($_POST['default_location'] ?? 'fsn1'),
        'default_storage_box_type' => (string) ($_POST['default_storage_box_type'] ?? 'bx11'),
        'default_access' => [
            'reachable_externally' => isset($_POST['reachable_externally']),
            'ssh_enabled' => isset($_POST['ssh_enabled']),
            'samba_enabled' => isset($_POST['samba_enabled']),
            'webdav_enabled' => isset($_POST['webdav_enabled']),
            'zfs_enabled' => isset($_POST['zfs_enabled']),
        ],
        'client_features' => [
            'label_editor' => isset($_POST['label_editor']),
            'password_reset' => isset($_POST['password_reset']),
        ],
        'billing' => [
            'auto_terminate_enabled' => isset($_POST['auto_terminate_enabled']),
            'overdue_days' => (int) ($_POST['overdue_days'] ?? 3),
        ],
        'pricing' => [
            'base_price_mode' => (string) ($_POST['pricing_base_price_mode'] ?? 'net'),
            'margin_percent' => (string) ($_POST['pricing_margin_percent'] ?? '15'),
            'selected_currency_ids' => array_map('intval', (array) ($_POST['pricing_selected_currency_ids'] ?? [])),
            'selected_periods' => array_values((array) ($_POST['pricing_selected_periods'] ?? [])),
            'apply_daily' => isset($_POST['pricing_apply_daily']),
        ],
    ];
}

function hetznerstoragebox_manager_locations($catalogItems)
{
    $locations = [];
    foreach ($catalogItems as $item) {
        foreach (Common::jsonDecodeArray($item->prices_json) as $price) {
            $code = strtolower(trim((string) ($price['location'] ?? '')));
            if ($code !== '') {
                $locations[$code] = $code;
            }
        }
    }

    if (empty($locations)) {
        $locations['fsn1'] = 'fsn1';
    }

    ksort($locations);
    return array_values($locations);
}

function hetznerstoragebox_manager_render_preview(array $preview)
{
    $html = '<table class="sbxm-table"><thead><tr><th>Currency</th><th>Billing Periods</th></tr></thead><tbody>';
    foreach ((array) ($preview['rows'] ?? []) as $row) {
        $periods = [];
        foreach ((array) ($row['periods'] ?? []) as $period => $amount) {
            $periods[] = htmlspecialchars(PricingEngine::periodLabel($period)) . ': <strong>' . htmlspecialchars((string) $amount . ' ' . $row['currency_code']) . '</strong>';
        }
        $html .= '<tr><td><strong>' . htmlspecialchars((string) $row['currency_code']) . '</strong></td><td>' . implode('<br>', $periods) . '</td></tr>';
    }
    if (empty($preview['rows'])) {
        $html .= '<tr><td colspan="2" class="sbxm-muted">No preview rows yet. Select currencies and billing periods first.</td></tr>';
    }
    $html .= '</tbody></table>';

    if (!empty($preview['base'])) {
        $html = '<p class="sbxm-muted" style="font-size: 13px; margin-top: 15px; padding-top: 15px; border-top: 1px dashed #e5e7eb;">Base price source: ' . htmlspecialchars($preview['base']['type_name'] . ' @ ' . strtoupper($preview['base']['location']) . ' in ' . $preview['base']['base_currency']) . '.</p>' . $html;
    }

    return $html;
}

function hetznerstoragebox_manager_render_catalog($catalogItems)
{
    $html = '<div style="max-height: 400px; overflow-y: auto; border-bottom: 1px solid #e5e7eb;">';
    $html .= '<table class="sbxm-table" style="margin-bottom: 0;"><thead><tr><th>Type</th><th>Quota</th><th>Locations</th></tr></thead><tbody>';
    foreach ($catalogItems as $item) {
        $locations = [];
        foreach (Common::jsonDecodeArray($item->prices_json) as $price) {
            if (!empty($price['location'])) {
                $locations[] = strtoupper((string) $price['location']);
            }
        }
        $html .= '<tr>';
        $html .= '<td><strong>' . htmlspecialchars((string) $item->type_name) . '</strong><br><span style="font-size: 13px; color: #6b7280;">' . htmlspecialchars((string) $item->description_text) . '</span></td>';
        $html .= '<td>' . htmlspecialchars(Common::humanBytes((int) $item->size_bytes)) . '</td>';
        $html .= '<td>' . htmlspecialchars(implode(', ', array_unique($locations))) . '</td>';
        $html .= '</tr>';
    }
    if (empty($catalogItems)) {
        $html .= '<tr><td colspan="3" class="sbxm-muted text-center" style="padding: 30px;">No synced catalog data yet.<br>Click "Sync Catalog" at the top to download the latest Storage Box types.</td></tr>';
    }
    $html .= '</tbody></table></div>';

    return $html;
}

function hetznerstoragebox_manager_render_monitoring()
{
    $serviceCount = count(Common::monitoredServiceRows());
    $catalogCount = count(Common::getCatalogItems());
    $warningCount = Capsule::table('mod_hetznerstoragebox_events')->whereIn('level', ['warning', 'error'])->count();
    $latestMetrics = Capsule::table('mod_hetznerstoragebox_metrics')->count();
    $events = Capsule::table('mod_hetznerstoragebox_events')->orderBy('id', 'desc')->limit(5)->get();

    $html = '<h3 style="margin-top:0; font-size: 18px;">System Overview</h3>';
    $html .= '<div class="sbxm-mini">';
    $html .= '<div class="sbxm-stat"><span class="sbxm-muted">Tracked Services</span><strong>' . (int) $serviceCount . '</strong></div>';
    $html .= '<div class="sbxm-stat"><span class="sbxm-muted">Catalog Types</span><strong>' . (int) $catalogCount . '</strong></div>';
    $html .= '<div class="sbxm-stat"><span class="sbxm-muted">Warnings / Errors</span><strong>' . (int) $warningCount . '</strong></div>';
    $html .= '<div class="sbxm-stat"><span class="sbxm-muted">Stored Metrics</span><strong>' . (int) $latestMetrics . '</strong></div>';
    $html .= '</div>';
    
    $html .= '<h4 style="margin-top:25px; border-bottom: 1px solid #e5e7eb; padding-bottom: 10px; font-size: 16px;">Recent Module Events</h4>';
    $html .= '<div style="overflow-x: auto;">';
    $html .= '<table class="sbxm-table"><thead><tr><th style="width: 180px;">When</th><th style="width: 80px;">Service</th><th style="width: 80px;">Level</th><th>Message</th></tr></thead><tbody>';
    foreach ($events as $event) {
        $color = $event->level === 'error' ? '#d14343' : ($event->level === 'warning' ? '#d9822b' : '#374151');
        $html .= '<tr>';
        $html .= '<td class="sbxm-muted" style="font-size: 13px;">' . htmlspecialchars((string) $event->created_at) . '</td>';
        $html .= '<td>' . htmlspecialchars((string) ($event->service_id ?: '--')) . '</td>';
        $html .= '<td style="color: ' . $color . '; font-weight: 600;">' . htmlspecialchars(strtoupper((string) $event->level)) . '</td>';
        $html .= '<td>' . htmlspecialchars((string) $event->message) . '</td>';
        $html .= '</tr>';
    }
    if (count($events) === 0) {
        $html .= '<tr><td colspan="4" class="sbxm-muted text-center" style="padding: 20px;">No module events recorded yet.</td></tr>';
    }
    $html .= '</tbody></table></div>';

    return $html;
}

function hetznerstoragebox_manager_render_active_services()
{
    $services = Capsule::table('mod_hetznerstoragebox_services')
        ->join('tblhosting', 'tblhosting.id', '=', 'mod_hetznerstoragebox_services.service_id')
        ->join('tblclients', 'tblclients.id', '=', 'tblhosting.userid')
        ->select(
            'mod_hetznerstoragebox_services.service_id',
            'mod_hetznerstoragebox_services.storage_box_id',
            'mod_hetznerstoragebox_services.username',
            'mod_hetznerstoragebox_services.status as hetzner_status',
            'tblhosting.domainstatus as whmcs_status',
            'tblclients.id as client_id',
            'tblclients.firstname',
            'tblclients.lastname',
            'tblclients.companyname',
            'tblclients.email'
        )
        ->orderBy('mod_hetznerstoragebox_services.service_id', 'desc')
        ->get();

    $html = '<div class="sbxm-card">';
    
    // Top Bar: Title & Filters
    $html .= '<div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e5e7eb; padding-bottom: 15px; margin-bottom: 15px; flex-wrap: wrap; gap: 15px;">';
    $html .= '<h3 style="margin: 0; font-size: 18px;">Active Storage Box Services</h3>';
    
    $html .= '<div style="display: flex; gap: 10px; flex-wrap: wrap;">';
    $html .= '<input type="text" id="sbx-service-search" class="sbxm-filter-input" placeholder="Search name, email, ID..." style="width: 250px;">';
    $html .= '<select id="sbx-whmcs-filter" class="sbxm-filter-input">';
    $html .= '<option value="">All WHMCS Statuses</option>';
    $html .= '<option value="active">Active</option>';
    $html .= '<option value="suspended">Suspended</option>';
    $html .= '<option value="terminated">Terminated</option>';
    $html .= '<option value="cancelled">Cancelled</option>';
    $html .= '</select>';
    $html .= '<select id="sbx-hetzner-filter" class="sbxm-filter-input">';
    $html .= '<option value="">All Hetzner Statuses</option>';
    $html .= '<option value="active">Active</option>';
    $html .= '<option value="inactive">Inactive / Hold / Not Found</option>';
    $html .= '</select>';
    $html .= '</div>';
    $html .= '</div>';

    // The Table container with fixed scrolling height
    $html .= '<div style="max-height: 800px; overflow-y: auto; border-bottom: 1px solid #e5e7eb;">';
    $html .= '<table class="sbxm-table" style="margin-bottom: 0;"><thead><tr><th>Service ID</th><th>Client</th><th>Storage Box</th><th>WHMCS Status</th><th>Hetzner Status</th><th style="text-align:right;">Action</th></tr></thead><tbody id="sbx-services-tbody">';
    
    foreach ($services as $svc) {
        $clientName = trim($svc->firstname . ' ' . $svc->lastname);
        if ($svc->companyname) $clientName .= ' (' . $svc->companyname . ')';
        
        $whmcsStatusRaw = strtolower($svc->whmcs_status);
        $hetznerStatusRaw = strtolower($svc->hetzner_status);
        
        $whmcsBadge = $whmcsStatusRaw === 'active' ? '<span style="color:#1f9d57;font-weight:bold;">Active</span>' : '<span class="sbxm-muted">' . htmlspecialchars($svc->whmcs_status) . '</span>';
        
        // Correct Hetzner Badge logic based on explicit Not Found overrides
        if (empty($svc->storage_box_id) || $hetznerStatusRaw === 'not found' || $hetznerStatusRaw === 'deleted') {
            $hetznerBadge = '<span style="color:#d14343;font-weight:bold;">Not Found</span>';
            $hetznerStatusRaw = 'inactive';
        } else if ($hetznerStatusRaw === 'active') {
            $hetznerBadge = '<span style="color:#1f9d57;font-weight:bold;">Active</span>';
            $hetznerStatusRaw = 'active';
        } else {
            $hetznerBadge = '<span style="color:#d9822b;font-weight:bold;">' . htmlspecialchars(ucfirst($svc->hetzner_status)) . '</span>';
            $hetznerStatusRaw = 'inactive';
        }
        
        // Build the searchable string for JS filtering
        $searchString = htmlspecialchars(strtolower(
            $svc->service_id . ' ' . 
            $clientName . ' ' . 
            $svc->email . ' ' . 
            $svc->client_id . ' ' . 
            $svc->username . ' ' . 
            $svc->storage_box_id
        ));

        $html .= '<tr class="sbx-service-row" data-search="' . $searchString . '" data-whmcs="' . htmlspecialchars($whmcsStatusRaw) . '" data-hetzner="' . htmlspecialchars($hetznerStatusRaw) . '">';
        $html .= '<td><a href="clientsservices.php?userid=' . $svc->client_id . '&id=' . $svc->service_id . '" target="_blank" style="text-decoration:none;font-weight:bold;font-size:14px;">#' . $svc->service_id . '</a></td>';
        $html .= '<td><a href="clientssummary.php?userid=' . $svc->client_id . '" target="_blank" style="text-decoration:none;color:#0f75bd;font-size:14px;">' . htmlspecialchars($clientName) . '</a><br><span style="font-size: 13px;" class="sbxm-muted">' . htmlspecialchars($svc->email) . '</span></td>';
        $html .= '<td><span style="font-size: 14px;">' . htmlspecialchars($svc->username ?: 'Pending') . '</span> <br><span class="sbxm-muted" style="font-size: 13px;">(' . ($svc->storage_box_id ?: '--') . ')</span></td>';
        $html .= '<td>' . $whmcsBadge . '</td>';
        $html .= '<td>' . $hetznerBadge . '</td>';
        $html .= '<td style="text-align:right;"><a href="clientsservices.php?userid=' . $svc->client_id . '&id=' . $svc->service_id . '" class="sbxm-btn alt" style="padding: 6px 14px; font-size: 13px; text-decoration: none;" target="_blank">Manage</a></td>';
        $html .= '</tr>';
    }
    
    if (count($services) === 0) {
        $html .= '<tr><td colspan="6" class="sbxm-muted text-center" style="padding: 20px;">No storage box services found.</td></tr>';
    }
    
    $html .= '<tr id="sbx-no-results" style="display: none;"><td colspan="6" class="sbxm-muted text-center" style="padding: 30px;">No users match your filter criteria.</td></tr>';
    $html .= '</tbody></table></div>';
    
    $html .= '</div>';
    return $html;
}