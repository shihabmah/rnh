<div class="hd-tab-content" id="hd-snapshots">
    <div class="hd-panel">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h5 class="fw-bold mb-1"><i class="fas fa-clone me-2" style="color: var(--hd-accent);"></i> Data Retention</h5>
                <p class="text-muted mb-0" style="font-size: 0.9rem;">Manage point-in-time images of your filesystem.</p>
            </div>
            
            <div class="d-flex flex-wrap" id="hd-snapshot-actions" style="gap: 16px;">
                <button type="button" class="hd-btn-outline" style="padding: 10px 22px; color: var(--hd-accent); border-color: var(--hd-accent);" onclick="openModal('createSnapshotModal')">
                    Take manual snapshot
                </button>

                {if $autoSnapshotEnabled}
                    <button type="button" class="hd-btn-primary" style="padding: 10px 22px;" onclick="openModal('autoSnapshotModal')">
                        Change settings
                    </button>
                    <button type="button" class="hd-btn-outline" style="padding: 10px 22px; color: var(--hd-accent); border-color: var(--hd-accent);" onclick="openModal('disableAutoSnapshotModal')">
                        Disable automatic snapshots
                    </button>
                {else}
                    <button type="button" class="hd-btn-primary" style="padding: 10px 22px;" onclick="openModal('autoSnapshotModal')">
                        Enable automatic snapshots
                    </button>
                {/if}
            </div>
        </div>

        <div class="hd-settings-list mb-4" id="hd-zfs-setting-wrap">
            <label class="hd-settings-item hd-zfs-setting" id="hd-zfs-setting" style="justify-content: space-between; padding: 16px 20px;">
                <div class="d-flex align-items-center text-nowrap" style="gap: 8px;">
                    <span class="fw-bold" style="font-size: 0.95rem;">Expose Snapshot Directory</span>
                    <span class="text-muted" style="font-size: 0.85rem; font-weight: 400;">
                        — Makes the <code class="px-1 rounded" style="background: rgba(127,138,150,0.1); border: 1px solid var(--hd-border); color: inherit;">/.zfs/snapshot</code> path visible.
                    </span>
                </div>

                <span class="hd-zfs-status" id="hd-zfs-status">
                    <i class="fas fa-circle-notch fa-spin"></i>
                    <span id="hd-zfs-status-text">Expose Snapshot Directory</span>
                </span>

                <input type="checkbox" id="hd-zfs-toggle" class="form-check-input" {if $accessSettings.zfs_enabled}checked{/if} onchange="toggleSnapshotDir(this.checked)">
            </label>
        </div>

        <div class="hd-table-wrapper hd-responsive-table" style="overflow-x: auto;">
            <table class="hd-table" style="width: 100%; white-space: nowrap;">
                <thead>
                    <tr>
                        <th style="width: 38%;">DESCRIPTION</th>
                        <th style="width: 16%;">TYPE</th>
                        <th style="width: 16%;">DISK SIZE</th>
                        <th style="width: 16%;">FILESYSTEM SIZE</th>
                        <th style="width: 14%; text-align: right;">ACTIONS</th>
                    </tr>
                </thead>

                <tbody id="hd-snapshots-tbody">
                    {foreach from=$snapshots item=snap}
                        {assign var=snapType value=$snap.type_label|default:$snap.type|default:'Manual'}
                        {assign var=snapDesc value=$snap.description|default:$snap.name|default:''}

                        <tr id="snap-row-{$snap.id|escape:'html'}">
                            <td class="fw-bold" data-label="Description">
                                {if $snapDesc}
                                    {$snapDesc|escape:'html'}
                                {elseif $snapType|lower == 'automatic'}
                                    Automatic snapshot
                                {else}
                                    Manual snapshot
                                {/if}
                            </td>

                            <td data-label="Type">
                                {if $snapType|lower == 'automatic'}
                                    <span style="background: rgba(var(--hd-accent-rgb),0.14); color: var(--hd-accent); font-size: 0.75rem; font-weight: 700; padding: 4px 12px; border-radius: 12px; text-transform: capitalize;">
                                        Automatic
                                    </span>
                                {else}
                                    <span style="background: rgba(127,138,150,0.15); color: var(--hd-text-main); font-size: 0.75rem; font-weight: 600; padding: 4px 12px; border-radius: 12px; text-transform: capitalize;">
                                        Manual
                                    </span>
                                {/if}
                            </td>

                            <td class="text-muted" data-label="Disk size">
                                {$snap.size|default:$snap.disk_size|default:'0 B'|escape:'html'}
                            </td>

                            <td class="text-muted" data-label="Filesystem size">
                                {$snap.filesystem_size|default:$snap.size_filesystem|default:'0 B'|escape:'html'}
                            </td>

                            <td data-label="Actions" style="text-align: right;">
                                <div class="d-flex justify-content-end gap-2">
                                    <button type="button" class="hd-icon-btn" style="color: var(--hd-warning);" onclick="promptRestoreSnapshot('{$snap.id|escape:'javascript'}')" title="Restore">
                                        <i class="fas fa-history"></i>
                                    </button>

                                    <button type="button" class="hd-icon-btn" style="color: var(--hd-danger);" onclick="promptDeleteSnapshot('{$snap.id|escape:'javascript'}')" title="Delete">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    {foreachelse}
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted" data-label="Snapshots">
                                <i class="fas fa-inbox fa-2x mb-2 d-block opacity-50"></i> No snapshots found.
                            </td>
                        </tr>
                    {/foreach}
                </tbody>
            </table>
        </div>
    </div>
</div>