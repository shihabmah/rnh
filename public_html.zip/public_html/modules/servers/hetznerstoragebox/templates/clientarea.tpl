<style>
{literal}
:root { 
    --hd-accent: #1f8dee;
    --hd-accent-rgb: 31, 141, 238; 
    --hd-success: #1f9d57; 
    --hd-warning: #d9822b; 
    --hd-danger: #d14343; 
    --hd-muted: var(--bs-secondary-color, #8a8a8a); 
    --hd-border: var(--bs-border-color, rgba(127, 138, 150, 0.25)); 
    --hd-text-main: var(--bs-body-color, #2d3748);
    --hd-bg-main: var(--bs-body-bg, #ffffff);
    --hd-card-bg: var(--bs-card-bg, #ffffff); 
    --hd-table-head-bg: rgba(127, 138, 150, 0.04);
    --hd-table-row-hover: rgba(127, 138, 150, 0.02);
}

/* Safely remove ONLY the WHMCS native tab separator line without breaking other tabs */
ul.nav.nav-tabs { border-bottom: none !important; }
div.tab-content { border-top: none !important; }

/* Croster Dark Mode Support */
[data-theme="dark"] .hd-dashboard,
body.dark-mode .hd-dashboard,
body[data-bs-theme="dark"] .hd-dashboard,
[data-theme="dark"] .hd-modal,
body.dark-mode .hd-modal,
body[data-bs-theme="dark"] .hd-modal {
    --hd-bg-main: #2a2a2a !important; 
    --hd-card-bg: #1d1d1d !important; 
    --hd-text-main: #ffffff !important;
    --hd-border: rgba(255, 255, 255, 0.1) !important; 
    --hd-muted: #a1a5b7 !important;
    --hd-table-head-bg: #222222 !important;
    --hd-table-row-hover: rgba(255, 255, 255, 0.03) !important;
}

/* Base Wrapper */
.hd-dashboard { 
    font-family: inherit; 
    background: transparent !important; 
    width: 100%; 
    box-sizing: border-box; 
    color: var(--hd-text-main); 
}
.hd-dashboard * { box-sizing: border-box; }
.hd-dashboard a { text-decoration: none !important; }

/* Navigation Tabs */
.hd-tab-nav { 
    display: flex; 
    gap: 8px; 
    list-style: none; 
    padding: 0; 
    margin-bottom: 24px; 
    overflow-x: auto; 
    scrollbar-width: none; 
    border-bottom: 1px solid var(--hd-border);
}
.hd-tab-nav::-webkit-scrollbar { display: none; }
.hd-tab-nav li { display: flex; flex: 1 1 auto; max-width: max-content; }
.hd-tab-nav a { 
    display: inline-flex; 
    align-items: center; 
    justify-content: center; 
    gap: 8px; 
    padding: 12px 20px; 
    color: var(--hd-muted); 
    font-weight: 600; 
    font-size: 0.95rem;
    border-radius: 4px 4px 0 0 !important; 
    border-bottom: 2px solid transparent;
    transition: all 0.2s ease; 
    white-space: nowrap; 
    cursor: pointer; 
}
.hd-tab-nav a:hover { color: var(--hd-accent); background: rgba(var(--hd-accent-rgb), 0.05); }
.hd-tab-nav a.active { 
    color: var(--hd-accent); 
    border-bottom-color: var(--hd-accent);
    background: rgba(var(--hd-accent-rgb), 0.05); 
}

/* Animations */
.hd-tab-content { display: none; animation: hdFadeIn 0.3s ease forwards; opacity: 0; }
.hd-tab-content.active { display: block; }
@keyframes hdFadeIn { to { opacity: 1; } }

/* Panels */
.hd-panel { 
    background: transparent !important; 
    border: none !important; 
    padding: 0 0 20px 0 !important; 
    margin-bottom: 0 !important; 
    box-shadow: none !important;
}
.hd-section-title { 
    display: flex; 
    align-items: center; 
    gap: 10px; 
    margin: 0 0 20px; 
    font-size: 1.1rem; 
    font-weight: 700; 
    color: var(--hd-accent);
    text-transform: uppercase;
}

/* Hetzner Quota Circles */
.hd-specs-wrapper { margin-bottom: 24px; padding-bottom: 24px; }
.hd-specs-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 30px; }
.hd-circle-gauge {
    width: 130px;
    height: 130px;
    border-radius: 50%;
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    text-align: center;
    background: repeating-conic-gradient(var(--hd-border) 0 30deg, transparent 30deg 36deg);
}
.hd-circle-gauge::before {
    content: "";
    position: absolute;
    inset: 8px; 
    background: var(--hd-bg-main);
    border-radius: 50%;
    z-index: 1;
    transition: background 0.3s ease;
}
.hd-circle-gauge > div {
    z-index: 2;
    position: relative;
    display: flex;
    flex-direction: column;
    gap: 2px;
}
.hd-circle-gauge .val {
    font-size: 1.15rem;
    color: var(--hd-accent);
    font-weight: bold;
}
.hd-circle-gauge .lbl {
    font-size: 0.85rem;
    color: var(--hd-muted);
    line-height: 1.2;
}

/* Layout Grids */
.hd-overview-grid { display: grid; grid-template-columns: minmax(0, 2fr) minmax(280px, 1fr); gap: 30px; align-items: stretch; }

/* Modern Tables */
.hd-table-wrapper {
    border: 1px solid var(--hd-border);
    border-radius: 6px;
    background: var(--hd-card-bg);
    overflow-x: auto;
    margin-bottom: 30px;
}
.hd-table { 
    width: 100%; 
    border-collapse: separate; 
    border-spacing: 0;
    margin: 0 !important; 
    text-align: left;
}
.hd-table thead { background-color: var(--hd-table-head-bg); }
.hd-table th { 
    padding: 12px 20px; 
    font-size: 0.75rem; 
    font-weight: 600; 
    text-transform: uppercase; 
    color: var(--hd-muted); 
    border-bottom: 1px solid var(--hd-border);
    white-space: nowrap;
}
.hd-table td { 
    padding: 14px 20px; 
    font-size: 0.875rem; 
    color: var(--hd-text-main); 
    border-bottom: 1px solid var(--hd-border);
    vertical-align: middle; 
}
.hd-table tbody tr:last-child td { border-bottom: none; }
.hd-table tbody tr { transition: background-color 0.15s ease; }
.hd-table tbody tr:hover { background-color: var(--hd-table-row-hover); }

/* Single-Line Data Pills */
.hd-data-pill { 
    padding: 6px 12px; 
    display: flex; 
    align-items: center; 
    justify-content: space-between; 
    gap: 10px; 
    font-family: monospace; 
    font-size: 0.9rem; 
    border-radius: 4px !important;
    border: 1px solid var(--hd-border);
    background: rgba(127,138,150,0.05) !important; 
    width: 100%;
}
.hd-data-pill span { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block; }
.hd-copy-icon { cursor: pointer; color: var(--hd-muted); transition: 0.2s; font-size: 1rem; flex-shrink: 0; }
.hd-copy-icon:hover { color: var(--hd-accent); }

/* Buttons */
.hd-btn-outline { 
    border: 1px solid var(--hd-border) !important; 
    background: transparent !important; 
    color: var(--hd-text-main) !important; 
    transition: all 0.2s ease; 
    padding: 10px 20px; 
    font-weight: 600; 
    border-radius: 4px !important;
    display: inline-flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer; white-space: nowrap; 
}
.hd-btn-outline:hover:not(:disabled) { border-color: var(--hd-accent) !important; color: var(--hd-accent) !important; background: rgba(var(--hd-accent-rgb), 0.05) !important; }
.hd-btn-primary { 
    background: var(--hd-accent) !important; 
    border: 1px solid var(--hd-accent) !important; 
    color: #fff !important; 
    font-weight: 600; 
    padding: 10px 20px; 
    border-radius: 4px !important;
    cursor: pointer; 
    transition: all 0.2s ease; 
    display: inline-flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap; 
}
.hd-btn-primary:hover:not(:disabled) { opacity: 0.9; }
.hd-btn-danger { background: var(--hd-danger) !important; border: 1px solid var(--hd-danger) !important; color: #fff !important; font-weight: 600; padding: 10px 20px; border-radius: 4px !important; cursor: pointer; transition: 0.2s; display: inline-flex; align-items: center; justify-content: center; gap: 6px; }
.hd-btn-danger:hover:not(:disabled) { opacity: 0.9; }

/* Icon Buttons for Table */
.hd-icon-btn {
    background: transparent !important;
    border: none !important;
    cursor: pointer;
    font-size: 1.15rem;
    padding: 4px 8px;
    transition: opacity 0.2s ease;
    opacity: 0.8;
}
.hd-icon-btn:hover { opacity: 1; }

/* Clean Modal & List Styling */
.hd-settings-list { border: 1px solid var(--hd-border); border-radius: 6px; background: var(--hd-bg-main); overflow: hidden; }
.hd-settings-item { display: flex; align-items: center; gap: 14px; padding: 16px 20px; margin: 0; cursor: pointer; border-bottom: 1px solid var(--hd-border); transition: background 0.2s ease; }
.hd-settings-item:last-child { border-bottom: none; }
.hd-settings-item:hover { background: rgba(127, 138, 150, 0.04); }
.hd-settings-item .form-check-input { position: relative !important; left: 0 !important; margin: 0 14px 0 0 !important; flex-shrink: 0; cursor: pointer; width: 1.2em !important; height: 1.2em !important; accent-color: var(--hd-accent); }
.hd-settings-item span.lbl-text { font-size: 0.95rem; font-weight: 500; margin-left: 4px !important; }

/* Custom Checkbox Grid - Fixed Gap */
.hd-checkbox-grid { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 20px; }
.hd-checkbox-label { display: flex !important; align-items: center !important; gap: 8px !important; cursor: pointer; font-size: 0.9rem; color: var(--hd-text-main); margin-bottom: 8px; }
.hd-checkbox-label input[type="checkbox"] { margin: 0 !important; width: 16px !important; height: 16px !important; flex-shrink: 0; accent-color: var(--hd-accent); cursor: pointer; }

/* Theme-Aware Modals */
.hd-modal-backdrop { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: transparent; z-index: 9998; display: none; }
.hd-modal { 
    position: fixed; 
    top: 50%; 
    left: 50%; 
    transform: translate(-50%, -50%); 
    width: 90%; 
    max-width: 550px; 
    background: var(--hd-card-bg); 
    color: var(--hd-text-main); 
    z-index: 9999; 
    border-radius: 8px !important; 
    box-shadow: 0 15px 40px rgba(0,0,0,0.15); 
    border: 1px solid var(--hd-border) !important; 
    display: none; 
    flex-direction: column; 
    overflow: hidden; 
    transition: background 0.3s ease, color 0.3s ease; 
}
[data-theme="dark"] .hd-modal, body.dark-mode .hd-modal { box-shadow: none !important; }
.hd-modal-header { 
    padding: 18px 24px; 
    background: transparent; 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
    border-bottom: 1px solid var(--hd-border); 
}
.hd-modal-title { font-weight: 700; font-size: 1.15rem; margin: 0; color: var(--hd-text-main) !important; }
.hd-modal-body { padding: 24px; max-height: 80vh; overflow-y: auto;}
.hd-close { font-size: 1.2rem; cursor: pointer; opacity: 0.6; background: transparent; border: none; color: var(--hd-text-main) !important; transition: opacity 0.2s; }
.hd-close:hover { opacity: 1; }
.hd-input { background: var(--hd-bg-main) !important; border: 1px solid var(--hd-border) !important; color: var(--hd-text-main) !important; border-radius: 6px !important; padding: 10px 14px; width: 100%; outline: none; transition: all 0.2s ease; }
.hd-input:focus { border-color: var(--hd-accent) !important; box-shadow: 0 0 0 2px rgba(var(--hd-accent-rgb), 0.2); }

/* Tree Builder CSS (Adapted for Blue Theme) */
.hd-tree-container {
    border: 1px solid var(--hd-border);
    border-radius: 6px;
    padding: 16px;
    background: var(--hd-bg-main);
    min-height: 160px;
    max-height: 250px;
    overflow-y: auto;
    margin-bottom: 15px;
}
.tree-node { margin: 6px 0; position: relative; }
.tree-node-children { margin-left: 26px; padding-left: 14px; border-left: 1px dashed var(--hd-border); }
.tree-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; min-height: 34px; }
.tree-folder-badge {
    display: inline-flex; align-items: center; gap: 6px;
    border: 2px solid var(--hd-accent); color: var(--hd-accent);
    border-radius: 6px; padding: 4px 10px; font-weight: 600; background: transparent;
}
.tree-folder-icon { width: 14px; height: 11px; border: 2px solid currentColor; border-radius: 3px; position: relative; display: inline-block; }
.tree-folder-icon::before { content: ""; position: absolute; top: -5px; left: 1px; width: 8px; height: 5px; border: 2px solid currentColor; border-bottom: none; border-radius: 3px 3px 0 0; background: transparent; }
.tree-ghost-folder { color: var(--hd-muted); display: inline-flex; align-items: center; gap: 8px; font-size: 0.9rem; cursor: pointer; user-select: none; opacity: 0.7; }
.tree-ghost-folder:hover { opacity: 1; color: var(--hd-accent); }
.tree-editor { display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.tree-editor input { width: 180px; height: 30px; border: 2px solid var(--hd-accent); border-radius: 4px; padding: 0 10px; outline: none; font-size: 0.9rem; background: var(--hd-bg-main); color: var(--hd-text-main); }
.tree-ok-btn { border: none; border-radius: 4px; padding: 5px 12px; cursor: pointer; font-size: 0.85rem; font-weight: 700; background: var(--hd-accent); color: #fff; }
.tree-actions { display: inline-flex; gap: 6px; margin-left: 4px; }
.tree-mini-btn { border: 1px solid var(--hd-border); background: transparent; color: var(--hd-text-main); padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; cursor: pointer; transition: 0.2s; }
.tree-mini-btn:hover { border-color: var(--hd-accent); color: var(--hd-accent); }

@media (max-width: 768px) { 
    .hd-overview-grid { grid-template-columns: 1fr; } 
}
{/literal}


/* Password reset requirements */
.hd-password-rules {
    border: 1px solid var(--hd-border);
    border-radius: 6px;
    background: rgba(var(--hd-accent-rgb), 0.04);
    padding: 12px 14px;
    font-size: 0.85rem;
    line-height: 1.55;
}
.hd-password-rule {
    display: flex;
    align-items: flex-start;
    gap: 8px;
    color: var(--hd-muted);
    margin-bottom: 4px;
}
.hd-password-rule:last-child { margin-bottom: 0; }
.hd-password-rule i { margin-top: 3px; color: var(--hd-muted); }
.hd-password-rule.is-valid { color: var(--hd-success); }
.hd-password-rule.is-valid i { color: var(--hd-success); }
.hd-password-rule.is-invalid { color: var(--hd-danger); }
.hd-password-rule.is-invalid i { color: var(--hd-danger); }
.hd-password-note {
    margin-top: 8px;
    color: var(--hd-muted);
    font-size: 0.8rem;
}
.hd-auto-snapshot-row {
    display: flex;
    flex-wrap: wrap;
    gap: 22px;
    align-items: flex-start;
}

/* Responsive improvements for phones and small tablets */
.hd-dashboard {
    max-width: 100%;
    overflow-x: hidden;
}
.hd-table-wrapper {
    -webkit-overflow-scrolling: touch;
}
#hd-snapshot-actions {
    align-items: center;
}

@media (max-width: 992px) {
    .hd-overview-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    .hd-specs-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 18px;
    }
    .hd-modal {
        width: calc(100vw - 32px);
        max-width: 620px;
    }
}

@media (max-width: 768px) {
    .hd-dashboard {
        padding-left: 4px;
        padding-right: 4px;
    }
    .hd-tab-nav {
        gap: 6px;
        margin-bottom: 18px;
        padding-bottom: 4px;
    }
    .hd-tab-nav li {
        flex: 0 0 auto;
        max-width: none;
    }
    .hd-tab-nav a {
        padding: 10px 12px;
        font-size: 0.85rem;
    }
    .hd-section-title {
        font-size: 1rem;
        margin-bottom: 14px;
    }
    .hd-table th,
    .hd-table td {
        padding: 11px 14px;
        font-size: 0.82rem;
    }
    .hd-settings-item {
        align-items: flex-start;
        gap: 10px;
    }
    .hd-settings-item .text-nowrap {
        white-space: normal !important;
    }
    #hd-snapshot-actions {
        width: 100%;
    }
    #hd-snapshot-actions button {
        flex: 1 1 220px;
    }
    .hd-auto-snapshot-row > div {
        min-width: 0 !important;
    }
}

@media (max-width: 576px) {
    .hd-dashboard {
        padding-left: 0;
        padding-right: 0;
    }
    .hd-specs-grid {
        grid-template-columns: 1fr;
        gap: 16px;
    }
    .hd-circle-gauge {
        width: 112px;
        height: 112px;
    }
    .hd-circle-gauge .val {
        font-size: 1rem;
    }
    .hd-circle-gauge .lbl {
        font-size: 0.78rem;
    }
    #hd-snapshot-actions button,
    .hd-btn-primary,
    .hd-btn-outline,
    .hd-btn-danger {
        min-height: 44px;
    }
    #hd-snapshot-actions button {
        width: 100%;
        flex: 1 1 100%;
    }
    .hd-modal {
        top: 12px;
        left: 50%;
        transform: translateX(-50%);
        width: calc(100vw - 20px);
        max-width: none;
        max-height: calc(100vh - 24px);
        border-radius: 10px !important;
    }
    .hd-modal-header {
        padding: 14px 16px;
    }
    .hd-modal-title {
        font-size: 1rem;
        line-height: 1.35;
    }
    .hd-modal-body {
        padding: 16px;
        max-height: calc(100vh - 94px);
    }
    .hd-modal .d-flex.justify-content-end {
        flex-wrap: wrap;
    }
    .hd-modal .d-flex.justify-content-end > button {
        flex: 1 1 140px;
    }
    .hd-auto-snapshot-row {
        gap: 14px;
    }
    .hd-auto-snapshot-row > div {
        flex: 1 1 100% !important;
    }
    .hd-checkbox-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 10px;
    }
    .tree-editor,
    .tree-row,
    .tree-actions {
        width: 100%;
    }
    .tree-editor input {
        width: min(100%, 220px);
    }
    .hd-responsive-table {
        border: 0;
        background: transparent;
        overflow: visible;
    }
    .hd-responsive-table .hd-table,
    .hd-responsive-table .hd-table thead,
    .hd-responsive-table .hd-table tbody,
    .hd-responsive-table .hd-table th,
    .hd-responsive-table .hd-table td,
    .hd-responsive-table .hd-table tr {
        display: block;
        width: 100%;
    }
    .hd-responsive-table .hd-table thead {
        display: none;
    }
    .hd-responsive-table .hd-table tbody tr {
        border: 1px solid var(--hd-border);
        border-radius: 10px;
        background: var(--hd-card-bg);
        margin-bottom: 12px;
        padding: 12px;
    }
    .hd-responsive-table .hd-table tbody tr:last-child {
        margin-bottom: 0;
    }
    .hd-responsive-table .hd-table td {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        padding: 10px 0;
        border-bottom: 1px solid var(--hd-border);
        white-space: normal;
        word-break: break-word;
    }
    .hd-responsive-table .hd-table td:last-child {
        border-bottom: 0;
        padding-bottom: 0;
    }
    .hd-responsive-table .hd-table td::before {
        content: attr(data-label);
        flex: 0 0 42%;
        color: var(--hd-muted);
        font-size: 0.72rem;
        font-weight: 700;
        text-transform: uppercase;
    }
    .hd-responsive-table .hd-table td[data-label="Actions"] {
        justify-content: flex-end;
    }
    .hd-responsive-table .hd-table td[data-label="Actions"]::before {
        margin-right: auto;
    }
}

@media (max-width: 380px) {
    .hd-tab-nav a {
        padding: 9px 10px;
        font-size: 0.8rem;
    }
    .hd-modal-body {
        padding: 14px;
    }
    .hd-data-pill {
        font-size: 0.78rem;
    }
}



/* Snapshot directory live-sync status */
.hd-zfs-setting {
    cursor: pointer;
}
.hd-zfs-status {
    display: none;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
    color: var(--hd-accent);
    font-weight: 700;
    font-size: 0.9rem;
    white-space: nowrap;
}
.hd-zfs-setting.is-syncing {
    opacity: 0.9;
    pointer-events: none;
}
.hd-zfs-setting.is-syncing #hd-zfs-toggle {
    display: none !important;
}
.hd-zfs-setting.is-syncing .hd-zfs-status {
    display: inline-flex;
}

@media (max-width: 576px) {
    #hd-snapshot-actions {
        margin-top: 10px;
    }
    .hd-zfs-setting {
        gap: 14px;
    }
    .hd-zfs-setting > .d-flex {
        width: 100%;
        align-items: flex-start !important;
    }
    .hd-zfs-status {
        width: 100%;
        justify-content: flex-start;
        margin-top: 8px;
    }
}


/* Subaccount directory tree + action menu */
.hd-tree-selected .tree-folder-badge,
.tree-folder-badge.is-selected {
    background: rgba(var(--hd-accent-rgb), 0.10) !important;
    color: var(--hd-accent) !important;
    border-color: var(--hd-accent) !important;
}
.tree-node-toggle {
    width: 18px;
    height: 18px;
    border: none;
    background: transparent;
    color: var(--hd-muted);
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    flex-shrink: 0;
}
.tree-node-toggle:hover { color: var(--hd-accent); }
.tree-folder-badge { cursor: pointer; }
.tree-selected-path {
    font-size: 0.8rem;
    color: var(--hd-muted);
    margin: 8px 0 12px;
    word-break: break-word;
}
.tree-selected-path code {
    color: var(--hd-text-main);
    background: rgba(127, 138, 150, 0.08);
    border: 1px solid var(--hd-border);
    border-radius: 4px;
    padding: 2px 6px;
}
.hd-actions-menu-wrap { position: relative; display: inline-flex; justify-content: flex-end; }
.hd-action-menu-trigger {
    width: 36px;
    height: 36px;
    border-radius: 50% !important;
    border: 1px solid var(--hd-border) !important;
    background: rgba(127, 138, 150, 0.08) !important;
    color: var(--hd-text-main) !important;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}
.hd-action-menu-trigger:hover { border-color: var(--hd-accent) !important; color: var(--hd-accent) !important; }
.hd-action-menu {
    position: absolute;
    right: 0;
    top: calc(100% + 8px);
    min-width: 185px;
    background: var(--hd-card-bg);
    color: var(--hd-text-main);
    border: 1px solid var(--hd-border);
    border-radius: 8px;
    box-shadow: 0 12px 28px rgba(0,0,0,0.14);
    padding: 8px;
    display: none;
    z-index: 10050;
    text-align: left;
}
.hd-actions-menu-wrap.is-open .hd-action-menu { display: block; }
.hd-action-menu button {
    width: 100%;
    border: none;
    background: transparent;
    color: var(--hd-text-main);
    text-align: left;
    padding: 10px 12px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.9rem;
}
.hd-action-menu button:hover { background: rgba(var(--hd-accent-rgb), 0.08); color: var(--hd-accent); }
.hd-action-menu button.text-danger:hover { background: rgba(209, 67, 67, 0.08); color: var(--hd-danger) !important; }
.hd-subaccount-pending-field {
    min-height: 38px;
    border-radius: 6px;
    background: linear-gradient(90deg, rgba(127,138,150,0.08), rgba(127,138,150,0.16), rgba(127,138,150,0.08));
    background-size: 200% 100%;
    animation: hdShimmer 1.2s infinite;
}
@keyframes hdShimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }

@media (max-width: 576px) {
    .hd-action-menu {
        right: 0;
        min-width: 170px;
    }
    .tree-node-children {
        margin-left: 14px;
        padding-left: 10px;
    }
}


/* Polished Subaccounts UI */
.hd-subaccounts-hero {
    border: 1px solid var(--hd-border);
    border-radius: 8px;
    background: var(--hd-card-bg);
    padding: 34px 28px;
    margin-bottom: 0;
    text-align: center;
}
.hd-subaccounts-hero h5 {
    margin: 0 0 14px;
    text-transform: uppercase;
    font-size: 1rem;
    font-weight: 800;
    color: var(--hd-text-main);
}
.hd-subaccounts-hero h5 i {
    color: var(--hd-accent);
}
.hd-subaccounts-hero p {
    max-width: 760px;
    margin: 0 auto 24px;
    color: var(--hd-muted);
    font-size: 0.95rem;
    line-height: 1.6;
}
.hd-subaccounts-table-wrap {
    margin-top: 0;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    overflow-x: visible;
}
.hd-subaccounts-table {
    table-layout: auto;
    width: 100%;
    min-width: 860px;
    white-space: normal !important;
}
.hd-subaccounts-table th,
.hd-subaccounts-table td {
    padding: 13px 18px;
    vertical-align: middle;
}
.hd-subaccounts-table th {
    font-size: 0.72rem;
    letter-spacing: 0.01em;
}
.hd-subaccount-username {
    white-space: nowrap;
}
.hd-subaccount-desc {
    max-width: 210px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.hd-subaccount-dir code {
    color: var(--hd-text-main);
    background: rgba(127, 138, 150, 0.08);
    border: 1px solid var(--hd-border);
    border-radius: 4px;
    padding: 3px 7px;
    white-space: nowrap;
}
.hd-status-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    font-size: 0.86rem;
    font-weight: 700;
}
.hd-status-icon.is-yes { color: var(--hd-success); }
.hd-status-icon.is-no { color: var(--hd-danger); }
.hd-action-menu-trigger {
    width: 34px;
    height: 34px;
    border-radius: 999px !important;
}
.hd-action-menu {
    min-width: 190px;
}
.hd-action-menu button {
    display: flex;
    align-items: center;
    gap: 10px;
}
.hd-action-menu button i {
    width: 16px;
    text-align: center;
}
.hd-subaccount-pending-field {
    border-color: transparent !important;
    color: transparent !important;
    caret-color: transparent !important;
    pointer-events: none;
}
.hd-subaccount-pending-field:focus {
    border-color: transparent !important;
    box-shadow: none !important;
}
#subDetailsModal .hd-input[readonly] {
    cursor: text;
}

@media (max-width: 1100px) {
    .hd-subaccounts-table-wrap {
        overflow-x: auto;
    }
}

@media (max-width: 768px) {
    .hd-subaccounts-hero {
        padding: 26px 18px;
    }
    .hd-subaccounts-hero p {
        font-size: 0.9rem;
    }
    .hd-subaccounts-hero .hd-btn-primary {
        width: 100%;
        max-width: 280px;
    }
    .hd-subaccounts-table-wrap {
        margin-top: 16px;
    }
}

@media (max-width: 576px) {
    #hd-subaccounts .hd-subaccounts-table-wrap {
        border: 0;
        background: transparent;
        overflow: visible;
    }
    #hd-subaccounts .hd-subaccounts-table {
        min-width: 0;
    }
    #hd-subaccounts .hd-subaccounts-table tbody tr {
        padding: 14px;
        border-radius: 12px;
        box-shadow: 0 6px 18px rgba(0,0,0,0.04);
    }
    #hd-subaccounts .hd-subaccounts-table td {
        min-height: 38px;
    }
    #hd-subaccounts .hd-subaccounts-table td::before {
        flex: 0 0 44%;
    }
    #hd-subaccounts .hd-subaccount-desc {
        max-width: none;
        white-space: normal;
        text-align: right;
    }
    #hd-subaccounts .hd-subaccount-dir code {
        white-space: normal;
        word-break: break-word;
        text-align: right;
    }
    #hd-subaccounts .hd-subaccount-actions {
        justify-content: space-between !important;
    }
    #hd-subaccounts .hd-subaccount-actions .hd-actions-menu-wrap {
        margin-left: auto;
    }
    .hd-action-menu {
        right: 0;
        top: calc(100% + 6px);
        z-index: 10080;
    }
}


/* Subaccounts final fit + directory tree spacing */
.hd-subaccounts-table-wrap { width: 100%; overflow: visible !important; }
.hd-subaccounts-table { min-width: 0 !important; table-layout: fixed !important; width: 100% !important; }
.hd-subaccounts-table th, .hd-subaccounts-table td { padding: 12px 10px !important; font-size: 0.82rem; }
.hd-subaccounts-table th:nth-child(1), .hd-subaccounts-table td:nth-child(1) { width: 15%; }
.hd-subaccounts-table th:nth-child(2), .hd-subaccounts-table td:nth-child(2) { width: 15%; }
.hd-subaccounts-table th:nth-child(3), .hd-subaccounts-table td:nth-child(3), .hd-subaccounts-table th:nth-child(4), .hd-subaccounts-table td:nth-child(4), .hd-subaccounts-table th:nth-child(5), .hd-subaccounts-table td:nth-child(5) { width: 7%; }
.hd-subaccounts-table th:nth-child(6), .hd-subaccounts-table td:nth-child(6) { width: 9%; }
.hd-subaccounts-table th:nth-child(7), .hd-subaccounts-table td:nth-child(7) { width: 9%; }
.hd-subaccounts-table th:nth-child(8), .hd-subaccounts-table td:nth-child(8) { width: 16%; }
.hd-subaccounts-table th:nth-child(9), .hd-subaccounts-table td:nth-child(9) { width: 15%; }
.hd-subaccount-actions-inline { display: inline-flex; align-items: center; justify-content: flex-end; gap: 7px; flex-wrap: nowrap; white-space: nowrap; }
.hd-subaccount-icon-action { width: 30px; height: 30px; border: 1px solid var(--hd-border) !important; border-radius: 999px !important; background: rgba(127, 138, 150, 0.06) !important; color: var(--hd-muted) !important; display: inline-flex; align-items: center; justify-content: center; padding: 0 !important; font-size: 0.82rem; cursor: pointer; transition: all 0.18s ease; }
.hd-subaccount-icon-action:hover { border-color: var(--hd-accent) !important; color: var(--hd-accent) !important; background: rgba(var(--hd-accent-rgb), 0.08) !important; }
.hd-subaccount-icon-action.is-danger:hover { border-color: var(--hd-danger) !important; color: var(--hd-danger) !important; background: rgba(209, 67, 67, 0.08) !important; }
.hd-subaccount-dir code { display: inline-block; max-width: 100%; overflow: hidden; text-overflow: ellipsis; vertical-align: middle; }
.hd-tree-container { padding: 18px !important; min-height: 180px; max-height: 310px; }
.tree-node { margin: 8px 0 !important; }
.tree-node-children { margin-left: 22px !important; padding-left: 16px !important; }
.tree-row { gap: 10px !important; min-height: 38px !important; align-items: center !important; }
.tree-folder-badge { padding: 6px 11px !important; max-width: min(100%, 280px); }
.tree-folder-badge span:last-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tree-actions { gap: 7px !important; margin-left: auto !important; flex-wrap: nowrap !important; }
.tree-mini-btn { min-height: 28px; padding: 5px 9px !important; font-size: 0.76rem !important; }
.tree-mini-btn.is-danger { color: var(--hd-danger) !important; }
.tree-mini-btn.is-danger:hover { border-color: var(--hd-danger) !important; color: var(--hd-danger) !important; }
.tree-editor { gap: 8px !important; }
.tree-editor input { width: min(100%, 230px) !important; }
.hd-checkbox-grid { display: flex !important; flex-wrap: wrap !important; column-gap: 28px !important; row-gap: 14px !important; align-items: center; }
.hd-checkbox-label { margin: 0 !important; min-height: 26px; gap: 10px !important; white-space: nowrap; }
.hd-checkbox-label input[type="checkbox"] { margin-right: 2px !important; }
@media (max-width: 1100px) { .hd-subaccounts-table-wrap { overflow-x: auto !important; } .hd-subaccounts-table { min-width: 820px !important; } }
@media (min-width: 1101px) { .hd-subaccounts-table-wrap { overflow-x: hidden !important; } }
@media (max-width: 576px) { .hd-subaccounts-table { min-width: 0 !important; } .hd-subaccount-actions-inline { justify-content: flex-end; gap: 9px; flex-wrap: wrap; } .hd-subaccount-icon-action { width: 34px; height: 34px; } .hd-tree-container { padding: 14px !important; max-height: 360px; } .tree-row { align-items: flex-start !important; gap: 8px !important; } .tree-actions { width: 100%; justify-content: flex-start; margin-left: 26px !important; margin-top: 4px; } .tree-node-children { margin-left: 12px !important; padding-left: 10px !important; } .hd-checkbox-grid { display: grid !important; grid-template-columns: 1fr !important; row-gap: 12px !important; } .hd-checkbox-label { white-space: normal; } }



/* Subaccounts full redesign: clean spacing, no cramped action menu, mobile friendly */
#hd-subaccounts {
    --hd-sub-gap: 18px;
}
#hd-subaccounts .hd-subaccounts-shell {
    width: 100%;
    max-width: 100%;
    display: flex;
    flex-direction: column;
    gap: var(--hd-sub-gap);
}
#hd-subaccounts .hd-subaccounts-hero {
    border: 1px solid var(--hd-border) !important;
    border-radius: 10px !important;
    background: var(--hd-card-bg) !important;
    padding: 32px 28px !important;
    margin: 0 !important;
    text-align: center;
}
#hd-subaccounts .hd-subaccounts-hero-icon {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: rgba(var(--hd-accent-rgb), 0.10);
    color: var(--hd-accent);
    margin-bottom: 12px;
    font-size: 1.05rem;
}
#hd-subaccounts .hd-subaccounts-hero h5 {
    margin: 0 0 12px !important;
    font-size: 1rem !important;
    font-weight: 800 !important;
    text-transform: uppercase;
    color: var(--hd-text-main) !important;
}
#hd-subaccounts .hd-subaccounts-hero p {
    max-width: 740px;
    margin: 0 auto 24px !important;
    color: var(--hd-muted);
    font-size: 0.94rem;
    line-height: 1.6;
}
#hd-subaccounts .hd-subaccount-create-btn {
    min-width: 210px;
    min-height: 46px;
}
#hd-subaccounts .hd-subaccounts-table-card {
    width: 100%;
    border: 1px solid var(--hd-border);
    border-radius: 10px;
    background: var(--hd-card-bg);
    overflow: visible;
}
#hd-subaccounts .hd-subaccounts-table-wrap {
    margin: 0 !important;
    border: 0 !important;
    border-radius: 10px !important;
    background: transparent !important;
    overflow-x: hidden !important;
}
#hd-subaccounts .hd-subaccounts-table {
    width: 100% !important;
    min-width: 0 !important;
    table-layout: fixed !important;
    white-space: normal !important;
}
#hd-subaccounts .hd-subaccounts-table th,
#hd-subaccounts .hd-subaccounts-table td {
    padding: 14px 9px !important;
    font-size: 0.80rem !important;
    vertical-align: middle !important;
}
#hd-subaccounts .hd-subaccounts-table th {
    color: var(--hd-muted) !important;
    font-size: 0.68rem !important;
    line-height: 1.15;
    letter-spacing: .02em;
    font-weight: 800 !important;
}
#hd-subaccounts .hd-subaccounts-table th:nth-child(1),
#hd-subaccounts .hd-subaccounts-table td:nth-child(1) { width: 15%; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(2),
#hd-subaccounts .hd-subaccounts-table td:nth-child(2) { width: 14%; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(3),
#hd-subaccounts .hd-subaccounts-table td:nth-child(3) { width: 5%; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(4),
#hd-subaccounts .hd-subaccounts-table td:nth-child(4) { width: 7%; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(5),
#hd-subaccounts .hd-subaccounts-table td:nth-child(5) { width: 5%; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(6),
#hd-subaccounts .hd-subaccounts-table td:nth-child(6) { width: 8%; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(7),
#hd-subaccounts .hd-subaccounts-table td:nth-child(7) { width: 8%; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(8),
#hd-subaccounts .hd-subaccounts-table td:nth-child(8) { width: 12%; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(9),
#hd-subaccounts .hd-subaccounts-table td:nth-child(9) { width: 26%; }
#hd-subaccounts .hd-subaccount-username,
#hd-subaccounts .hd-subaccount-desc {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
#hd-subaccounts .hd-subaccount-dir code {
    display: inline-block;
    max-width: 100%;
    color: var(--hd-text-main) !important;
    background: rgba(127, 138, 150, 0.08) !important;
    border: 1px solid var(--hd-border) !important;
    border-radius: 6px !important;
    padding: 4px 8px !important;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    vertical-align: middle;
}
#hd-subaccounts .hd-status-icon {
    width: 24px;
    height: 24px;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0.82rem;
}
#hd-subaccounts .hd-status-icon.is-yes { color: var(--hd-success) !important; }
#hd-subaccounts .hd-status-icon.is-no { color: var(--hd-danger) !important; }
#hd-subaccounts .hd-subaccount-actions-inline {
    display: inline-flex !important;
    justify-content: flex-end;
    align-items: center;
    gap: 6px !important;
    flex-wrap: nowrap !important;
    white-space: nowrap;
}
#hd-subaccounts .hd-subaccount-icon-action {
    width: 30px !important;
    height: 30px !important;
    min-width: 30px;
    border-radius: 999px !important;
    border: 1px solid var(--hd-border) !important;
    background: rgba(127, 138, 150, 0.06) !important;
    color: var(--hd-muted) !important;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0 !important;
    font-size: 0.82rem !important;
    cursor: pointer;
    transition: all .18s ease;
}
#hd-subaccounts .hd-subaccount-icon-action:hover {
    border-color: var(--hd-accent) !important;
    color: var(--hd-accent) !important;
    background: rgba(var(--hd-accent-rgb), .10) !important;
}
#hd-subaccounts .hd-subaccount-icon-action.is-danger:hover {
    border-color: var(--hd-danger) !important;
    color: var(--hd-danger) !important;
    background: rgba(209, 67, 67, .10) !important;
}

/* Better subaccount modal layout, directory tree and checkbox spacing */
#createSubModal,
#editSubModal,
#subDetailsModal,
#resetSubPassModal {
    max-width: 620px !important;
}
#createSubModal .hd-modal-body,
#editSubModal .hd-modal-body {
    padding: 24px 26px !important;
}
#createSubModal .hd-tree-container,
#editSubModal .hd-tree-container {
    min-height: 190px !important;
    max-height: 330px !important;
    padding: 18px !important;
    border-radius: 8px !important;
    margin-bottom: 12px !important;
}
#createSubModal .tree-node,
#editSubModal .tree-node {
    margin: 9px 0 !important;
}
#createSubModal .tree-row,
#editSubModal .tree-row {
    gap: 10px !important;
    min-height: 36px !important;
    align-items: center !important;
}
#createSubModal .tree-node-children,
#editSubModal .tree-node-children {
    margin-left: 20px !important;
    padding-left: 16px !important;
}
#createSubModal .tree-folder-badge,
#editSubModal .tree-folder-badge {
    padding: 6px 11px !important;
    max-width: min(100%, 300px) !important;
}
#createSubModal .tree-actions,
#editSubModal .tree-actions {
    gap: 7px !important;
    margin-left: 6px !important;
    flex-wrap: wrap !important;
}
#createSubModal .tree-mini-btn,
#editSubModal .tree-mini-btn {
    min-height: 30px;
    padding: 6px 10px !important;
}
#createSubModal .hd-checkbox-grid,
#editSubModal .hd-checkbox-grid {
    display: grid !important;
    grid-template-columns: repeat(auto-fit, minmax(165px, 1fr));
    gap: 14px 24px !important;
    align-items: center;
}
#createSubModal .hd-checkbox-label,
#editSubModal .hd-checkbox-label {
    display: inline-flex !important;
    align-items: center !important;
    gap: 10px !important;
    min-height: 28px;
    margin: 0 !important;
    white-space: nowrap;
}
#createSubModal .hd-checkbox-label input[type="checkbox"],
#editSubModal .hd-checkbox-label input[type="checkbox"] {
    margin: 0 !important;
    flex: 0 0 auto;
}
#subDetailsModal .hd-modal-title {
    display: inline-flex !important;
    align-items: center !important;
    gap: 12px !important;
}
#subDetailsModal .hd-modal-title .hd-inline-spinner {
    margin-right: 0 !important;
    flex: 0 0 auto;
}

@media (max-width: 992px) {
    #hd-subaccounts .hd-subaccounts-table-wrap {
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch;
    }
    #hd-subaccounts .hd-subaccounts-table {
        min-width: 820px !important;
    }
}
@media (min-width: 993px) {
    #hd-subaccounts .hd-subaccounts-table-wrap {
        overflow-x: hidden !important;
    }
}
@media (max-width: 576px) {
    #hd-subaccounts .hd-subaccounts-shell { gap: 14px; }
    #hd-subaccounts .hd-subaccounts-hero {
        padding: 24px 18px !important;
    }
    #hd-subaccounts .hd-subaccounts-hero p {
        font-size: .88rem;
        margin-bottom: 18px !important;
    }
    #hd-subaccounts .hd-subaccount-create-btn {
        width: 100%;
        min-width: 0;
    }
    #hd-subaccounts .hd-subaccounts-table-card {
        border: 0;
        background: transparent;
    }
    #hd-subaccounts .hd-subaccounts-table-wrap {
        overflow: visible !important;
    }
    #hd-subaccounts .hd-subaccounts-table {
        min-width: 0 !important;
    }
    #hd-subaccounts .hd-subaccounts-table,
    #hd-subaccounts .hd-subaccounts-table thead,
    #hd-subaccounts .hd-subaccounts-table tbody,
    #hd-subaccounts .hd-subaccounts-table tr,
    #hd-subaccounts .hd-subaccounts-table th,
    #hd-subaccounts .hd-subaccounts-table td {
        display: block;
        width: 100% !important;
    }
    #hd-subaccounts .hd-subaccounts-table thead { display: none; }
    #hd-subaccounts .hd-subaccounts-table tbody tr {
        border: 1px solid var(--hd-border);
        border-radius: 12px;
        background: var(--hd-card-bg);
        margin-bottom: 14px;
        padding: 14px 16px;
    }
    #hd-subaccounts .hd-subaccounts-table td {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        min-height: 42px;
        padding: 10px 0 !important;
        border-bottom: 1px solid var(--hd-border);
        white-space: normal;
        word-break: break-word;
    }
    #hd-subaccounts .hd-subaccounts-table td:last-child { border-bottom: 0; }
    #hd-subaccounts .hd-subaccounts-table td::before {
        content: attr(data-label);
        flex: 0 0 44%;
        color: var(--hd-muted);
        font-size: 0.72rem;
        font-weight: 800;
        text-transform: uppercase;
    }
    #hd-subaccounts .hd-subaccount-desc,
    #hd-subaccounts .hd-subaccount-username {
        max-width: none;
        white-space: normal;
        text-align: right;
    }
    #hd-subaccounts .hd-subaccount-dir code {
        white-space: normal;
        word-break: break-word;
        text-align: right;
    }
    #hd-subaccounts .hd-subaccount-actions-inline {
        gap: 10px !important;
        flex-wrap: wrap !important;
        justify-content: flex-end;
    }
    #hd-subaccounts .hd-subaccount-icon-action {
        width: 36px !important;
        height: 36px !important;
        min-width: 36px;
    }
    #createSubModal,
    #editSubModal,
    #subDetailsModal,
    #resetSubPassModal {
        max-width: none !important;
    }
    #createSubModal .hd-modal-body,
    #editSubModal .hd-modal-body {
        padding: 18px !important;
    }
    #createSubModal .hd-checkbox-grid,
    #editSubModal .hd-checkbox-grid {
        grid-template-columns: 1fr !important;
        gap: 12px !important;
    }
    #createSubModal .tree-actions,
    #editSubModal .tree-actions {
        width: 100%;
        margin-left: 28px !important;
        margin-top: 4px;
    }
}


/* Final Subaccounts width/copy/live-directory overrides */
#hd-subaccounts .hd-subaccounts-shell {
    box-sizing: border-box;
    padding-left: 20px !important;
    padding-right: 20px !important;
}
#hd-subaccounts .hd-subaccounts-table th,
#hd-subaccounts .hd-subaccounts-table td {
    padding: 11px 6px !important;
    font-size: 0.76rem !important;
}
#hd-subaccounts .hd-subaccounts-table th:nth-child(1),
#hd-subaccounts .hd-subaccounts-table td:nth-child(1) { width: 14% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(2),
#hd-subaccounts .hd-subaccounts-table td:nth-child(2) { width: 12% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(3),
#hd-subaccounts .hd-subaccounts-table td:nth-child(3) { width: 5% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(4),
#hd-subaccounts .hd-subaccounts-table td:nth-child(4) { width: 6% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(5),
#hd-subaccounts .hd-subaccounts-table td:nth-child(5) { width: 5% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(6),
#hd-subaccounts .hd-subaccounts-table td:nth-child(6) { width: 8% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(7),
#hd-subaccounts .hd-subaccounts-table td:nth-child(7) { width: 7% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(8),
#hd-subaccounts .hd-subaccounts-table td:nth-child(8) { width: 22% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(9),
#hd-subaccounts .hd-subaccounts-table td:nth-child(9) { width: 21% !important; }
.hd-subaccount-copy-pill {
    width: 100%;
    max-width: 100%;
    border: 1px solid transparent !important;
    background: transparent !important;
    color: inherit !important;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 2px 4px !important;
    border-radius: 6px !important;
    cursor: pointer;
    text-align: left;
}
.hd-subaccount-copy-pill span,
.hd-subaccount-copy-pill code {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.hd-subaccount-copy-pill i {
    color: var(--hd-muted);
    font-size: 0.78rem;
    flex: 0 0 auto;
}
.hd-subaccount-copy-pill:hover {
    border-color: var(--hd-accent) !important;
    background: rgba(var(--hd-accent-rgb), 0.08) !important;
}
.hd-copy-input-row {
    display: flex;
    align-items: stretch;
    gap: 8px;
}
.hd-copy-input-row .hd-input {
    min-width: 0;
    flex: 1 1 auto;
    margin-bottom: 0 !important;
}
.hd-copy-field-btn {
    width: 42px;
    border: 1px solid var(--hd-border) !important;
    border-radius: 6px !important;
    background: rgba(127,138,150,0.06) !important;
    color: var(--hd-muted) !important;
    cursor: pointer;
}
.hd-copy-field-btn:hover {
    border-color: var(--hd-accent) !important;
    color: var(--hd-accent) !important;
    background: rgba(var(--hd-accent-rgb),0.08) !important;
}
.tree-directory-rule,
.tree-sync-status {
    color: var(--hd-muted);
    font-size: 0.78rem;
    line-height: 1.35;
}
.tree-sync-status.is-loading { color: var(--hd-accent); font-weight: 700; }
.tree-folder-badge.is-existing .tree-folder-icon::after { opacity: .65; }
#createSubModal .tree-mini-btn.is-existing-action {
    display: none !important;
}
@media (min-width: 993px) {
    #hd-subaccounts .hd-subaccounts-table-wrap { overflow-x: hidden !important; }
    #hd-subaccounts .hd-subaccounts-table { min-width: 0 !important; }
}
@media (max-width: 992px) {
    #hd-subaccounts .hd-subaccounts-shell { padding-left: 0 !important; padding-right: 0 !important; }
    #hd-subaccounts .hd-subaccounts-table { min-width: 820px !important; }
}
@media (max-width: 576px) {
    #hd-subaccounts .hd-subaccounts-table { min-width: 0 !important; }
    .hd-copy-input-row { gap: 6px; }
    .hd-copy-field-btn { width: 40px; }
}



/* Customer-safe subaccount directory picker + 864px full-HD fit */
body.hd-modal-open {
    overflow: hidden !important;
    touch-action: none;
}
.hd-modal-backdrop {
    background: rgba(0, 0, 0, 0.55) !important;
    pointer-events: auto !important;
}
#hd-subaccounts .hd-subaccounts-shell {
    width: min(864px, calc(100% - 40px)) !important;
    max-width: 864px !important;
    margin-left: auto !important;
    margin-right: auto !important;
}
#hd-subaccounts .hd-subaccounts-hero,
#hd-subaccounts .hd-subaccounts-table-card {
    width: 100% !important;
}
#hd-subaccounts .hd-subaccounts-table th,
#hd-subaccounts .hd-subaccounts-table td {
    padding: 12px 7px !important;
    font-size: 0.78rem !important;
}
#hd-subaccounts .hd-subaccounts-table th:nth-child(1),
#hd-subaccounts .hd-subaccounts-table td:nth-child(1) { width: 16% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(2),
#hd-subaccounts .hd-subaccounts-table td:nth-child(2) { width: 14% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(3),
#hd-subaccounts .hd-subaccounts-table td:nth-child(3) { width: 5% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(4),
#hd-subaccounts .hd-subaccounts-table td:nth-child(4) { width: 6% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(5),
#hd-subaccounts .hd-subaccounts-table td:nth-child(5) { width: 5% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(6),
#hd-subaccounts .hd-subaccounts-table td:nth-child(6) { width: 8% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(7),
#hd-subaccounts .hd-subaccounts-table td:nth-child(7) { width: 8% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(8),
#hd-subaccounts .hd-subaccounts-table td:nth-child(8) { width: 19% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(9),
#hd-subaccounts .hd-subaccounts-table td:nth-child(9) { width: 18% !important; }
#hd-subaccounts .hd-subaccount-copy-pill {
    width: 100%;
    max-width: 100%;
    display: inline-flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    border: 1px solid var(--hd-border) !important;
    background: rgba(127, 138, 150, 0.07) !important;
    color: var(--hd-text-main) !important;
    border-radius: 6px !important;
    padding: 5px 7px !important;
    cursor: pointer;
    min-width: 0;
}
#hd-subaccounts .hd-subaccount-copy-pill span,
#hd-subaccounts .hd-subaccount-copy-pill code {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    border: 0 !important;
    background: transparent !important;
    padding: 0 !important;
}
#hd-subaccounts .hd-subaccount-copy-pill i {
    flex: 0 0 auto;
    color: var(--hd-muted);
    font-size: 0.78rem;
}
#hd-subaccounts .hd-subaccount-copy-pill:hover {
    border-color: var(--hd-accent) !important;
    color: var(--hd-accent) !important;
}
#hd-subaccounts .hd-subaccount-actions-inline {
    gap: 5px !important;
}
#hd-subaccounts .hd-subaccount-icon-action {
    width: 29px !important;
    height: 29px !important;
    min-width: 29px !important;
}
#createSubModal .hd-checkbox-grid,
#editSubModal .hd-checkbox-grid {
    display: grid !important;
    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
    gap: 12px 18px !important;
    align-items: center !important;
}
#createSubModal .hd-checkbox-label,
#editSubModal .hd-checkbox-label {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: flex-start !important;
    gap: 9px !important;
    margin: 0 !important;
    padding: 0 !important;
    min-height: 24px !important;
    white-space: nowrap !important;
    line-height: 1.2 !important;
}
#createSubModal .hd-checkbox-label .form-check-input,
#editSubModal .hd-checkbox-label .form-check-input,
#createSubModal .hd-checkbox-label input[type="checkbox"],
#editSubModal .hd-checkbox-label input[type="checkbox"] {
    position: static !important;
    float: none !important;
    margin: 0 !important;
    margin-left: 0 !important;
    margin-right: 0 !important;
    flex: 0 0 16px !important;
    width: 16px !important;
    height: 16px !important;
    transform: none !important;
}
#createSubModal .tree-actions .tree-mini-btn.is-danger,
#editSubModal .tree-actions .tree-mini-btn.is-danger,
#createSubModal .tree-actions .tree-mini-btn .fa-pen,
#editSubModal .tree-actions .tree-mini-btn .fa-pen {
    display: none !important;
}
.tree-folder-badge.is-existing::after {
    content: "Existing";
    margin-left: 8px;
    font-size: 0.68rem;
    font-weight: 700;
    color: var(--hd-muted);
    opacity: .78;
}
@media (max-width: 992px) {
    #hd-subaccounts .hd-subaccounts-shell {
        width: min(864px, calc(100% - 24px)) !important;
    }
}
@media (max-width: 576px) {
    #hd-subaccounts .hd-subaccounts-shell {
        width: 100% !important;
        max-width: 100% !important;
    }
    #createSubModal .hd-checkbox-grid,
    #editSubModal .hd-checkbox-grid {
        grid-template-columns: 1fr !important;
    }
    #createSubModal .hd-checkbox-label,
    #editSubModal .hd-checkbox-label {
        white-space: normal !important;
    }
}


/* V3 Subaccounts final fix: safe 864px desktop table and readable mobile cards */
#hd-subaccounts .hd-subaccounts-shell {
    width: min(864px, calc(100% - 40px)) !important;
    max-width: 864px !important;
    margin-left: auto !important;
    margin-right: auto !important;
    padding-left: 0 !important;
    padding-right: 0 !important;
}
#hd-subaccounts .hd-subaccounts-table-card,
#hd-subaccounts .hd-subaccounts-table-wrap {
    width: 100% !important;
    max-width: 100% !important;
}
#hd-subaccounts .hd-subaccounts-table {
    width: 100% !important;
    min-width: 0 !important;
    table-layout: fixed !important;
    border-collapse: separate !important;
}
#hd-subaccounts .hd-subaccounts-table th,
#hd-subaccounts .hd-subaccounts-table td {
    padding: 10px 5px !important;
    font-size: 0.74rem !important;
    line-height: 1.2 !important;
    vertical-align: middle !important;
}
#hd-subaccounts .hd-subaccounts-table th {
    font-size: 0.58rem !important;
    letter-spacing: 0 !important;
    white-space: nowrap !important;
    overflow: hidden !important;
    text-overflow: clip !important;
    word-break: normal !important;
    overflow-wrap: normal !important;
}
#hd-subaccounts .hd-subaccounts-table th:nth-child(1),
#hd-subaccounts .hd-subaccounts-table td:nth-child(1) { width: 15% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(2),
#hd-subaccounts .hd-subaccounts-table td:nth-child(2) { width: 12% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(3),
#hd-subaccounts .hd-subaccounts-table td:nth-child(3) { width: 5% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(4),
#hd-subaccounts .hd-subaccounts-table td:nth-child(4) { width: 7% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(5),
#hd-subaccounts .hd-subaccounts-table td:nth-child(5) { width: 5% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(6),
#hd-subaccounts .hd-subaccounts-table td:nth-child(6) { width: 8% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(7),
#hd-subaccounts .hd-subaccounts-table td:nth-child(7) { width: 8% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(8),
#hd-subaccounts .hd-subaccounts-table td:nth-child(8) { width: 20% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(9),
#hd-subaccounts .hd-subaccounts-table td:nth-child(9) { width: 20% !important; }
#hd-subaccounts .hd-subaccount-actions-inline {
    gap: 4px !important;
    justify-content: flex-end !important;
}
#hd-subaccounts .hd-subaccount-icon-action {
    width: 28px !important;
    height: 28px !important;
    min-width: 28px !important;
    font-size: 0.76rem !important;
}
#hd-subaccounts .hd-subaccount-copy-pill {
    min-width: 0 !important;
    max-width: 100% !important;
}
#createSubModal .hd-checkbox-label,
#editSubModal .hd-checkbox-label {
    pointer-events: auto !important;
    user-select: none;
}
#createSubModal .hd-checkbox-label .form-check-input,
#editSubModal .hd-checkbox-label .form-check-input {
    pointer-events: auto !important;
    opacity: 1 !important;
}
@media (min-width: 993px) {
    #hd-subaccounts .hd-subaccounts-table-wrap { overflow-x: hidden !important; }
}
@media (max-width: 992px) {
    #hd-subaccounts .hd-subaccounts-shell {
        width: min(864px, calc(100% - 24px)) !important;
        max-width: 864px !important;
    }
    #hd-subaccounts .hd-subaccounts-table-wrap { overflow-x: auto !important; }
    #hd-subaccounts .hd-subaccounts-table { min-width: 820px !important; }
}
@media (max-width: 576px) {
    #hd-subaccounts .hd-subaccounts-shell {
        width: 100% !important;
        max-width: 100% !important;
        padding-left: 12px !important;
        padding-right: 12px !important;
    }
    #hd-subaccounts .hd-subaccounts-table-card {
        border: 0 !important;
        background: transparent !important;
    }
    #hd-subaccounts .hd-subaccounts-table-wrap {
        overflow: visible !important;
        border: 0 !important;
        background: transparent !important;
    }
    #hd-subaccounts .hd-subaccounts-table,
    #hd-subaccounts .hd-subaccounts-table thead,
    #hd-subaccounts .hd-subaccounts-table tbody,
    #hd-subaccounts .hd-subaccounts-table tr,
    #hd-subaccounts .hd-subaccounts-table th,
    #hd-subaccounts .hd-subaccounts-table td {
        display: block !important;
        width: 100% !important;
        min-width: 0 !important;
    }
    #hd-subaccounts .hd-subaccounts-table thead { display: none !important; }
    #hd-subaccounts .hd-subaccounts-table tbody tr {
        display: block !important;
        border: 1px solid var(--hd-border) !important;
        border-radius: 12px !important;
        background: var(--hd-card-bg) !important;
        margin-bottom: 14px !important;
        padding: 14px !important;
    }
    #hd-subaccounts .hd-subaccounts-table td {
        display: grid !important;
        grid-template-columns: 118px minmax(0, 1fr) !important;
        align-items: center !important;
        gap: 12px !important;
        min-height: 42px !important;
        padding: 9px 0 !important;
        border-bottom: 1px solid var(--hd-border) !important;
        text-align: right !important;
        white-space: normal !important;
        word-break: normal !important;
        overflow-wrap: anywhere !important;
    }
    #hd-subaccounts .hd-subaccounts-table td:last-child { border-bottom: 0 !important; }
    #hd-subaccounts .hd-subaccounts-table td::before {
        content: attr(data-label) !important;
        display: block !important;
        width: 118px !important;
        max-width: 118px !important;
        min-width: 0 !important;
        flex: none !important;
        color: var(--hd-muted) !important;
        font-size: 0.70rem !important;
        font-weight: 800 !important;
        text-transform: uppercase !important;
        text-align: left !important;
        white-space: nowrap !important;
        word-break: normal !important;
        overflow-wrap: normal !important;
        line-height: 1.2 !important;
    }
    #hd-subaccounts .hd-subaccount-username,
    #hd-subaccounts .hd-subaccount-desc,
    #hd-subaccounts .hd-subaccount-dir,
    #hd-subaccounts .hd-subaccount-actions {
        min-width: 0 !important;
        max-width: 100% !important;
    }
    #hd-subaccounts .hd-subaccount-copy-pill {
        justify-self: end !important;
        width: min(100%, 210px) !important;
        text-align: right !important;
    }
    #hd-subaccounts .hd-status-icon {
        justify-self: end !important;
    }
    #hd-subaccounts .hd-subaccount-actions-inline {
        justify-content: flex-end !important;
        gap: 8px !important;
        flex-wrap: wrap !important;
    }
    #hd-subaccounts .hd-subaccount-icon-action {
        width: 34px !important;
        height: 34px !important;
        min-width: 34px !important;
    }
}
@media (max-width: 380px) {
    #hd-subaccounts .hd-subaccounts-table td {
        grid-template-columns: 96px minmax(0, 1fr) !important;
        gap: 8px !important;
    }
    #hd-subaccounts .hd-subaccounts-table td::before {
        width: 96px !important;
        max-width: 96px !important;
        font-size: 0.64rem !important;
    }
}

/* FINAL CLEANUP: equal tab spacing + compact footer gap */
.hd-dashboard {
    --hd-tab-footer-gap: 18px;
    margin-top: 0 !important;
    padding-bottom: var(--hd-tab-footer-gap) !important;
    overflow-x: hidden !important;
}

.hd-tab-nav {
    margin: 0 0 18px !important;
}

.hd-tab-content,
.hd-tab-content.active,
.hd-panel,
#hd-overview,
#hd-access,
#hd-snapshots,
#hd-subaccounts {
    min-height: 0 !important;
}

.hd-tab-content {
    padding-bottom: var(--hd-tab-footer-gap) !important;
}

.hd-panel {
    padding: 0 !important;
    margin-bottom: 0 !important;
}

.hd-panel > :last-child,
.hd-tab-content > :last-child {
    margin-bottom: 0 !important;
}

.hd-table-wrapper {
    margin-bottom: 0 !important;
}

.hd-specs-wrapper {
    margin-bottom: 18px !important;
    padding-bottom: 0 !important;
}

.hd-overview-grid {
    margin-bottom: 0 !important;
}

#hd-subaccounts .hd-subaccounts-shell {
    gap: 18px !important;
    padding-bottom: 0 !important;
}

#hd-subaccounts .hd-subaccounts-table-card {
    margin-bottom: 0 !important;
}

#hd-snapshots .hd-table-wrapper,
#hd-subaccounts .hd-subaccounts-table-wrap {
    margin-bottom: 0 !important;
}

/* Edit/Create subaccount directory sync status spacing */
#createSubModal .tree-sync-status,
#editSubModal .tree-sync-status {
    display: block !important;
    margin: 10px 0 12px !important;
    text-align: center !important;
    min-height: 18px !important;
}

#cs-addRootBtn,
#cs-resetBtn,
#es-addRootBtn,
#es-resetBtn {
    margin-top: 6px !important;
}

/* Hidden by JS */
.hd-hide-native-product-block {
    display: none !important;
}


/* FINAL REQUEST FIX: keep scrollbar stable, small centered notifications, 864px subaccount layout, mobile cards */
html { scrollbar-gutter: stable !important; }
body.hd-modal-open {
    overflow-y: auto !important;
    overflow-x: auto !important;
    touch-action: auto !important;
    position: static !important;
    padding-right: 0 !important;
}
.hd-modal,
.hd-modal *,
.hd-table-wrapper,
.hd-table,
.hd-subaccounts-hero,
.hd-subaccounts-table-card,
.hd-subaccounts-table tbody tr,
.hd-btn-primary,
.hd-btn-outline,
.hd-btn-danger,
.hd-input,
.hd-settings-list,
.hd-settings-item,
.hd-subaccount-icon-action,
.hd-subaccount-copy-pill,
.tree-folder-badge,
.tree-mini-btn,
.tree-ok-btn { border-radius: 0.25rem !important; }
#notificationModal {
    width: min(420px, calc(100vw - 32px)) !important;
    max-width: 420px !important;
    top: 50% !important;
    left: 50% !important;
    transform: translate(-50%, -50%) !important;
    z-index: 10080 !important;
}
#notificationModal .hd-modal-header { padding: 12px 16px !important; }
#notificationModal .hd-modal-body {
    padding: 16px 20px 20px !important;
    max-height: calc(100vh - 80px) !important;
}
#notificationModal #notif-icon {
    font-size: 2.15rem !important;
    margin-top: 6px !important;
    margin-bottom: 12px !important;
}
#notificationModal #notif-msg {
    margin-bottom: 16px !important;
    font-size: 0.92rem !important;
}
#notificationModal .hd-btn-primary {
    min-height: 40px !important;
    padding: 8px 16px !important;
}
#hd-subaccounts .hd-subaccounts-shell {
    width: min(864px, calc(100% - 40px)) !important;
    max-width: 864px !important;
    margin-left: auto !important;
    margin-right: auto !important;
}
#hd-subaccounts .hd-subaccounts-hero { padding: 30px 28px !important; }
#hd-subaccounts .hd-subaccounts-table-card { overflow: hidden !important; }
#hd-subaccounts .hd-subaccounts-table-wrap { overflow-x: hidden !important; }
#hd-subaccounts .hd-subaccounts-table {
    min-width: 0 !important;
    width: 100% !important;
    table-layout: fixed !important;
}
#hd-subaccounts .hd-subaccounts-table th,
#hd-subaccounts .hd-subaccounts-table td {
    padding: 10px 6px !important;
    font-size: 0.74rem !important;
    line-height: 1.22 !important;
}
#hd-subaccounts .hd-subaccounts-table th:nth-child(1),
#hd-subaccounts .hd-subaccounts-table td:nth-child(1) { width: 15% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(2),
#hd-subaccounts .hd-subaccounts-table td:nth-child(2) { width: 12% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(3),
#hd-subaccounts .hd-subaccounts-table td:nth-child(3) { width: 5% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(4),
#hd-subaccounts .hd-subaccounts-table td:nth-child(4) { width: 7% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(5),
#hd-subaccounts .hd-subaccounts-table td:nth-child(5) { width: 5% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(6),
#hd-subaccounts .hd-subaccounts-table td:nth-child(6) { width: 8% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(7),
#hd-subaccounts .hd-subaccounts-table td:nth-child(7) { width: 8% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(8),
#hd-subaccounts .hd-subaccounts-table td:nth-child(8) { width: 20% !important; }
#hd-subaccounts .hd-subaccounts-table th:nth-child(9),
#hd-subaccounts .hd-subaccounts-table td:nth-child(9) { width: 20% !important; }
#hd-subaccounts .hd-subaccount-actions-inline {
    display: inline-flex !important;
    gap: 5px !important;
    justify-content: flex-end !important;
    align-items: center !important;
    flex-wrap: nowrap !important;
}
#hd-subaccounts .hd-subaccount-icon-action {
    width: 28px !important;
    height: 28px !important;
    min-width: 28px !important;
    border-radius: 50% !important;
}
#hd-subaccounts .hd-subaccount-copy-pill {
    min-width: 0 !important;
    width: 100% !important;
    max-width: 100% !important;
}
@media (max-width: 700px) {
    #hd-subaccounts .hd-subaccounts-shell {
        width: 100% !important;
        max-width: 100% !important;
        padding-left: 14px !important;
        padding-right: 14px !important;
        gap: 16px !important;
    }
    #hd-subaccounts .hd-subaccounts-hero { padding: 24px 18px !important; }
    #hd-subaccounts .hd-subaccounts-hero p {
        font-size: 0.88rem !important;
        line-height: 1.55 !important;
    }
    #hd-subaccounts .hd-subaccount-create-btn {
        width: 100% !important;
        min-width: 0 !important;
    }
    #hd-subaccounts .hd-subaccounts-table-card,
    #hd-subaccounts .hd-subaccounts-table-wrap {
        border: 0 !important;
        background: transparent !important;
        overflow: visible !important;
    }
    #hd-subaccounts .hd-subaccounts-table,
    #hd-subaccounts .hd-subaccounts-table thead,
    #hd-subaccounts .hd-subaccounts-table tbody,
    #hd-subaccounts .hd-subaccounts-table tr,
    #hd-subaccounts .hd-subaccounts-table th,
    #hd-subaccounts .hd-subaccounts-table td {
        display: block !important;
        width: 100% !important;
        min-width: 0 !important;
    }
    #hd-subaccounts .hd-subaccounts-table thead { display: none !important; }
    #hd-subaccounts .hd-subaccounts-table tbody tr {
        background: var(--hd-card-bg) !important;
        border: 1px solid var(--hd-border) !important;
        margin-bottom: 14px !important;
        padding: 14px 16px !important;
        box-shadow: none !important;
    }
    #hd-subaccounts .hd-subaccounts-table td {
        display: grid !important;
        grid-template-columns: 116px minmax(0, 1fr) !important;
        align-items: center !important;
        gap: 12px !important;
        min-height: 42px !important;
        padding: 10px 0 !important;
        border-bottom: 1px solid var(--hd-border) !important;
        text-align: right !important;
        white-space: normal !important;
        word-break: normal !important;
        overflow-wrap: anywhere !important;
    }
    #hd-subaccounts .hd-subaccounts-table td:last-child { border-bottom: 0 !important; }
    #hd-subaccounts .hd-subaccounts-table td::before {
        content: attr(data-label) !important;
        width: 116px !important;
        max-width: 116px !important;
        min-width: 0 !important;
        color: var(--hd-muted) !important;
        font-size: 0.70rem !important;
        font-weight: 800 !important;
        text-transform: uppercase !important;
        text-align: left !important;
        white-space: nowrap !important;
        line-height: 1.2 !important;
    }
    #hd-subaccounts .hd-subaccount-username,
    #hd-subaccounts .hd-subaccount-desc,
    #hd-subaccounts .hd-subaccount-dir,
    #hd-subaccounts .hd-subaccount-actions {
        max-width: 100% !important;
        min-width: 0 !important;
        text-align: right !important;
    }
    #hd-subaccounts .hd-subaccount-copy-pill {
        justify-self: end !important;
        width: min(100%, 220px) !important;
        text-align: right !important;
    }
    #hd-subaccounts .hd-subaccount-copy-pill span,
    #hd-subaccounts .hd-subaccount-copy-pill code {
        max-width: 100% !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        white-space: nowrap !important;
    }
    #hd-subaccounts .hd-status-icon { justify-self: end !important; }
    #hd-subaccounts .hd-subaccount-actions-inline {
        justify-content: flex-end !important;
        gap: 8px !important;
        flex-wrap: wrap !important;
    }
    #hd-subaccounts .hd-subaccount-icon-action {
        width: 36px !important;
        height: 36px !important;
        min-width: 36px !important;
    }
    #hd-snapshots .hd-responsive-table .hd-table td[data-label="Actions"] {
        justify-content: flex-start !important;
        text-align: left !important;
    }
    #hd-snapshots .hd-responsive-table .hd-table td[data-label="Actions"]::before { margin-right: 0 !important; }
    #hd-snapshots .hd-responsive-table .hd-table td[data-label="Actions"] > div {
        justify-content: flex-start !important;
        margin-left: 0 !important;
    }
}
@media (max-width: 380px) {
    #hd-subaccounts .hd-subaccounts-table td {
        grid-template-columns: 94px minmax(0, 1fr) !important;
        gap: 8px !important;
    }
    #hd-subaccounts .hd-subaccounts-table td::before {
        width: 94px !important;
        max-width: 94px !important;
        font-size: 0.64rem !important;
    }
    #hd-subaccounts .hd-subaccount-copy-pill { width: min(100%, 190px) !important; }
}


/* REBUILT SUBACCOUNTS RESPONSIVE FIX: 864px desktop, clean mobile card, full-width fields */
#hd-subaccounts .hd-subaccounts-shell {
    width: min(864px, calc(100% - 40px)) !important;
    max-width: 864px !important;
    margin-left: auto !important;
    margin-right: auto !important;
    padding-left: 0 !important;
    padding-right: 0 !important;
}
#hd-subaccounts .hd-subaccounts-table-card,
#hd-subaccounts .hd-subaccounts-hero {
    width: 100% !important;
    max-width: 864px !important;
}
#hd-subaccounts .hd-subaccounts-table th:nth-child(9) {
    color: transparent !important;
    font-size: 0 !important;
    line-height: 0 !important;
}
#hd-subaccounts .hd-subaccounts-table th:nth-child(9)::after { content: "" !important; }

@media (max-width: 700px) {
    #hd-subaccounts .hd-subaccounts-shell {
        width: 100% !important;
        max-width: 100% !important;
        padding-left: 14px !important;
        padding-right: 14px !important;
        gap: 16px !important;
    }
    #hd-subaccounts .hd-subaccounts-hero { padding: 24px 18px !important; }
    #hd-subaccounts .hd-subaccounts-hero p {
        font-size: 0.88rem !important;
        line-height: 1.55 !important;
    }
    #hd-subaccounts .hd-subaccount-create-btn {
        width: 100% !important;
        min-width: 0 !important;
    }
    #hd-subaccounts .hd-subaccounts-table-card,
    #hd-subaccounts .hd-subaccounts-table-wrap {
        border: 0 !important;
        background: transparent !important;
        overflow: visible !important;
    }
    #hd-subaccounts .hd-subaccounts-table,
    #hd-subaccounts .hd-subaccounts-table thead,
    #hd-subaccounts .hd-subaccounts-table tbody,
    #hd-subaccounts .hd-subaccounts-table tr,
    #hd-subaccounts .hd-subaccounts-table th,
    #hd-subaccounts .hd-subaccounts-table td {
        display: block !important;
        width: 100% !important;
        min-width: 0 !important;
    }
    #hd-subaccounts .hd-subaccounts-table thead { display: none !important; }
    #hd-subaccounts .hd-subaccounts-table tbody tr {
        display: grid !important;
        grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
        gap: 0 !important;
        background: var(--hd-card-bg) !important;
        border: 1px solid var(--hd-border) !important;
        border-radius: 0.25rem !important;
        margin-bottom: 14px !important;
        padding: 14px 16px !important;
        box-shadow: none !important;
    }
    #hd-subaccounts .hd-subaccounts-table td {
        min-height: 0 !important;
        padding: 0 !important;
        border-bottom: 0 !important;
        text-align: left !important;
        white-space: normal !important;
        word-break: normal !important;
        overflow-wrap: anywhere !important;
    }
    #hd-subaccounts .hd-subaccounts-table td::before {
        content: attr(data-label) !important;
        color: var(--hd-muted) !important;
        font-size: 0.68rem !important;
        font-weight: 800 !important;
        text-transform: uppercase !important;
        text-align: left !important;
        white-space: nowrap !important;
        line-height: 1.2 !important;
    }

    /* Username, description and base directory stretch horizontally across the card */
    #hd-subaccounts .hd-subaccounts-table td[data-label="Username"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="Description"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="Base dir."] {
        grid-column: 1 / -1 !important;
        display: grid !important;
        grid-template-columns: 92px minmax(0, 1fr) !important;
        align-items: center !important;
        column-gap: 12px !important;
        width: 100% !important;
        margin-bottom: 8px !important;
    }
    #hd-subaccounts .hd-subaccount-username,
    #hd-subaccounts .hd-subaccount-desc,
    #hd-subaccounts .hd-subaccount-dir {
        max-width: 100% !important;
        min-width: 0 !important;
        width: 100% !important;
        text-align: left !important;
        white-space: normal !important;
        overflow: visible !important;
        text-overflow: clip !important;
    }
    #hd-subaccounts .hd-subaccount-copy-pill {
        justify-self: stretch !important;
        width: 100% !important;
        max-width: 100% !important;
        min-height: 36px !important;
        text-align: left !important;
        justify-content: space-between !important;
    }
    #hd-subaccounts .hd-subaccount-copy-pill span,
    #hd-subaccounts .hd-subaccount-copy-pill code {
        white-space: normal !important;
        overflow: visible !important;
        text-overflow: clip !important;
        word-break: break-word !important;
    }

    /* Option table: two columns, auto order gives SMB/SSH/Read-only left and WebDAV/Ext. reach right */
    #hd-subaccounts .hd-subaccounts-table td[data-label="SMB"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="WebDAV"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="SSH"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="Ext. reach."],
    #hd-subaccounts .hd-subaccounts-table td[data-label="Read-only"] {
        display: flex !important;
        flex-direction: row !important;
        align-items: center !important;
        justify-content: flex-start !important;
        gap: 5px !important;
        min-height: 36px !important;
        padding: 7px 8px !important;
        border: 1px solid var(--hd-border) !important;
        margin: 0 -1px -1px 0 !important;
        background: transparent !important;
    }
    #hd-subaccounts .hd-subaccounts-table td[data-label="SMB"]::before,
    #hd-subaccounts .hd-subaccounts-table td[data-label="WebDAV"]::before,
    #hd-subaccounts .hd-subaccounts-table td[data-label="SSH"]::before,
    #hd-subaccounts .hd-subaccounts-table td[data-label="Ext. reach."]::before,
    #hd-subaccounts .hd-subaccounts-table td[data-label="Read-only"]::before {
        font-size: 0.86rem !important;
        color: var(--hd-text-main) !important;
        font-weight: 700 !important;
        text-transform: none !important;
    }
    #hd-subaccounts .hd-status-icon {
        width: auto !important;
        height: auto !important;
        min-width: 0 !important;
        font-size: 0.9rem !important;
    }
    #hd-subaccounts .hd-status-icon.is-yes { color: #00e676 !important; }
    #hd-subaccounts .hd-status-icon.is-no { color: var(--hd-danger) !important; }

    /* Base directory after option table, stretched full width */
    #hd-subaccounts .hd-subaccounts-table td[data-label="Base dir."] {
        margin-top: 10px !important;
        margin-bottom: 10px !important;
    }

    /* Bottom button stack: four equal horizontal buttons, left-to-right */
    #hd-subaccounts .hd-subaccounts-table td[data-label="Actions"] {
        grid-column: 1 / -1 !important;
        display: block !important;
        width: 100% !important;
        margin-top: 4px !important;
    }
    #hd-subaccounts .hd-subaccounts-table td[data-label="Actions"]::before {
        content: "" !important;
        display: none !important;
    }
    #hd-subaccounts .hd-subaccount-actions-inline {
        width: 100% !important;
        display: grid !important;
        grid-template-columns: repeat(4, minmax(0, 1fr)) !important;
        gap: 8px !important;
        justify-content: stretch !important;
        align-items: stretch !important;
    }
    #hd-subaccounts .hd-subaccount-icon-action {
        width: 100% !important;
        height: 38px !important;
        min-width: 0 !important;
        border-radius: 0.25rem !important;
    }
}

@media (max-width: 380px) {
    #hd-subaccounts .hd-subaccounts-table tbody tr {
        padding: 14px !important;
    }
    #hd-subaccounts .hd-subaccounts-table td[data-label="Username"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="Description"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="Base dir."] {
        grid-template-columns: 82px minmax(0, 1fr) !important;
        column-gap: 8px !important;
    }
    #hd-subaccounts .hd-subaccounts-table td[data-label="SMB"]::before,
    #hd-subaccounts .hd-subaccounts-table td[data-label="WebDAV"]::before,
    #hd-subaccounts .hd-subaccounts-table td[data-label="SSH"]::before,
    #hd-subaccounts .hd-subaccounts-table td[data-label="Ext. reach."]::before,
    #hd-subaccounts .hd-subaccounts-table td[data-label="Read-only"]::before {
        font-size: 0.80rem !important;
    }
}

/* FINAL MICRO FIX: remove responsive boxes from subaccount options and base directory only */
@media (max-width: 700px) {
    #hd-subaccounts .hd-subaccounts-table td[data-label="SMB"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="WebDAV"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="SSH"],
    #hd-subaccounts .hd-subaccounts-table td[data-label="Ext. reach."],
    #hd-subaccounts .hd-subaccounts-table td[data-label="Read-only"] {
        border: 0 !important;
        background: transparent !important;
        margin: 0 !important;
        padding: 4px 8px !important;
    }
    #hd-subaccounts .hd-subaccounts-table td[data-label="Base dir."] .hd-subaccount-copy-pill {
        border: 0 !important;
        background: transparent !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
        min-height: 0 !important;
    }
}

/* FINAL REQUEST: overview mobile readability + snapshot action icons right aligned only */
@media (max-width: 700px) {
    #hd-overview .hd-overview-grid {
        display: grid !important;
        grid-template-columns: 1fr !important;
        gap: 18px !important;
    }
    #hd-overview .hd-table-wrapper {
        overflow: visible !important;
        width: 100% !important;
    }
    #hd-overview #hd-server-details tr,
    #hd-overview #hd-server-details th,
    #hd-overview #hd-server-details td {
        display: block !important;
        width: 100% !important;
    }
    #hd-overview #hd-server-details tr {
        padding: 12px 0 !important;
        border-bottom: 1px solid var(--hd-border) !important;
    }
    #hd-overview #hd-server-details tr:last-child {
        border-bottom: 0 !important;
    }
    #hd-overview #hd-server-details th {
        padding: 0 14px 8px !important;
        border-bottom: 0 !important;
        font-size: 0.70rem !important;
        color: var(--hd-muted) !important;
    }
    #hd-overview #hd-server-details td {
        padding: 0 14px !important;
        border-bottom: 0 !important;
    }
    #hd-overview .hd-data-pill {
        width: 100% !important;
        max-width: 100% !important;
        min-height: 38px !important;
    }
    #hd-overview .hd-data-pill span {
        min-width: 0 !important;
        white-space: normal !important;
        word-break: break-word !important;
        overflow: visible !important;
        text-overflow: clip !important;
    }
    #hd-overview .hd-protocols-list .hd-settings-item {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        gap: 14px !important;
        width: 100% !important;
    }
    #hd-overview .hd-protocols-list .lbl-text {
        min-width: 0 !important;
        white-space: normal !important;
    }
    #hd-overview .hd-panel .hd-btn-outline {
        width: 100% !important;
        min-height: 44px !important;
    }
    #hd-snapshots .hd-responsive-table .hd-table td[data-label="Actions"] {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        text-align: right !important;
        width: 100% !important;
    }
    #hd-snapshots .hd-responsive-table .hd-table td[data-label="Actions"]::before {
        margin-right: auto !important;
        flex: 0 0 auto !important;
    }
    #hd-snapshots .hd-responsive-table .hd-table td[data-label="Actions"] > div {
        margin-left: auto !important;
        justify-content: flex-end !important;
        width: auto !important;
    }
}

</style>

<div class="hd-dashboard mt-3">
    <input type="hidden" id="hd-system-url" value="{$systemUrl|escape:'html'}">
    <input type="hidden" id="hd-secret-token" value="{$rzCustomToken|escape:'html'}">
    <input type="hidden" id="hd-secret-serviceid" value="{$serviceId|escape:'html'}">
    <input type="hidden" id="hd-snapshot-suggestion" value="{$snapshotSuggestedDescription|escape:'html'}">
    <script type="application/json" id="hd-initial-directories">{$storageDirectoriesJson nofilter}</script>

    <ul class="hd-tab-nav" id="hdTabs">
        <li><a href="javascript:void(0);" data-target="#hd-overview" class="active"><i class="fas fa-layer-group"></i> Overview</a></li>
        <li><a href="javascript:void(0);" data-target="#hd-access"><i class="fas fa-shield-alt"></i> Authentication</a></li>
        <li><a href="javascript:void(0);" data-target="#hd-snapshots"><i class="fas fa-history"></i> Snapshots</a></li>
        <li><a href="javascript:void(0);" data-target="#hd-subaccounts"><i class="fas fa-users"></i> Subaccounts</a></li>
    </ul>

    {include file="./overview.tpl"}
    {include file="./authentication.tpl"}
    {include file="./snapshots.tpl"}
    {include file="./subaccounts.tpl"}
</div>

{include file="./modals.tpl"}

<script>
{literal}
const hdHiddenServiceIdRaw = (document.getElementById('hd-secret-serviceid') && document.getElementById('hd-secret-serviceid').value) || '';
const hdUrlServiceIdRaw = new URLSearchParams(window.location.search).get('id') || '';
const hdSafeServiceId = /^\d+$/.test(hdHiddenServiceIdRaw) ? hdHiddenServiceIdRaw : (/^\d+$/.test(hdUrlServiceIdRaw) ? hdUrlServiceIdRaw : String(hdHiddenServiceIdRaw || hdUrlServiceIdRaw).replace(/[^0-9]/g, ''));
const hdServiceUrl = "clientarea.php?action=productdetails&id=" + encodeURIComponent(hdSafeServiceId || hdUrlServiceIdRaw || hdHiddenServiceIdRaw);
const hdToken = document.getElementById('hd-secret-token').value;

try {
    const hdUrlParams = new URLSearchParams(window.location.search);
    if (/^\d+$/.test(hdSafeServiceId) && hdUrlParams.get('id') !== hdSafeServiceId) {
        hdUrlParams.set('id', hdSafeServiceId);
        window.history.replaceState(null, '', window.location.pathname + '?' + hdUrlParams.toString() + window.location.hash);
    }
} catch (e) {}

const hdInitialDirectoryEl = document.getElementById('hd-initial-directories');
let hdLiveDirectoryPaths = [];

try {
    hdLiveDirectoryPaths = JSON.parse((hdInitialDirectoryEl && hdInitialDirectoryEl.textContent) || '[]') || [];
} catch(e) {
    hdLiveDirectoryPaths = [];
}

let hdZfsPollerActive = false;
let hdSilentRefreshRunning = false;
let hdSilentRefreshQueued = false;
let hdLastSilentRefreshAt = 0;
let hdDirectoryFetchInFlight = {
    create: false,
    edit: false
};

function copyPlainText(text, message = 'Copied to clipboard.') {
    const value = String(text || '');
    if (!value) return;

    const done = () => showNotification('Data Copied', message, false);

    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(value).then(done).catch(() => {
            const tmp = document.createElement('textarea');
            tmp.value = value;
            document.body.appendChild(tmp);
            tmp.select();
            document.execCommand('copy');
            tmp.remove();
            done();
        });
    } else {
        const tmp = document.createElement('textarea');
        tmp.value = value;
        document.body.appendChild(tmp);
        tmp.select();
        document.execCommand('copy');
        tmp.remove();
        done();
    }
}

function copyToClipboard(id) {
    const el = document.getElementById(id);
    copyPlainText(el ? (el.value || el.innerText) : '', 'Copied to clipboard.');
}

function anyHdModalOpen() {
    return Array.from(document.querySelectorAll('.hd-modal')).some(m => m.style.display === 'flex');
}

function lockHdModalBackground() {
    document.body.classList.add('hd-modal-open');
}

function unlockHdModalBackgroundIfDone() {
    if (!anyHdModalOpen()) {
        document.body.classList.remove('hd-modal-open');
        const backdrop = document.getElementById('hd-modal-backdrop');
        if (backdrop) backdrop.style.display = 'none';
    }
}

function openModal(id) {
    if (id === 'createSnapshotModal') prepareManualSnapshotModal();
    if (id === 'autoSnapshotModal') prepareAutoSnapshotModal();
    if (id === 'passwordModal') updatePasswordRequirementState();
    if (id === 'createSubModal') prepareCreateSubaccountModal();

    const backdrop = document.getElementById('hd-modal-backdrop');
    const modal = document.getElementById(id);

    if (backdrop) backdrop.style.display = 'block';
    if (modal) modal.style.display = 'flex';

    lockHdModalBackground();
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.style.display = 'none';
    unlockHdModalBackgroundIfDone();
}

function closeAllModals() {
    document.querySelectorAll('.hd-modal').forEach(m => m.style.display = 'none');

    const backdrop = document.getElementById('hd-modal-backdrop');
    if (backdrop) backdrop.style.display = 'none';

    document.body.classList.remove('hd-modal-open');
}

function showNotification(title, msg, isError = false) {
    document.getElementById('notif-title').innerText = title;
    document.getElementById('notif-msg').innerHTML = msg;

    const icon = document.getElementById('notif-icon');

    if (isError) {
        icon.className = 'fas fa-exclamation-triangle fa-3x mb-3 mt-3';
        icon.style.color = 'var(--hd-danger)';
    } else {
        icon.className = 'fas fa-check-circle fa-3x mb-3 mt-3';
        icon.style.color = 'var(--hd-success)';
    }

    openModal('notificationModal');
}

function activateTab(target) {
    document.querySelectorAll('#hdTabs a').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.hd-tab-content').forEach(c => c.classList.remove('active'));

    const tab = document.querySelector('#hdTabs a[data-target="' + target + '"]');
    const content = document.querySelector(target);

    if (tab) tab.classList.add('active');
    if (content) content.classList.add('active');
}

document.addEventListener('DOMContentLoaded', function () {
    const backdrop = document.getElementById('hd-modal-backdrop');

    if (backdrop) {
        backdrop.addEventListener('click', function(e) {
            if (e.target === this) {
                const isProcessing = document.querySelector('.hd-modal[style*="display: flex"] button:disabled');
                if (isProcessing) return;

                const notificationModal = document.getElementById('notificationModal');

                if (notificationModal && notificationModal.style.display === 'flex') {
                    closeModal('notificationModal');
                    return;
                }

                closeAllModals();
            }
        });
    }

    const serviceEl = document.getElementById('hd-secret-serviceid');
    const serviceId = serviceEl ? serviceEl.value : '';
    const savedTab = sessionStorage.getItem('hd_tab_' + serviceId);

    if (savedTab) activateTab(savedTab);

    document.querySelectorAll('#hdTabs a').forEach((tab) => {
        tab.addEventListener('click', function (e) {
            e.preventDefault();

            const target = this.getAttribute('data-target');
            activateTab(target);

            if (serviceEl) {
                sessionStorage.setItem('hd_tab_' + serviceEl.value, target);
            }

            /*
             * Performance fix:
             * Do not refresh the whole module every time a tab is clicked.
             * Data refreshes after actions only.
             */
        });
    });

    /*
     * Performance fix:
     * Delay status polling so first page render is faster.
     */
    window.setTimeout(function () {
        applySnapshotDirectoryPendingState();
        refreshSnapshotDirectoryStateFromServer().catch(() => {});
    }, 1200);

    bindDirectoryTreeButtons();
    resetDirectoryTree('create', '');
    renderTree();
});

async function postAction(action, bodyMap) {
    const body = new URLSearchParams(bodyMap || {});
    body.set('customAction', action);
    body.set('rz_token', hdToken);

    const res = await fetch(hdServiceUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        },
        body: body.toString(),
        cache: 'no-store',
        credentials: 'same-origin'
    });

    const text = await res.text();
    let data = null;

    try {
        data = JSON.parse(text);
    } catch (e) {
        throw new Error('We could not complete this request right now. Please refresh the page and try again.');
    }

    if (!res.ok) {
        throw new Error(data.error || 'We could not complete this request right now. Please refresh the page and try again.');
    }

    return data;
}

function friendlyActionError(message) {
    const fallback = 'We could not complete this request right now. Please refresh the page and try again.';
    message = String(message || '').trim();

    if (!message) return fallback;

    if (/subaccount limit|open a ticket|directory|Whitespace is not allowed|Storage Box username|Reset the Storage Box password/i.test(message)) {
        return message;
    }

    if (/Storage Provider API Error|storage provider|hcloud|api error|curl|json|401|403|404|409|422|429|500|502|503|504/i.test(message)) {
        return fallback;
    }

    return message;
}

function hdServiceId() {
    const el = document.getElementById('hd-secret-serviceid');
    return el ? el.value : '0';
}

function hdZfsPendingKey() {
    return 'hd_zfs_pending_' + hdServiceId();
}

function saveZfsPendingState(desiredState) {
    try {
        localStorage.setItem(hdZfsPendingKey(), JSON.stringify({
            desired: desiredState ? 1 : 0,
            ts: Date.now()
        }));
    } catch (e) {}
}

function readZfsPendingState() {
    try {
        const raw = localStorage.getItem(hdZfsPendingKey());
        return raw ? JSON.parse(raw) : null;
    } catch (e) {
        return null;
    }
}

function clearZfsPendingState() {
    try {
        localStorage.removeItem(hdZfsPendingKey());
    } catch (e) {}
}

function setSnapshotDirectorySyncing(isSyncing, desiredState = null) {
    const setting = document.getElementById('hd-zfs-setting');
    const toggle = document.getElementById('hd-zfs-toggle');
    const statusText = document.getElementById('hd-zfs-status-text');

    if (setting) setting.classList.toggle('is-syncing', !!isSyncing);
    if (statusText) statusText.innerText = 'Expose Snapshot Directory';

    if (toggle) {
        if (typeof desiredState === 'boolean') toggle.checked = desiredState;
        toggle.disabled = !!isSyncing;
    }
}

function updateSnapshotDirectoryToggle(isEnabled) {
    const toggle = document.getElementById('hd-zfs-toggle');
    if (toggle) toggle.checked = !!isEnabled;
}

async function refreshSnapshotDirectoryStateFromServer() {
    const data = await postAction('status_poll', {});

    if (data && data.status === 'success' && data.accessSettings) {
        updateSnapshotDirectoryToggle(!!data.accessSettings.zfs_enabled);
        return !!data.accessSettings.zfs_enabled;
    }

    return null;
}

async function pollSnapshotDirectoryUntilSynced(desiredState, maxAttempts = 30) {
    if (hdZfsPollerActive) return false;

    hdZfsPollerActive = true;
    setSnapshotDirectorySyncing(true, desiredState);

    try {
        for (let i = 0; i < maxAttempts; i++) {
            const liveState = await refreshSnapshotDirectoryStateFromServer();

            if (liveState === desiredState) {
                clearZfsPendingState();
                setSnapshotDirectorySyncing(false, desiredState);
                return true;
            }

            await new Promise(resolve => setTimeout(resolve, 2500));
        }
    } finally {
        hdZfsPollerActive = false;
    }

    return false;
}

function applySnapshotDirectoryPendingState() {
    const pending = readZfsPendingState();
    if (!pending) return;

    const desiredState = pending.desired === 1 || pending.desired === true;
    const ageMs = Date.now() - (parseInt(pending.ts, 10) || 0);

    if (ageMs > 10 * 60 * 1000) {
        clearZfsPendingState();
        setSnapshotDirectorySyncing(false);
        refreshSnapshotDirectoryStateFromServer().catch(() => {});
        return;
    }

    setSnapshotDirectorySyncing(true, desiredState);

    pollSnapshotDirectoryUntilSynced(desiredState).then((synced) => {
        if (!synced) {
            clearZfsPendingState();
            setSnapshotDirectorySyncing(false);
            refreshSnapshotDirectoryStateFromServer().catch(() => {});
            showNotification('Error', 'Cloud Storage has not confirmed the snapshot directory status yet. Please refresh the page and check again.', true);
        }
    });
}

async function silentRefresh(force = false) {
    const now = Date.now();

    if (!force && now - hdLastSilentRefreshAt < 900) {
        hdSilentRefreshQueued = true;
        return;
    }

    if (hdSilentRefreshRunning) {
        hdSilentRefreshQueued = true;
        return;
    }

    hdSilentRefreshRunning = true;
    hdSilentRefreshQueued = false;
    hdLastSilentRefreshAt = now;

    try {
        const refreshUrl = new URL(window.location.href);
        refreshUrl.searchParams.set('_t', Date.now());
        refreshUrl.searchParams.set('_hd_sync', '1');

        const res = await fetch(refreshUrl.toString(), {
            cache: 'no-store',
            credentials: 'same-origin',
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            }
        });

        const text = await res.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/html');

        const mapIds = [
            'hd-live-specs',
            'hd-server-details',
            'hd-access-protocols',
            'hd-snapshots-tbody',
            'hd-subaccounts-tbody',
            'hd-snapshot-suggestion',
            'hd-snapshot-actions',
            'hd-zfs-setting-wrap'
        ];

        mapIds.forEach(id => {
            const freshEl = doc.getElementById(id);
            const currentEl = document.getElementById(id);

            if (!freshEl || !currentEl) return;

            if (currentEl.tagName === 'INPUT') {
                currentEl.value = freshEl.value || freshEl.getAttribute('value') || '';
            } else {
                currentEl.innerHTML = freshEl.innerHTML;
            }
        });

        ['autoSnapshotModal', 'disableAutoSnapshotModal'].forEach(id => {
            const freshEl = doc.getElementById(id);
            const currentEl = document.getElementById(id);

            if (!freshEl || !currentEl) return;
            if (currentEl.style.display === 'flex') return;

            currentEl.innerHTML = freshEl.innerHTML;
        });

        applySnapshotDirectoryPendingState();
    } catch(e) {
        console.error("Silent sync failed", e);
    } finally {
        hdSilentRefreshRunning = false;

        if (hdSilentRefreshQueued) {
            hdSilentRefreshQueued = false;
            window.setTimeout(function () {
                silentRefresh(true);
            }, 700);
        }
    }
}

function refreshPageDataAfterAction() {
    window.setTimeout(() => silentRefresh(true), 700);
    window.setTimeout(() => silentRefresh(true), 3500);
}

function removeSnapshotRowFromUi(snapshotId) {
    const row = document.getElementById('snap-row-' + snapshotId);

    if (row) {
        row.style.opacity = '0.5';
        row.remove();
    }
}

async function executeActionWithNotification(action, payload, loadingBtnId, loadingText, successTitle, successMsg, customCallback = null) {
    const btn = document.getElementById(loadingBtnId);
    const originalText = btn ? btn.innerHTML : '';

    if (btn) {
        btn.innerHTML = `<i class="fas fa-circle-notch fa-spin me-2"></i> ${loadingText}`;
        btn.disabled = true;
    }

    let data = {
        status: 'error',
        error: 'Unable to contact the server.'
    };

    try {
        data = await postAction(action, payload);
        closeAllModals();

        if (data.status === 'success') {
            const callbackResult = customCallback ? customCallback(data) : null;

            if (callbackResult !== false && (!customCallback || !data.new_username)) {
                showNotification(successTitle, successMsg || data.message || 'Operation executed successfully.', false);
            }

            refreshPageDataAfterAction();
        } else {
            showNotification('Error', friendlyActionError(data.error || 'Server rejected the request.'), true);
            refreshPageDataAfterAction();
        }
    } catch (e) {
        closeAllModals();
        showNotification('Error', friendlyActionError(e.message || 'Unable to contact the server.'), true);
        refreshPageDataAfterAction();
    } finally {
        if (btn) {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    }

    return data;
}

function generateSecurePass() {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    let pass = "A" + "a" + "1";

    for (let i = 0; i < 15; i++) {
        pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return pass.split('').sort(() => 0.5 - Math.random()).join('');
}

function saveAccessSettings() {
    const payload = {
        samba_enabled: document.getElementById('modal-chk-smb').checked ? 1 : 0,
        webdav_enabled: document.getElementById('modal-chk-webdav').checked ? 1 : 0,
        ssh_enabled: document.getElementById('modal-chk-ssh').checked ? 1 : 0,
        reachable_externally: document.getElementById('modal-chk-ext').checked ? 1 : 0
    };

    executeActionWithNotification('save_settings', payload, 'btn-save-settings', 'Saving...', 'Routing Updated', 'Network access protocols applied successfully.');
}

function getStorageBoxPasswordValidation(password) {
    return {
        length: password.length >= 8 && password.length <= 32,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password)
    };
}

function updatePasswordRequirementState() {
    const input = document.getElementById('hd-new-password');
    const rulesBox = document.getElementById('hd-password-rules');

    if (!input || !rulesBox) return;

    const validation = getStorageBoxPasswordValidation(input.value.trim());

    Object.keys(validation).forEach((rule) => {
        const item = rulesBox.querySelector('[data-rule="' + rule + '"]');

        if (!item) return;

        const icon = item.querySelector('i');

        item.classList.remove('is-valid', 'is-invalid');
        item.classList.add(validation[rule] ? 'is-valid' : 'is-invalid');

        if (icon) {
            icon.className = validation[rule] ? 'fas fa-check-circle' : 'fas fa-times-circle';
        }
    });
}

function setGeneratedStorageBoxPassword() {
    const input = document.getElementById('hd-new-password');

    if (!input) return;

    input.value = generateSecurePass();
    updatePasswordRequirementState();
}

async function submitPasswordReset() {
    const passwordInput = document.getElementById('hd-new-password');
    const newPass = passwordInput.value.trim();

    updatePasswordRequirementState();

    if (!newPass) {
        showNotification("Validation Error", "Please enter a password.", true);
        return;
    }

    const validation = getStorageBoxPasswordValidation(newPass);

    if (!validation.length || !validation.uppercase || !validation.lowercase || !validation.number) {
        showNotification("Validation Error", "Password must be 8 to 32 characters long and contain at least one uppercase letter, one lowercase letter, and one number.", true);
        return;
    }

    const data = await executeActionWithNotification('custom_reset_password', {
        new_password: newPass
    }, 'btn-reset-password', 'Processing...', 'System Updated', 'Password updated successfully in the Cloud Storage. No email was sent because you set the password here.');

    if (data.status === 'success') {
        passwordInput.value = '';
        updatePasswordRequirementState();
    }
}

function padTwo(value) {
    value = parseInt(value, 10);

    if (Number.isNaN(value)) return '00';

    return String(value).padStart(2, '0');
}

function prepareManualSnapshotModal() {
    const input = document.getElementById('newSnapshotDesc');
    const suggestion = document.getElementById('hd-snapshot-suggestion');

    if (!input || !suggestion) return;

    if (!input.value.trim()) {
        input.value = suggestion.value || '';
    }
}

function advanceSnapshotSuggestion(currentDescription) {
    const suggestion = document.getElementById('hd-snapshot-suggestion');

    if (!suggestion) return;

    const current = (currentDescription || suggestion.value || '').trim();
    const match = current.match(/^(.*-)(\d+)$/);

    if (match) {
        suggestion.value = match[1] + (parseInt(match[2], 10) + 1);
    }
}

function clampAutoSnapshotMax(forceDefault) {
    const input = document.getElementById('autoSnapMax');

    if (!input) return 1;

    const maxAllowed = parseInt(input.getAttribute('max') || input.dataset.max || '10', 10) || 10;
    let value = input.value === '' ? NaN : parseInt(input.value, 10);

    if (Number.isNaN(value)) {
        if (forceDefault) {
            value = 1;
            input.value = value;
        }

        return maxAllowed;
    }

    if (value > maxAllowed) value = maxAllowed;
    if (value < 1) value = 1;

    input.value = value;

    return maxAllowed;
}

function clampAutoSnapshotDayOfMonth(forceDefault) {
    const input = document.getElementById('autoSnapDayOfMonth');

    if (!input) return 1;

    let value = input.value === '' ? NaN : parseInt(input.value, 10);

    if (Number.isNaN(value)) {
        if (forceDefault) {
            value = 1;
            input.value = value;
        }

        toggleAutoSnapshotMonthlyNote();
        return value;
    }

    if (value > 31) value = 31;
    if (value < 1) value = 1;

    input.value = value;
    toggleAutoSnapshotMonthlyNote();

    return value;
}

function toggleAutoSnapshotMonthlyNote() {
    const interval = document.getElementById('autoSnapInterval');
    const input = document.getElementById('autoSnapDayOfMonth');
    const notice = document.getElementById('autoSnapMonthNotice');

    if (!interval || !input || !notice) return;

    const day = parseInt(input.value, 10);

    notice.style.display = interval.value === 'monthly' && day >= 29 && day <= 31 ? 'block' : 'none';
}

function updateAutoSnapshotFrequencyFields() {
    const interval = document.getElementById('autoSnapInterval');
    const weeklyRow = document.getElementById('autoSnapWeeklyRow');
    const monthlyRow = document.getElementById('autoSnapMonthlyRow');

    if (!interval) return;

    if (weeklyRow) weeklyRow.style.display = interval.value === 'weekly' ? 'block' : 'none';
    if (monthlyRow) monthlyRow.style.display = interval.value === 'monthly' ? 'block' : 'none';

    if (interval.value === 'monthly') {
        clampAutoSnapshotDayOfMonth(true);
    } else {
        toggleAutoSnapshotMonthlyNote();
    }
}

function prepareAutoSnapshotModal() {
    clampAutoSnapshotMax(true);

    const hour = document.getElementById('autoSnapHour');
    const minute = document.getElementById('autoSnapMin');

    if (hour) hour.value = padTwo(hour.value);
    if (minute) minute.value = padTwo(minute.value);

    updateAutoSnapshotFrequencyFields();
}

async function toggleSnapshotDir(isEnabled) {
    const toggle = document.getElementById('hd-zfs-toggle');
    const previousState = toggle ? !isEnabled : false;

    saveZfsPendingState(isEnabled);
    setSnapshotDirectorySyncing(true, isEnabled);

    try {
        const data = await postAction('toggle_zfs', {
            zfs_enabled: isEnabled ? 1 : 0
        });

        if (data.error || data.status === 'error') {
            clearZfsPendingState();
            setSnapshotDirectorySyncing(false, previousState);
            updateSnapshotDirectoryToggle(previousState);
            showNotification('Operation Failed', friendlyActionError(data.error || 'An error occurred.'), true);
            refreshPageDataAfterAction();
            return;
        }

        if (typeof data.zfs_enabled !== 'undefined') {
            updateSnapshotDirectoryToggle(!!data.zfs_enabled);
        }

        const synced = await pollSnapshotDirectoryUntilSynced(isEnabled, 12);

        if (synced) {
            showNotification('System Updated', 'Snapshot directory visibility updated successfully.', false);
        } else {
            showNotification('System Updated', 'Snapshot directory request accepted. The status will continue syncing with Cloud Storage.', false);
        }

        refreshPageDataAfterAction();
    } catch (e) {
        clearZfsPendingState();
        setSnapshotDirectorySyncing(false, previousState);
        updateSnapshotDirectoryToggle(previousState);
        showNotification('Operation Failed', friendlyActionError(e.message || 'Unable to contact the server.'), true);
        refreshPageDataAfterAction();
    }
}

function promptRestoreSnapshot(id) {
    document.getElementById('restoreSnapshotId').value = id;
    openModal('restoreSnapshotModal');
}

function promptDeleteSnapshot(id) {
    document.getElementById('deleteSnapshotId').value = id;
    openModal('deleteSnapshotModal');
}

async function submitCreateSnapshot() {
    const input = document.getElementById('newSnapshotDesc');
    const desc = input.value.trim();

    if (!desc) {
        showNotification("Validation Error", "Description is required.", true);
        return;
    }

    const data = await executeActionWithNotification('create_snapshot', {
        description: desc
    }, 'btn-create-snap', 'Creating...', 'System Updated', 'Manual snapshot created successfully in the Cloud Storage.');

    if (data.status === 'success') {
        advanceSnapshotSuggestion(desc);
        input.value = document.getElementById('hd-snapshot-suggestion').value || '';
    }
}

async function submitAutoSnapshot() {
    const maxInput = document.getElementById('autoSnapMax');
    const maxAllowed = clampAutoSnapshotMax(true);
    const amount = parseInt(maxInput.value, 10);
    const interval = document.getElementById('autoSnapInterval').value;
    const hour = document.getElementById('autoSnapHour').value;
    const minute = document.getElementById('autoSnapMin').value;

    if (Number.isNaN(amount) || amount < 1 || amount > maxAllowed) {
        showNotification('Validation Error', 'Max Amount must be between 1 and ' + maxAllowed + ' for this Storage Box plan.', true);
        return;
    }

    if (!/^(?:[01]\d|2[0-3])$/.test(hour) || !/^[0-5]\d$/.test(minute)) {
        showNotification('Validation Error', 'Execution Time must use hour 00-23 and minute 00-59.', true);
        return;
    }

    const payload = {
        interval: interval,
        max_amount: String(amount),
        hour: hour,
        minute: minute
    };

    if (interval === 'weekly') {
        const dayOfWeek = parseInt(document.getElementById('autoSnapDayOfWeek').value, 10);

        if (Number.isNaN(dayOfWeek) || dayOfWeek < 1 || dayOfWeek > 7) {
            showNotification('Validation Error', 'Please choose a valid day of week.', true);
            return;
        }

        payload.day_of_week = String(dayOfWeek);
    }

    if (interval === 'monthly') {
        const dayOfMonth = clampAutoSnapshotDayOfMonth(true);

        if (Number.isNaN(dayOfMonth) || dayOfMonth < 1 || dayOfMonth > 31) {
            showNotification('Validation Error', 'Day of month must be between 1 and 31.', true);
            return;
        }

        payload.day_of_month = String(dayOfMonth);
    }

    executeActionWithNotification('enable_auto_snapshot', payload, 'btn-enable-auto', 'Saving...', 'System Updated', 'Auto snapshot policy updated successfully.Please refresh the page.');
}

function submitDisableAutoSnapshot() {
    executeActionWithNotification('disable_auto_snapshot', {}, 'btn-disable-auto', 'Disabling...', 'System Updated', 'Automatic snapshots disabled successfully. Please refresh the page.');
}

function submitDeleteSnapshot() {
    const id = document.getElementById('deleteSnapshotId').value;

    executeActionWithNotification('delete_snapshot', {
        snapshot_id: id
    }, 'btn-delete-snap', 'Deleting...', 'Snapshot Deleted', 'Filesystem snapshot deleted successfully.', () => {
        removeSnapshotRowFromUi(id);
    });
}

function submitRestoreSnapshot() {
    const id = document.getElementById('restoreSnapshotId').value;

    executeActionWithNotification('restore_snapshot', {
        snapshot_id: id
    }, 'btn-restore-snap', 'Restoring...', 'Restore Complete', 'Snapshot restored successfully.');
}

let treeIdCounter = 3;
let editTreeOriginalPath = '';

const hdDirectoryTrees = {
    create: {
        containerId: 'cs-tree',
        inputId: 'cs-dir',
        selectedPathId: 'cs-selected-path',
        statusId: 'cs-tree-status',
        addRootBtnId: 'cs-addRootBtn',
        resetBtnId: 'cs-resetBtn',
        data: [],
        selectedId: null,
        liveLoaded: false
    },
    edit: {
        containerId: 'es-tree',
        inputId: 'es-dir',
        selectedPathId: 'es-selected-path',
        statusId: 'es-tree-status',
        addRootBtnId: 'es-addRootBtn',
        resetBtnId: 'es-resetBtn',
        data: [],
        selectedId: null,
        liveLoaded: false
    }
};

function makeTreeNode(name, options = {}) {
    return {
        id: treeIdCounter++,
        name: name || 'new_directory',
        isPlaceholder: !!options.isPlaceholder,
        isEditing: !!options.isEditing,
        isExisting: !!options.isExisting,
        tempName: options.tempName || '',
        expanded: options.expanded !== false,
        children: options.children || []
    };
}

function normalizeDirectoryPath(path) {
    return String(path || '')
        .replace(/\\/g, '/')
        .replace(/^\/+|\/+$/g, '')
        .split('/')
        .map(part => part.trim())
        .filter(Boolean)
        .join('/');
}

function validateDirectorySegment(value) {
    const raw = String(value || '');

    if (!raw) return 'Directory name cannot be empty.';
    if (raw !== raw.trim()) return 'Whitespace is not allowed at the beginning or end of a directory name.';
    if (raw === '.' || raw === '..') return 'Directory name is not valid.';
    if (/[\\/]/.test(raw)) return 'Directory names cannot contain slashes. Add child folders with the Child button.';

    return '';
}

function validateDirectoryPathClient(path) {
    const raw = String(path || '').replace(/\\/g, '/');

    if (!raw || raw !== raw.trim()) return 'Whitespace is not allowed at the beginning or end of a directory path.';

    const parts = raw.replace(/^\/+|\/+$/g, '').split('/').filter(Boolean);

    if (!parts.length) return 'Directory path is required.';

    for (const part of parts) {
        const err = validateDirectorySegment(part);
        if (err) return err;
    }

    return '';
}

function treeSetStatus(mode, message = '', loading = false) {
    const tree = hdDirectoryTrees[mode];
    const el = tree ? document.getElementById(tree.statusId) : null;

    if (!el) return;

    el.classList.toggle('is-loading', !!loading);
    el.innerHTML = message;
}

function addPathToTreeData(data, path, options = {}) {
    const normalized = normalizeDirectoryPath(path);

    if (!normalized) return null;

    const parts = normalized.split('/');
    let children = data;
    let current = null;

    parts.forEach((part) => {
        let node = children.find(item => !item.isPlaceholder && item.name.toLowerCase() === part.toLowerCase());

        if (!node) {
            node = makeTreeNode(part, {
                expanded: true,
                isExisting: !!options.isExisting
            });

            children.push(node);
        } else {
            node.expanded = true;
            if (options.isExisting) node.isExisting = true;
        }

        current = node;

        if (!Array.isArray(node.children)) node.children = [];

        children = node.children;
    });

    return current;
}

function collectSubaccountDirectoryPaths(extraPath = '') {
    const paths = [];

    (Array.isArray(hdLiveDirectoryPaths) ? hdLiveDirectoryPaths : []).forEach((item) => {
        const path = normalizeDirectoryPath(item);

        if (path && !paths.includes(path)) paths.push(path);
    });

    document.querySelectorAll('#hd-subaccounts-tbody .hd-subaccount-dir code').forEach((code) => {
        const path = normalizeDirectoryPath(code.textContent || '');

        if (path && !paths.includes(path)) paths.push(path);
    });

    const extra = normalizeDirectoryPath(extraPath);

    if (extra && !paths.includes(extra)) paths.push(extra);

    return paths;
}

function treeFromPaths(paths, selectedPath = '') {
    const data = [];
    let selectedNode = null;
    const normalizedSelected = normalizeDirectoryPath(selectedPath);
    const allPaths = Array.isArray(paths) ? paths.slice() : [];
    const normalizedLivePaths = hdLiveDirectoryPaths.map(p => normalizeDirectoryPath(p).toLowerCase());

    if (normalizedSelected && !allPaths.includes(normalizedSelected)) {
        allPaths.push(normalizedSelected);
    }

    allPaths.forEach((path) => {
        const normalized = normalizeDirectoryPath(path);
        const node = addPathToTreeData(data, normalized, {
            isExisting: normalizedLivePaths.includes(normalized.toLowerCase())
        });

        if (normalizedSelected && normalized.toLowerCase() === normalizedSelected.toLowerCase()) {
            selectedNode = node;
        }
    });

    if (!data.length) {
        data.push(makeTreeNode('new_directory', {
            isPlaceholder: true,
            isEditing: true
        }));
    }

    return {
        data,
        selectedId: selectedNode ? selectedNode.id : null
    };
}

function resetDirectoryTree(mode, path = '', pathsOverride = null) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return;

    const built = treeFromPaths(pathsOverride || collectSubaccountDirectoryPaths(path), path);

    tree.data = built.data;
    tree.selectedId = built.selectedId;

    renderDirectoryTree(mode);
}

function getTreeNodeInfo(mode, nodeId) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return null;

    function walk(nodes, parents) {
        for (const node of nodes) {
            if (node.id === nodeId) return {
                node,
                parents
            };

            const found = walk(node.children || [], parents.concat(node));

            if (found) return found;
        }

        return null;
    }

    return walk(tree.data, []);
}

function firstRealTreeNode(nodes) {
    for (const node of nodes) {
        if (!node.isPlaceholder) return node;

        const found = firstRealTreeNode(node.children || []);

        if (found) return found;
    }

    return null;
}

function getPathForNodeInfo(info) {
    if (!info || !info.node) return '';

    return info.parents.concat(info.node).map(n => n.name).filter(Boolean).join('/');
}

function getSelectedTreePath(mode) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return 'new_directory';

    let info = tree.selectedId ? getTreeNodeInfo(mode, tree.selectedId) : null;

    if (!info || info.node.isPlaceholder) {
        const first = firstRealTreeNode(tree.data);

        if (first) {
            tree.selectedId = first.id;
            info = getTreeNodeInfo(mode, first.id);
        }
    }

    if (!info || info.node.isPlaceholder) return 'new_directory';

    return getPathForNodeInfo(info) || 'new_directory';
}

function updateHiddenPath(mode) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return;

    const path = getSelectedTreePath(mode);
    const input = document.getElementById(tree.inputId);
    const selectedPath = document.getElementById(tree.selectedPathId);

    if (input) input.value = path;
    if (selectedPath) selectedPath.innerHTML = 'Selected directory: <code>/' + escapeHtml(path) + '/</code>';
}

function renderTree() {
    renderDirectoryTree('create');
    renderDirectoryTree('edit');
}

function renderDirectoryTree(mode) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return;

    const treeEl = document.getElementById(tree.containerId);

    if (!treeEl) return;

    treeEl.innerHTML = '';

    if (!tree.data.length) {
        tree.data.push(makeTreeNode('new_directory', {
            isPlaceholder: true
        }));
    }

    tree.data.forEach(node => treeEl.appendChild(renderTreeNode(mode, node)));
    updateHiddenPath(mode);
}

function renderTreeNode(mode, node) {
    const tree = hdDirectoryTrees[mode];

    const wrapper = document.createElement('div');
    wrapper.className = 'tree-node' + (tree.selectedId === node.id ? ' hd-tree-selected' : '');

    const row = document.createElement('div');
    row.className = 'tree-row';

    if (node.isEditing) {
        const editor = document.createElement('div');
        editor.className = 'tree-editor';

        const icon = document.createElement('span');
        icon.className = 'tree-folder-icon';
        editor.appendChild(icon);

        const input = document.createElement('input');
        input.type = 'text';
        input.placeholder = 'Enter folder name';
        input.value = node.tempName || (node.isPlaceholder ? '' : node.name);
        editor.appendChild(input);

        const okBtn = document.createElement('button');
        okBtn.type = 'button';
        okBtn.className = 'tree-ok-btn';
        okBtn.textContent = 'OK';
        okBtn.onclick = () => saveNode(mode, node, input.value);
        editor.appendChild(okBtn);

        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') saveNode(mode, node, input.value);
            if (e.key === 'Escape') cancelEdit(mode, node);
        });

        row.appendChild(editor);

        setTimeout(() => input.focus(), 0);
    } else if (node.isPlaceholder) {
        const ghost = document.createElement('div');
        ghost.className = 'tree-ghost-folder';
        ghost.innerHTML = '<span class="tree-folder-icon"></span><span>new_directory</span>';
        ghost.onclick = () => startEditing(mode, node);
        row.appendChild(ghost);
    } else {
        const hasRealChildren = (node.children || []).some(child => !child.isPlaceholder);

        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'tree-node-toggle';
        toggle.innerHTML = hasRealChildren ? (node.expanded ? '<i class="fas fa-chevron-down"></i>' : '<i class="fas fa-chevron-right"></i>') : '';
        toggle.onclick = (e) => {
            e.stopPropagation();
            node.expanded = !node.expanded;
            renderDirectoryTree(mode);
        };

        row.appendChild(toggle);

        const badge = document.createElement('div');
        badge.className = 'tree-folder-badge' + (tree.selectedId === node.id ? ' is-selected' : '') + (node.isExisting ? ' is-existing' : '');
        badge.innerHTML = '<span class="tree-folder-icon"></span><span>' + escapeHtml(node.name) + '</span>';
        badge.onclick = () => selectTreeNode(mode, node.id);
        row.appendChild(badge);

        const actions = document.createElement('div');
        actions.className = 'tree-actions';

        const addChildBtn = document.createElement('button');
        addChildBtn.type = 'button';
        addChildBtn.className = 'tree-mini-btn';
        addChildBtn.innerHTML = '<i class="fas fa-folder-plus"></i> Child';
        addChildBtn.onclick = () => addPlaceholderChild(mode, node);
        actions.appendChild(addChildBtn);

        row.appendChild(actions);
    }

    wrapper.appendChild(row);

    if (node.children && node.children.length && node.expanded !== false) {
        const childrenWrap = document.createElement('div');
        childrenWrap.className = 'tree-node-children';

        node.children.forEach(child => childrenWrap.appendChild(renderTreeNode(mode, child)));

        wrapper.appendChild(childrenWrap);
    }

    return wrapper;
}

function selectTreeNode(mode, nodeId) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return;

    const info = getTreeNodeInfo(mode, nodeId);

    if (!info || info.node.isPlaceholder) return;

    tree.selectedId = nodeId;
    renderDirectoryTree(mode);
}

function startEditing(mode, node) {
    node.isEditing = true;
    node.tempName = node.isPlaceholder ? '' : node.name;
    renderDirectoryTree(mode);
}

async function saveNode(mode, node, value) {
    const rawValue = String(value || '');
    const validationError = validateDirectorySegment(rawValue);

    if (validationError) {
        showNotification('Error', validationError, true);
        return;
    }

    const oldInfo = getTreeNodeInfo(mode, node.id);
    const oldPath = getPathForNodeInfo(oldInfo);
    const oldName = node.name;
    const wasExisting = !!node.isExisting;

    node.name = rawValue;

    const newInfo = getTreeNodeInfo(mode, node.id);
    const newPath = getPathForNodeInfo(newInfo);
    const pathError = validateDirectoryPathClient(newPath);

    node.name = oldName;

    if (pathError) {
        showNotification('Error', pathError, true);
        return;
    }

    if (wasExisting && oldPath && oldPath !== newPath) {
        showNotification('Error', 'Existing directories cannot be renamed from the client panel. Select it as-is or add a new child directory.', true);
        return;
    }

    if (!wasExisting) {
        try {
            treeSetStatus(mode, '<i class="fas fa-circle-notch fa-spin me-1"></i> Creating directory in Cloud Storage...', true);

            const data = await postAction('create_storage_directory', {
                path: newPath
            });

            if (data && data.status !== 'success') {
                throw new Error(data.error || 'Directory creation failed.');
            }

            if (data && Array.isArray(data.folders)) {
                hdLiveDirectoryPaths = data.folders;
            }

            treeSetStatus(mode, 'New directory created in Cloud Storage.');
        } catch (e) {
            treeSetStatus(mode, '');
            showNotification('Error', friendlyActionError(e.message || 'Directory creation failed.'), true);
            return;
        }
    }

    node.name = rawValue;
    node.isPlaceholder = false;
    node.isEditing = false;
    node.isExisting = mode === 'edit' ? true : !!node.isExisting;
    node.tempName = '';
    node.expanded = true;

    if (!Array.isArray(node.children)) node.children = [];

    hdDirectoryTrees[mode].selectedId = node.id;

    renderDirectoryTree(mode);
}

function cancelEdit(mode, node) {
    if (node.isPlaceholder) {
        removeTreeNode(mode, node.id, true);
        return;
    }

    node.isEditing = false;
    node.tempName = '';

    renderDirectoryTree(mode);
}

function addPlaceholderChild(mode, node) {
    if (!node.children) node.children = [];

    node.expanded = true;
    node.children.push(makeTreeNode('new_directory', {
        isPlaceholder: true,
        isEditing: true,
        isExisting: false
    }));

    renderDirectoryTree(mode);
}

function renameNode(mode, node) {
    showNotification('Action Disabled', 'Directory rename is disabled in the client panel.', true);
}

async function removeTreeNode(mode, nodeId, skipConfirm = false) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return;

    const info = getTreeNodeInfo(mode, nodeId);

    if (!info) return;

    if (info.node.isExisting && !skipConfirm) {
        showNotification('Action Disabled', 'Existing directories cannot be deleted from the client panel.', true);
        return;
    }

    function removeFrom(nodes) {
        const index = nodes.findIndex(node => node.id === nodeId);

        if (index >= 0) {
            nodes.splice(index, 1);
            return true;
        }

        return nodes.some(node => removeFrom(node.children || []));
    }

    const removed = removeFrom(tree.data);

    if (removed && tree.selectedId === nodeId) {
        const first = firstRealTreeNode(tree.data);
        tree.selectedId = first ? first.id : null;
    }

    if (!tree.data.length) {
        tree.data.push(makeTreeNode('new_directory', {
            isPlaceholder: true,
            isEditing: true
        }));
    }

    renderDirectoryTree(mode);
}

function addRootDirectory(mode) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return;

    tree.data.push(makeTreeNode('new_directory', {
        isPlaceholder: true,
        isEditing: true,
        isExisting: false
    }));

    renderDirectoryTree(mode);
}

async function fetchLiveDirectories(mode, selectedPath = '', force = false) {
    const tree = hdDirectoryTrees[mode];

    if (!tree) return;

    if (!force && tree.liveLoaded && Array.isArray(hdLiveDirectoryPaths) && hdLiveDirectoryPaths.length) {
        resetDirectoryTree(mode, selectedPath, collectSubaccountDirectoryPaths(selectedPath));
        treeSetStatus(mode, 'Showing cached directories. Use Refresh directories to sync latest.');
        return;
    }

    if (hdDirectoryFetchInFlight[mode]) return;

    hdDirectoryFetchInFlight[mode] = true;

    treeSetStatus(mode, '<i class="fas fa-circle-notch fa-spin me-1"></i> Fetching latest directories from Cloud Storage...', true);

    try {
        const data = await postAction('list_storage_box_folders', {});

        if (data.status === 'success' && Array.isArray(data.folders)) {
            hdLiveDirectoryPaths = data.folders;
            tree.liveLoaded = true;
            resetDirectoryTree(mode, selectedPath, collectSubaccountDirectoryPaths(selectedPath));
            treeSetStatus(mode, 'Showing latest directories synced from Cloud Storage.');
        } else {
            throw new Error(data.error || 'Unable to fetch directories.');
        }
    } catch (e) {
        resetDirectoryTree(mode, selectedPath);
        treeSetStatus(mode, 'Could not fetch live directories. Showing cached subaccount directories.');
        showNotification('Error', friendlyActionError(e.message || 'Unable to fetch live directories.'), true);
    } finally {
        hdDirectoryFetchInFlight[mode] = false;
    }
}

function resetCreateSubaccountTree() {
    resetDirectoryTree('create', '');
}

function resetEditSubaccountTree() {
    resetDirectoryTree('edit', editTreeOriginalPath || '');
}

function bindDirectoryTreeButtons() {
    ['create', 'edit'].forEach(mode => {
        const tree = hdDirectoryTrees[mode];
        const addBtn = document.getElementById(tree.addRootBtnId);
        const resetBtn = document.getElementById(tree.resetBtnId);

        if (addBtn && !addBtn.dataset.bound) {
            addBtn.dataset.bound = '1';
            addBtn.addEventListener('click', function(e) {
                e.preventDefault();
                addRootDirectory(mode);
            });
        }

        if (resetBtn && !resetBtn.dataset.bound) {
            resetBtn.dataset.bound = '1';
            resetBtn.addEventListener('click', function(e) {
                e.preventDefault();

                if (mode === 'create') {
                    fetchLiveDirectories('create', '', true);
                } else {
                    fetchLiveDirectories('edit', editTreeOriginalPath || '', true);
                }
            });
        }
    });
}

function prepareCreateSubaccountModal() {
    bindDirectoryTreeButtons();

    const currentPath = document.getElementById('cs-dir') ? document.getElementById('cs-dir').value : '';

    resetDirectoryTree('create', currentPath);
    fetchLiveDirectories('create', currentPath, false);
}

function prepareEditSubaccountModal(selectedPath) {
    bindDirectoryTreeButtons();

    const path = selectedPath || editTreeOriginalPath || '';

    resetDirectoryTree('edit', path);
    fetchLiveDirectories('edit', path, false);
}

function escapeHtml(str) {
    return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function toggleSubActionMenu(button, event) {
    if (event) event.stopPropagation();

    const wrap = button ? button.closest('.hd-actions-menu-wrap') : null;

    document.querySelectorAll('.hd-actions-menu-wrap.is-open').forEach(el => {
        if (el !== wrap) el.classList.remove('is-open');
    });

    if (wrap) wrap.classList.toggle('is-open');
}

function closeSubActionMenus() {
    document.querySelectorAll('.hd-actions-menu-wrap.is-open').forEach(el => el.classList.remove('is-open'));
}

function showSubaccountDetailsPending() {
    document.getElementById('sd-modal-title').innerHTML = '<i class="fas fa-circle-notch fa-spin hd-inline-spinner" style="color: var(--hd-accent);"></i><span>Subaccount is being created</span>';
    document.getElementById('sd-modal-desc').innerHTML = 'To access a subaccount, you should use the subaccount username and the domain of the subaccount instead of the main account data. The access information will be displayed automatically once the process is complete.';

    ['sd-user', 'sd-smb', 'sd-url'].forEach(id => {
        const el = document.getElementById(id);

        if (el) {
            el.value = '';
            el.readOnly = true;
            el.classList.add('hd-subaccount-pending-field');
            el.blur();
        }
    });

    openModal('subDetailsModal');
}

function clearSubaccountDetailsPending() {
    ['sd-user', 'sd-smb', 'sd-url'].forEach(id => {
        const el = document.getElementById(id);

        if (el) el.classList.remove('hd-subaccount-pending-field');
    });
}

async function submitCreateSubaccount() {
    const selectedDir = document.getElementById('cs-dir').value || 'new_directory';
    const dirError = validateDirectoryPathClient(selectedDir);

    if (dirError) {
        showNotification('Validation Error', dirError, true);
        return;
    }

    const pass = document.getElementById('cs-pass').value.trim();

    if (!pass) {
        showNotification('Validation Error', 'Please enter a password or generate a random one.', true);
        return;
    }

    const btn = document.getElementById('btn-create-sub');
    const originalText = btn ? btn.innerHTML : '';

    if (btn) {
        btn.innerHTML = '<i class="fas fa-circle-notch fa-spin me-2"></i> Creating...';
        btn.disabled = true;
    }

    const payload = {
        home_directory: selectedDir,
        comment: document.getElementById('cs-desc').value,
        password: pass,
        samba: document.getElementById('cs-smb').checked ? 1 : 0,
        webdav: document.getElementById('cs-webdav').checked ? 1 : 0,
        ssh: document.getElementById('cs-ssh').checked ? 1 : 0,
        external_reachability: document.getElementById('cs-ext').checked ? 1 : 0,
        readonly: document.getElementById('cs-ro').checked ? 1 : 0,
        read_only: document.getElementById('cs-ro').checked ? 1 : 0
    };

    try {
        closeModal('createSubModal');
        showSubaccountDetailsPending();

        const data = await postAction('create_subaccount', payload);

        if (data.status === 'success' && data.new_username) {
            await silentRefresh(true);
            refreshPageDataAfterAction();
            clearSubaccountDetailsPending();
            showSubaccountDetails(data.new_username, true);

            document.getElementById('cs-pass').value = '';
            document.getElementById('cs-desc').value = '';

            resetCreateSubaccountTree();
        } else {
            closeAllModals();
            showNotification('Error', friendlyActionError(data.error || 'We could not create this subaccount right now.'), true);
            refreshPageDataAfterAction();
        }
    } catch (e) {
        closeAllModals();
        showNotification('Error', friendlyActionError(e.message || 'We could not create this subaccount right now.'), true);
        refreshPageDataAfterAction();
    } finally {
        if (btn) {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    }
}

function promptEditSubaccount(username, directory, comment, samba, webdav, ssh, ext, ro) {
    closeSubActionMenus();

    document.getElementById('es-user').value = username;
    document.getElementById('es-desc').value = comment;
    document.getElementById('es-smb').checked = (samba == 1);
    document.getElementById('es-webdav').checked = (webdav == 1);
    document.getElementById('es-ssh').checked = (ssh == 1);
    document.getElementById('es-ext').checked = (ext == 1);
    document.getElementById('es-ro').checked = (ro == 1);

    editTreeOriginalPath = normalizeDirectoryPath(directory) || 'new_directory';

    openModal('editSubModal');
    prepareEditSubaccountModal(editTreeOriginalPath);
}

function submitEditSubaccount() {
    const selectedDir = document.getElementById('es-dir').value || 'new_directory';
    const dirError = validateDirectoryPathClient(selectedDir);

    if (dirError) {
        showNotification('Validation Error', dirError, true);
        return;
    }

    const payload = {
        subaccount_username: document.getElementById('es-user').value,
        home_directory: selectedDir,
        comment: document.getElementById('es-desc').value,
        samba: document.getElementById('es-smb').checked ? 1 : 0,
        webdav: document.getElementById('es-webdav').checked ? 1 : 0,
        ssh: document.getElementById('es-ssh').checked ? 1 : 0,
        external_reachability: document.getElementById('es-ext').checked ? 1 : 0,
        readonly: document.getElementById('es-ro').checked ? 1 : 0,
        read_only: document.getElementById('es-ro').checked ? 1 : 0
    };

    executeActionWithNotification('update_subaccount', payload, 'btn-edit-sub', 'Saving...', 'Subaccount Updated', 'Subaccount settings successfully applied.', () => {
        refreshPageDataAfterAction();
    });
}

function showSubaccountDetails(username, isNew = false, server = '') {
    closeSubActionMenus();
    clearSubaccountDetailsPending();

    const row = document.querySelector('[data-subaccount-username="' + (window.CSS && CSS.escape ? CSS.escape(username) : username) + '"]');
    const rowServer = row ? (row.getAttribute('data-subaccount-server') || '') : '';
    const baseHostEl = document.getElementById('hd-endpoint');
    const mainUserEl = document.getElementById('hd-username');
    const baseHost = baseHostEl ? baseHostEl.innerText.trim() : '';
    const mainUser = mainUserEl ? mainUserEl.innerText.trim() : '';
    const fallbackHost = baseHost && mainUser ? baseHost.replace(mainUser, username) : username;
    const subHost = (server || rowServer || fallbackHost || '').trim();

    document.getElementById('sd-user').value = username;
    document.getElementById('sd-smb').value = subHost ? '\\\\' + subHost + '\\' + username : '';
    document.getElementById('sd-url').value = subHost;

    if (isNew) {
        document.getElementById('sd-modal-title').innerText = 'Subaccount created';
        document.getElementById('sd-modal-desc').innerHTML = 'To access a subaccount, use the subaccount username and subaccount domain instead of the main account data.';
    } else {
        document.getElementById('sd-modal-title').innerText = 'Subaccount Access Details';
        document.getElementById('sd-modal-desc').innerHTML = 'To access a subaccount, use the subaccount username and subaccount domain instead of the main account data.';
    }

    openModal('subDetailsModal');
}

function promptDeleteSubaccount(username) {
    closeSubActionMenus();
    document.getElementById('ds-user').value = username;
    openModal('deleteSubModal');
}

function removeSubaccountRowFromUi(username) {
    const safeId = 'sub-row-' + String(username || '').replace(/[^A-Za-z0-9_-]/g, '_');
    let row = document.getElementById(safeId);

    if (!row && window.CSS && typeof CSS.escape === 'function') {
        row = document.querySelector('[data-subaccount-username="' + CSS.escape(username) + '"]');
    }

    if (row) row.remove();
}

function submitDeleteSubaccount() {
    const user = document.getElementById('ds-user').value;

    executeActionWithNotification('delete_subaccount', {
        subaccount_username: user
    }, 'btn-delete-sub', 'Deleting...', 'Subaccount Deleted', 'Subaccount permanently removed.', () => {
        removeSubaccountRowFromUi(user);
        refreshPageDataAfterAction();
    });
}

function promptSubaccountPassword(username) {
    closeSubActionMenus();

    document.getElementById('rs-user').value = username;
    document.getElementById('rs-user-display').innerText = username;
    document.getElementById('rs-pass').value = '';

    openModal('resetSubPassModal');
}

function submitResetSubPass() {
    const user = document.getElementById('rs-user').value;
    const pass = document.getElementById('rs-pass').value.trim();

    if (!pass) {
        showNotification('Validation Error', 'Please enter a new password.', true);
        return;
    }

    executeActionWithNotification('reset_subaccount_password', {
        subaccount_username: user,
        password: pass
    }, 'btn-reset-sub', 'Processing...', 'Password Reset', 'Subaccount password securely updated.', (data) => {
        refreshPageDataAfterAction();

        if (data.new_password) {
            showNotification('Password Reset', `Password successfully reset.<br><br><strong style="font-size: 1.1rem; color: var(--hd-accent); background: rgba(var(--hd-accent-rgb), 0.1); padding: 5px 10px; border-radius: 4px; font-family: monospace; word-break: break-all;">${escapeHtml(data.new_password)}</strong><br><br><span style="font-size: 0.8rem; color: var(--hd-danger);">Copy and securely save your password. It won't be shown again.</span>`, false);
            return false;
        }
    });
}

document.addEventListener('click', function(event) {
    if (!event.target.closest('.hd-actions-menu-wrap')) {
        closeSubActionMenus();
    }
});

document.addEventListener('keydown', function(event) {
    if (event.key === "Escape") {
        const backdrop = document.getElementById('hd-modal-backdrop');

        if (backdrop && backdrop.style.display === 'block') {
            const isProcessing = document.querySelector('.hd-modal[style*="display: flex"] button:disabled');

            if (!isProcessing) {
                closeAllModals();
            }
        }
    }
});
{/literal}
</script>
