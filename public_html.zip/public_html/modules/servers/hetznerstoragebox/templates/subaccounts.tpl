<div class="hd-tab-content" id="hd-subaccounts">
    <div class="hd-subaccounts-shell">
        <div class="hd-subaccounts-hero">
            <div class="hd-subaccounts-hero-icon"><i class="fas fa-users"></i></div>
            <h5>Subaccounts</h5>
            <p>With a subaccount, you can create another user and assign a directory for this user. When the user logs in, they will only be able to access the files saved in this directory.</p>
            <button type="button" class="hd-btn-primary hd-subaccount-create-btn" onclick="openModal('createSubModal')">
                <i class="fas fa-plus-circle"></i> Create subaccount
            </button>
        </div>

        <div class="hd-subaccounts-table-card">
            <div class="hd-table-wrapper hd-responsive-table hd-subaccounts-table-wrap">
                <table class="hd-table hd-subaccounts-table">
                    <thead>
                        <tr>
                            <th>USERNAME</th>
                            <th>DESCRIPTION</th>
                            <th class="text-center">SMB</th>
                            <th class="text-center">WEBDAV</th>
                            <th class="text-center">SSH</th>
                            <th class="text-center">EXT.<br>REACH.</th>
                            <th class="text-center">READ<br>ONLY</th>
                            <th>BASE DIR.</th>
                            <th class="text-end">ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="hd-subaccounts-tbody">
                        {foreach from=$subaccounts item=sub}
                            {assign var=subUsername value=$sub.username|default:$sub.name|default:''}
                            {assign var=subServer value=$sub.server|default:''}
                            {assign var=subDesc value=$sub.description|default:$sub.comment|default:''}
                            {assign var=subDirRaw value=$sub.home_directory|default:$sub.homedirectory|default:$sub.directory|default:'new_directory'}
                            {assign var=subDirClean value=$subDirRaw|regex_replace:"/^[\/]+|[\/]+$/":""}
                            {if $subDirClean eq ''}{assign var=subDirClean value='new_directory'}{/if}
                            {assign var=subSmb value=$sub.access_settings.samba_enabled|default:$sub.samba_enabled|default:$sub.samba|default:0}
                            {assign var=subWebdav value=$sub.access_settings.webdav_enabled|default:$sub.webdav_enabled|default:$sub.webdav|default:0}
                            {assign var=subSsh value=$sub.access_settings.ssh_enabled|default:$sub.ssh_enabled|default:$sub.ssh|default:0}
                            {assign var=subExt value=$sub.access_settings.reachable_externally|default:$sub.reachable_externally|default:$sub.external_reachability|default:0}
                            {assign var=subReadonly value=$sub.access_settings.readonly|default:$sub.access_settings.read_only|default:$sub.readonly|default:$sub.read_only|default:0}
                            <tr id="sub-row-{$subUsername|escape:'html'}" data-subaccount-username="{$subUsername|escape:'html'}" data-subaccount-server="{$subServer|escape:'html'}">
                                <td class="fw-bold hd-subaccount-username" data-label="Username">
                                    <button type="button" class="hd-subaccount-copy-pill hd-subaccount-username-pill" onclick="copyPlainText('{$subUsername|escape:'javascript'}', 'Username copied.'); return false;" title="Click to copy username">
                                        <span>{$subUsername|escape:'html'}</span><i class="fas fa-copy"></i>
                                    </button>
                                </td>
                                <td class="hd-subaccount-desc" data-label="Description">{if $subDesc ne ''}{$subDesc|escape:'html'}{else}<span class="text-muted">--</span>{/if}</td>
                                <td class="text-center" data-label="SMB">{if $subSmb}<span class="hd-status-icon is-yes"><i class="fas fa-check"></i></span>{else}<span class="hd-status-icon is-no"><i class="fas fa-times"></i></span>{/if}</td>
                                <td class="text-center" data-label="WebDAV">{if $subWebdav}<span class="hd-status-icon is-yes"><i class="fas fa-check"></i></span>{else}<span class="hd-status-icon is-no"><i class="fas fa-times"></i></span>{/if}</td>
                                <td class="text-center" data-label="SSH">{if $subSsh}<span class="hd-status-icon is-yes"><i class="fas fa-check"></i></span>{else}<span class="hd-status-icon is-no"><i class="fas fa-times"></i></span>{/if}</td>
                                <td class="text-center" data-label="Ext. reach.">{if $subExt}<span class="hd-status-icon is-yes"><i class="fas fa-check"></i></span>{else}<span class="hd-status-icon is-no"><i class="fas fa-times"></i></span>{/if}</td>
                                <td class="text-center" data-label="Read-only">{if $subReadonly}<span class="hd-status-icon is-yes"><i class="fas fa-check"></i></span>{else}<span class="hd-status-icon is-no"><i class="fas fa-times"></i></span>{/if}</td>
                                <td class="hd-subaccount-dir" data-label="Base dir.">
                                    <button type="button" class="hd-subaccount-copy-pill hd-subaccount-dir-pill" onclick="copyPlainText('/{$subDirClean|escape:'javascript'}/', 'Base directory copied.'); return false;" title="Click to copy base directory">
                                        <code>/{$subDirClean|escape:'html'}/</code><i class="fas fa-copy"></i>
                                    </button>
                                </td>
                                <td class="text-end hd-subaccount-actions" data-label="Actions">
                                    <div class="hd-subaccount-actions-inline" aria-label="Subaccount actions">
                                        <button type="button" class="hd-subaccount-icon-action" onclick="showSubaccountDetails('{$subUsername|escape:'javascript'}', false, '{$subServer|escape:'javascript'}'); return false;" title="Access details" aria-label="Access details">
                                            <i class="fas fa-info-circle"></i>
                                        </button>
                                        <button type="button" class="hd-subaccount-icon-action" onclick="promptEditSubaccount('{$subUsername|escape:'javascript'}', '{$subDirClean|escape:'javascript'}', '{$subDesc|escape:'javascript'}', {if $subSmb}1{else}0{/if}, {if $subWebdav}1{else}0{/if}, {if $subSsh}1{else}0{/if}, {if $subExt}1{else}0{/if}, {if $subReadonly}1{else}0{/if}); return false;" title="Edit" aria-label="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" class="hd-subaccount-icon-action" onclick="promptSubaccountPassword('{$subUsername|escape:'javascript'}'); return false;" title="Reset password" aria-label="Reset password">
                                            <i class="fas fa-key"></i>
                                        </button>
                                        <button type="button" class="hd-subaccount-icon-action is-danger" onclick="promptDeleteSubaccount('{$subUsername|escape:'javascript'}'); return false;" title="Delete" aria-label="Delete">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        {foreachelse}
                            <tr><td colspan="9" class="text-center py-5 text-muted" data-label="Subaccounts"><i class="fas fa-users fa-2x mb-2 d-block opacity-50"></i> No subaccounts found.</td></tr>
                        {/foreach}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
