<div class="hd-tab-content active" id="hd-overview">
    {assign var="active_auto_snaps" value=0}
    {foreach from=$snapshots item=snap}
        {assign var="snapType" value=$snap.type_label|default:$snap.type|default:''}
        {assign var="snapDesc" value=$snap.description|default:$snap.name|default:''}

        {if $snapType|lower == 'automatic' || $snapType|lower == 'auto' || $snapDesc|lower|strstr:'automatic' || $snapDesc|lower|strstr:'auto'}
            {assign var="active_auto_snaps" value=$active_auto_snaps+1}
        {/if}
    {/foreach}

    <div class="hd-panel mb-4">
        <div class="hd-section-title"><i class="fas fa-hdd"></i> QUOTA</div>
        <div class="hd-specs-wrapper" id="hd-live-specs" style="border: none; padding: 0;">
            <div class="hd-specs-grid">
                <div class="hd-circle-gauge">
                    <div>
                        <div class="val">{$usedDisplay|escape:'html'}</div>
                        <div class="lbl">Disk<br>usage</div>
                    </div>
                </div>

                <div class="hd-circle-gauge">
                    <div>
                        <div class="val">{$snapshots|@count}/{$snapshotMaxAmount|default:$box.storage_box_type.snapshot_limit|default:'10'}</div>
                        <div class="lbl">Snapshots</div>
                    </div>
                </div>

                <div class="hd-circle-gauge">
                    <div>
                        <div class="val">{$active_auto_snaps}/{$autoSnapshotMaxAmount|default:$box.storage_box_type.automatic_snapshot_limit|default:'10'}</div>
                        <div class="lbl">Auto<br>snapshots</div>
                    </div>
                </div>

                <div class="hd-circle-gauge">
                    <div>
                        <div class="val">{$subaccounts|@count}/{$box.storage_box_type.subaccounts_limit|default:$box.storage_box_type.max_subaccounts|default:'100'}</div>
                        <div class="lbl">Subaccounts</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="hd-overview-grid">
        <div class="hd-panel">
            <div class="hd-section-title" style="color: var(--hd-accent);"><i class="fas fa-list-alt"></i> Details</div>
            <div class="hd-table-wrapper">
                <table class="hd-table">
                    <tbody id="hd-server-details">
                        <tr>
                            <th style="width: 30%;">Hostname</th>
                            <td>
                                <div class="hd-data-pill" title="{$storageEndpoint|escape:'html'}">
                                    <span id="hd-endpoint">{$storageEndpoint|escape:'html'}</span>
                                    <i class="fas fa-copy hd-copy-icon" onclick="copyToClipboard('hd-endpoint')"></i>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th>Username</th>
                            <td>
                                <div class="hd-data-pill" title="{$storageUsername|escape:'html'}">
                                    <span id="hd-username">{$storageUsername|escape:'html'}</span>
                                    <i class="fas fa-copy hd-copy-icon" onclick="copyToClipboard('hd-username')"></i>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th>Samba/CIFS Mount</th>
                            <td>
                                <div class="hd-data-pill" title="//{$storageEndpoint|escape:'html'}/backup">
                                    <span id="hd-smb-share">//{$storageEndpoint|escape:'html'}/backup</span>
                                    <i class="fas fa-copy hd-copy-icon" onclick="copyToClipboard('hd-smb-share')"></i>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th>Secure Port (SSH)</th>
                            <td>
                                <div class="hd-data-pill">
                                    <span id="hd-ssh-port">23</span>
                                    <i class="fas fa-copy hd-copy-icon" onclick="copyToClipboard('hd-ssh-port')"></i>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th>Location</th>
                            <td id="hd-location-map" class="fw-bold" style="color: var(--hd-accent);">
                                {assign var="locLower" value=$storageLocation|lower}
                                <i class="fas fa-map-marker-alt me-1"></i>
                                {if $locLower|strstr:'fsn' || $locLower|strstr:'nbg'}Germany
                                {elseif $locLower|strstr:'hel'}Finland
                                {elseif $locLower|strstr:'ash' || $locLower|strstr:'hil'}USA
                                {else}{$storageLocation|escape:'html'}
                                {/if}
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="hd-panel d-flex flex-column">
            <div class="hd-section-title" style="color: var(--hd-accent);"><i class="fas fa-network-wired"></i> Protocols</div>

            <div class="hd-settings-list hd-protocols-list mb-3" id="hd-access-protocols">
                <div class="hd-settings-item" style="cursor: default;">
                    <span class="lbl-text flex-grow-1">External Reachability</span>
                    <span class="fw-bold" id="proto-ext">{if $accessSettings.reachable_externally}Yes{else}No{/if}</span>
                </div>

                <div class="hd-settings-item" style="cursor: default;">
                    <span class="lbl-text flex-grow-1">SSH Support</span>
                    <span class="fw-bold" id="proto-ssh">{if $accessSettings.ssh_enabled}Yes{else}No{/if}</span>
                </div>

                <div class="hd-settings-item" style="cursor: default;">
                    <span class="lbl-text flex-grow-1">Samba Support</span>
                    <span class="fw-bold" id="proto-smb">{if $accessSettings.samba_enabled}Yes{else}No{/if}</span>
                </div>

                <div class="hd-settings-item" style="cursor: default; border-bottom: 0;">
                    <span class="lbl-text flex-grow-1">WebDAV Support</span>
                    <span class="fw-bold" id="proto-webdav">{if $accessSettings.webdav_enabled}Yes{else}No{/if}</span>
                </div>
            </div>

            <button type="button" class="hd-btn-outline w-100" style="padding: 10px;" onclick="openModal('settingsModal')">
                Configure Routing
            </button>
        </div>
    </div>
</div>