<div class="hd-tab-content" id="hd-access">
    <div class="hd-panel text-center" style="max-width: 600px; margin: 40px auto;">
        <i class="fas fa-user-shield fa-3x mb-3" style="color: var(--hd-accent);"></i>
        <h3 class="fw-bold mb-3">Security & Authentication</h3>
        <p class="text-muted mb-4" style="line-height: 1.6;">
            {if $accessChoice eq 'ssh_key'}
                Your environment is currently secured via strictly enforced SSH Key authentication. Password-based access is internally disabled.
            {else}
                Your storage instance is secured with a private password. If you suspect a breach or forgot your credentials, securely reset your password below.
            {/if}
        </p>
        {if $allowPasswordReset}
            <button type="button" class="hd-btn-primary py-2 px-4" onclick="openModal('passwordModal')">
                <i class="fas fa-key me-2"></i> Reset Password
            </button>
        {/if}
    </div>
</div>