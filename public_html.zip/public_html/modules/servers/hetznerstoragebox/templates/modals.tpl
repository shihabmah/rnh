<div id="hd-modal-backdrop" class="hd-modal-backdrop"></div>

<div id="notificationModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title" id="notif-title">Status</h5>
        <button type="button" class="hd-close" onclick="closeModal('notificationModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body text-center pb-4">
        <i id="notif-icon" class="fas fa-check-circle fa-3x mb-3 mt-3" style="color: var(--hd-success);"></i>
        <p id="notif-msg" class="mb-4" style="line-height: 1.5;"></p>
        <button type="button" class="hd-btn-primary w-100" onclick="closeModal('notificationModal')">Acknowledge</button>
    </div>
</div>

<div id="settingsModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title">Configure Routing</h5>
        <button type="button" class="hd-close" onclick="closeModal('settingsModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <p class="text-muted mb-4" style="font-size: 0.9rem; text-align: left;">Toggle network access methods for your storage box.</p>
        
        <div class="hd-settings-list mb-4">
            <label class="hd-settings-item">
                <input type="checkbox" id="modal-chk-ext" class="form-check-input" {if $accessSettings.reachable_externally}checked{/if}>
                <span class="lbl-text">External Reachability</span>
            </label>
            <label class="hd-settings-item">
                <input type="checkbox" id="modal-chk-ssh" class="form-check-input" {if $accessSettings.ssh_enabled}checked{/if}>
                <span class="lbl-text">SSH Support</span>
            </label>
            <label class="hd-settings-item">
                <input type="checkbox" id="modal-chk-smb" class="form-check-input" {if $accessSettings.samba_enabled}checked{/if}>
                <span class="lbl-text">Samba Support</span>
            </label>
            <label class="hd-settings-item">
                <input type="checkbox" id="modal-chk-webdav" class="form-check-input" {if $accessSettings.webdav_enabled}checked{/if}>
                <span class="lbl-text">WebDAV Support</span>
            </label>
        </div>

        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('settingsModal')">Discard</button>
            <button type="button" class="hd-btn-primary" id="btn-save-settings" onclick="saveAccessSettings()">Apply Changes</button>
        </div>
    </div>
</div>

<div id="passwordModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title">Reset Password</h5>
        <button type="button" class="hd-close" onclick="closeModal('passwordModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="fw-bold text-muted" style="font-size: 0.8rem;">NEW PASSWORD <span class="text-danger">*</span></span>
            <a href="javascript:void(0);" onclick="setGeneratedStorageBoxPassword()" style="color: var(--hd-accent); font-weight: normal; font-size: 0.85rem;">Create random password</a>
        </div>

        <input type="text" id="hd-new-password" class="hd-input mb-2" placeholder="Enter a secure password" autocomplete="off" oninput="updatePasswordRequirementState()">
        <div id="hd-password-rules" class="hd-password-rules mb-4">
            <div class="hd-password-rule" data-rule="length"><i class="fas fa-circle"></i><span>Password must be between 8 and 32 characters long.</span></div>
            <div class="hd-password-rule" data-rule="uppercase"><i class="fas fa-circle"></i><span>Password must contain at least one uppercase letter.</span></div>
            <div class="hd-password-rule" data-rule="lowercase"><i class="fas fa-circle"></i><span>Password must contain at least one lowercase letter.</span></div>
            <div class="hd-password-rule" data-rule="number"><i class="fas fa-circle"></i><span>Password must contain at least one number.</span></div>
            <div class="hd-password-note"><i class="fas fa-info-circle me-1"></i> The new password is applied directly to the Cloud Storage and will not be emailed because you are setting it here.</div>
        </div>

        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('passwordModal')">Cancel</button>
            <button type="button" class="hd-btn-primary" id="btn-reset-password" onclick="submitPasswordReset()">Submit</button>
        </div>
    </div>
</div>

<div id="createSnapshotModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title">Create Snapshot</h5>
        <button type="button" class="hd-close" onclick="closeModal('createSnapshotModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <label class="fw-bold mb-2 d-block text-muted" style="font-size: 0.8rem;">DESCRIPTION <span class="text-danger">*</span></label>
        <input type="text" id="newSnapshotDesc" class="hd-input mb-4" value="{$snapshotSuggestedDescription|escape:'html'}" placeholder="{$snapshotSuggestedDescription|escape:'html'}">
        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('createSnapshotModal')">Cancel</button>
            <button type="button" class="hd-btn-primary" id="btn-create-snap" onclick="submitCreateSnapshot()">Create Snapshot</button>
        </div>
    </div>
</div>

<div id="autoSnapshotModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title">{if $autoSnapshotEnabled}Change automatic snapshot settings{else}Enable automatic snapshots{/if}</h5>
        <button type="button" class="hd-close" onclick="closeModal('autoSnapshotModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <p class="text-muted mb-4" style="font-size: 0.9rem; text-align: left;">{if $autoSnapshotEnabled}Change the schedule for automatic snapshots.{else}Choose the schedule and maximum amount, then enable automatic snapshots in Cloud Storage.{/if}</p>
        <input type="hidden" id="hd-snapshot-max-amount" value="{$snapshotMaxAmount|default:'10'|escape:'html'}">
        <div class="hd-auto-snapshot-row mb-3">
            <div style="flex: 2 1 220px; min-width: 180px;">
                <label class="small fw-bold mb-1 text-muted">Frequency</label>
                <select id="autoSnapInterval" class="hd-input" onchange="updateAutoSnapshotFrequencyFields()">
                    <option value="daily" {if $autoSnapshotFrequency eq 'daily'}selected{/if}>Daily</option>
                    <option value="weekly" {if $autoSnapshotFrequency eq 'weekly'}selected{/if}>Weekly</option>
                    <option value="monthly" {if $autoSnapshotFrequency eq 'monthly'}selected{/if}>Monthly</option>
                </select>
            </div>
            <div style="flex: 1 1 170px; min-width: 160px;">
                <label class="small fw-bold mb-1 text-muted">Max Amount</label>
                <input type="number" id="autoSnapMax" class="hd-input" value="{$autoSnapshotMaxAmount|default:$snapshotMaxAmount|escape:'html'}" min="1" max="{$snapshotMaxAmount|default:'10'|escape:'html'}" data-max="{$snapshotMaxAmount|default:'10'|escape:'html'}" oninput="clampAutoSnapshotMax(false)" onblur="clampAutoSnapshotMax(true)">
            </div>
        </div>
        <div class="mb-4">
            <label class="small fw-bold mb-1 text-muted">Execution Time (UTC)</label>
            <div class="d-flex align-items-center flex-wrap" style="gap: 12px;">
                <select id="autoSnapHour" class="hd-input text-center" style="width: 100px;">
                    {section name=h start=0 loop=24}
                        {assign var=hourValue value="%02d"|sprintf:$smarty.section.h.index}
                        <option value="{$hourValue}" {if $autoSnapshotHour eq $hourValue}selected{/if}>{$hourValue}</option>
                    {/section}
                </select>
                <span class="fw-bold" style="font-size: 1.2rem; margin-bottom: 2px;">:</span>
                <select id="autoSnapMin" class="hd-input text-center" style="width: 100px;">
                    {section name=m start=0 loop=60}
                        {assign var=minuteValue value="%02d"|sprintf:$smarty.section.m.index}
                        <option value="{$minuteValue}" {if $autoSnapshotMinute eq $minuteValue}selected{/if}>{$minuteValue}</option>
                    {/section}
                </select>
            </div>
        </div>

        <div id="autoSnapWeeklyRow" class="mb-4" style="display: none;">
            <label class="small fw-bold mb-1 text-muted">Day of week</label>
            <select id="autoSnapDayOfWeek" class="hd-input">
                <option value="1" {if $autoSnapshotDayOfWeek|default:1 eq 1}selected{/if}>Monday</option>
                <option value="2" {if $autoSnapshotDayOfWeek|default:1 eq 2}selected{/if}>Tuesday</option>
                <option value="3" {if $autoSnapshotDayOfWeek|default:1 eq 3}selected{/if}>Wednesday</option>
                <option value="4" {if $autoSnapshotDayOfWeek|default:1 eq 4}selected{/if}>Thursday</option>
                <option value="5" {if $autoSnapshotDayOfWeek|default:1 eq 5}selected{/if}>Friday</option>
                <option value="6" {if $autoSnapshotDayOfWeek|default:1 eq 6}selected{/if}>Saturday</option>
                <option value="7" {if $autoSnapshotDayOfWeek|default:1 eq 7}selected{/if}>Sunday</option>
            </select>
        </div>

        <div id="autoSnapMonthlyRow" class="mb-4" style="display: none;">
            <label class="small fw-bold mb-1 text-muted">Day of month</label>
            <input type="number" id="autoSnapDayOfMonth" class="hd-input" value="{$autoSnapshotDayOfMonth|default:'1'|escape:'html'}" min="1" max="31" oninput="clampAutoSnapshotDayOfMonth(false)" onblur="clampAutoSnapshotDayOfMonth(true)">
            <div class="small text-muted mt-3" id="autoSnapMonthNotice" style="display: none; line-height: 1.4;">
                <i class="fas fa-info-circle me-1"></i> If the selected day does not exist in a given month, the automatic snapshot will be skipped and resume in the next applicable month.
            </div>
        </div>
        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('autoSnapshotModal')">Cancel</button>
            <button type="button" class="hd-btn-primary" id="btn-enable-auto" onclick="submitAutoSnapshot()">{if $autoSnapshotEnabled}Save{else}Save &amp; Enable{/if}</button>
        </div>
    </div>
</div>

<div id="disableAutoSnapshotModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title">Disable Automatic Snapshots</h5>
        <button type="button" class="hd-close" onclick="closeModal('disableAutoSnapshotModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <p class="mb-4 mt-2">Are you sure you want to disable automatic snapshots? Existing snapshots will remain, but future snapshots will no longer be created automatically.</p>
        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('disableAutoSnapshotModal')">Cancel</button>
            <button type="button" class="hd-btn-primary" id="btn-disable-auto" onclick="submitDisableAutoSnapshot()">Disable</button>
        </div>
    </div>
</div>

<div id="deleteSnapshotModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title"><i class="fas fa-exclamation-triangle me-2"></i> Delete Snapshot</h5>
        <button type="button" class="hd-close" onclick="closeModal('deleteSnapshotModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <p class="mb-4 mt-2">Are you sure you want to permanently delete this snapshot? This action cannot be undone.</p>
        <input type="hidden" id="deleteSnapshotId" value="">
        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('deleteSnapshotModal')">Cancel</button>
            <button type="button" class="hd-btn-danger" id="btn-delete-snap" onclick="submitDeleteSnapshot()">Delete</button>
        </div>
    </div>
</div>

<div id="restoreSnapshotModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title"><i class="fas fa-history me-2"></i> Restore Snapshot</h5>
        <button type="button" class="hd-close" onclick="closeModal('restoreSnapshotModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <p class="mb-4 mt-2">If you restore this snapshot, all newer snapshots and data created after this point will be deleted. Are you sure?</p>
        <input type="hidden" id="restoreSnapshotId" value="">
        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('restoreSnapshotModal')">Cancel</button>
            <button type="button" class="hd-btn-primary" id="btn-restore-snap" onclick="submitRestoreSnapshot()">Restore snapshot</button>
        </div>
    </div>
</div>

<div id="createSubModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title">Create subaccount</h5>
        <button type="button" class="hd-close" onclick="closeModal('createSubModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body hd-subaccount-modal-body" style="padding-top: 15px;">
        <label class="fw-bold mb-2 text-muted" style="font-size: 0.8rem; display: block;">BASE DIRECTORY <span class="text-danger">*</span></label>
        <div class="tree-directory-rule mb-2"><i class="fas fa-info-circle me-1"></i> Whitespace is not allowed at the beginning or end of a directory name. Existing directories are shown from Cloud Storage and cannot be renamed or deleted here.</div>
        <div id="cs-tree" class="hd-tree-container mb-2"></div>
        <div id="cs-selected-path" class="tree-selected-path"></div>
        <div id="cs-tree-status" class="tree-sync-status"></div>
        <div class="d-flex gap-2 flex-wrap mb-4">
            <button type="button" class="tree-mini-btn" id="cs-addRootBtn"><i class="fas fa-folder-plus"></i> Add main directory</button>
            <button type="button" class="tree-mini-btn" style="color: var(--hd-text-main); border-color: var(--hd-border);" id="cs-resetBtn"><i class="fas fa-undo"></i> Reset</button>
        </div>
        <input type="hidden" id="cs-dir" value="new_directory">

        <label class="fw-bold mb-3 d-block text-muted" style="font-size: 0.8rem;">ADDITIONAL SETTINGS</label>
        <div class="hd-checkbox-grid mb-4">
            <label class="hd-checkbox-label"><input type="checkbox" id="cs-smb" class="form-check-input"> Allow SMB</label>
            <label class="hd-checkbox-label"><input type="checkbox" id="cs-webdav" class="form-check-input"> Allow WebDAV</label>
            <label class="hd-checkbox-label"><input type="checkbox" id="cs-ssh" class="form-check-input"> Allow SSH</label>
            <label class="hd-checkbox-label"><input type="checkbox" id="cs-ext" class="form-check-input"> External reachability</label>
            <label class="hd-checkbox-label"><input type="checkbox" id="cs-ro" class="form-check-input"> Read-Only</label>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-1">
            <span class="fw-bold text-muted" style="font-size: 0.8rem;">PASSWORD <span class="text-danger">*</span></span>
            <a href="javascript:void(0);" onclick="document.getElementById('cs-pass').value = generateSecurePass()" style="color: var(--hd-accent); font-weight: normal; font-size: 0.85rem;">Create random password</a>
        </div>
        <input type="text" id="cs-pass" class="hd-input mb-4" placeholder="Enter a secure password">

        <label class="fw-bold mb-1 text-muted" style="font-size: 0.8rem;">DESCRIPTION <span class="fw-normal">(Optional)</span></label>
        <input type="text" id="cs-desc" class="hd-input mb-4" placeholder="Add description">

        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('createSubModal')">Cancel</button>
            <button type="button" class="hd-btn-primary" id="btn-create-sub" onclick="submitCreateSubaccount()">Create subaccount</button>
        </div>
    </div>
</div>

<div id="editSubModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title">Edit subaccount</h5>
        <button type="button" class="hd-close" onclick="closeModal('editSubModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body hd-subaccount-modal-body" style="padding-top: 15px;">
        <input type="hidden" id="es-user">
        
        <label class="fw-bold mb-2 text-muted" style="font-size: 0.8rem; display: block;">BASE DIRECTORY <span class="text-danger">*</span></label>
        <div class="tree-directory-rule mb-2"><i class="fas fa-info-circle me-1"></i> Whitespace is not allowed at the beginning or end of a directory name. Existing directories cannot be renamed or deleted from this panel. Use Child/Add main directory to create a new directory.</div>
        <div id="es-tree" class="hd-tree-container mb-2"></div>
        <div id="es-selected-path" class="tree-selected-path"></div>
        <div id="es-tree-status" class="tree-sync-status"></div>
        <div class="d-flex gap-2 flex-wrap mb-4">
            <button type="button" class="tree-mini-btn" id="es-addRootBtn"><i class="fas fa-folder-plus"></i> Add main directory</button>
            <button type="button" class="tree-mini-btn" style="color: var(--hd-text-main); border-color: var(--hd-border);" id="es-resetBtn"><i class="fas fa-undo"></i> Reset</button>
        </div>
        <input type="hidden" id="es-dir" value="new_directory">

        <label class="fw-bold mb-3 d-block text-muted" style="font-size: 0.8rem;">ADDITIONAL SETTINGS</label>
        <div class="hd-checkbox-grid mb-4">
            <label class="hd-checkbox-label"><input type="checkbox" id="es-smb" class="form-check-input"> Allow SMB</label>
            <label class="hd-checkbox-label"><input type="checkbox" id="es-webdav" class="form-check-input"> Allow WebDAV</label>
            <label class="hd-checkbox-label"><input type="checkbox" id="es-ssh" class="form-check-input"> Allow SSH</label>
            <label class="hd-checkbox-label"><input type="checkbox" id="es-ext" class="form-check-input"> External reachability</label>
            <label class="hd-checkbox-label"><input type="checkbox" id="es-ro" class="form-check-input"> Read-Only</label>
        </div>

        <label class="fw-bold mb-1 text-muted" style="font-size: 0.8rem;">DESCRIPTION <span class="fw-normal">(Optional)</span></label>
        <input type="text" id="es-desc" class="hd-input mb-4" placeholder="Add description">

        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('editSubModal')">Cancel</button>
            <button type="button" class="hd-btn-primary" id="btn-edit-sub" onclick="submitEditSubaccount()">Save</button>
        </div>
    </div>
</div>

<div id="subDetailsModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title" id="sd-modal-title">Subaccount Access Details</h5>
        <button type="button" class="hd-close" onclick="closeModal('subDetailsModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <p class="text-muted mb-4" id="sd-modal-desc" style="font-size: 0.9rem;">To access a subaccount, you should use the subaccount username and the domain of the subaccount instead of the main account data.</p>
        
        <label class="fw-bold mb-1 text-muted" style="font-size: 0.8rem;">USERNAME</label>
        <div class="hd-copy-input-row mb-3">
            <input type="text" id="sd-user" class="hd-input" readonly style="background: rgba(127,138,150,0.05) !important;">
            <button type="button" class="hd-copy-field-btn" onclick="copyToClipboard('sd-user')" title="Copy username"><i class="fas fa-copy"></i></button>
        </div>
        
        <label class="fw-bold mb-1 text-muted" style="font-size: 0.8rem;">SMB/CIFS SHARE</label>
        <div class="hd-copy-input-row mb-3">
            <input type="text" id="sd-smb" class="hd-input" readonly style="background: rgba(127,138,150,0.05) !important;">
            <button type="button" class="hd-copy-field-btn" onclick="copyToClipboard('sd-smb')" title="Copy SMB/CIFS share"><i class="fas fa-copy"></i></button>
        </div>
        
        <label class="fw-bold mb-1 text-muted" style="font-size: 0.8rem;">URL FOR OTHER PROTOCOLS</label>
        <div class="hd-copy-input-row mb-2">
            <input type="text" id="sd-url" class="hd-input" readonly style="background: rgba(127,138,150,0.05) !important;">
            <button type="button" class="hd-copy-field-btn" onclick="copyToClipboard('sd-url')" title="Copy URL"><i class="fas fa-copy"></i></button>
        </div>
    </div>
</div>

<div id="deleteSubModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title"><i class="fas fa-exclamation-triangle me-2"></i> Delete Subaccount</h5>
        <button type="button" class="hd-close" onclick="closeModal('deleteSubModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <p class="mb-4 mt-2">Are you sure you want to completely delete this subaccount? This action cannot be undone.</p>
        <input type="hidden" id="ds-user">
        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('deleteSubModal')">Cancel</button>
            <button type="button" class="hd-btn-danger" id="btn-delete-sub" onclick="submitDeleteSubaccount()">Delete</button>
        </div>
    </div>
</div>

<div id="resetSubPassModal" class="hd-modal">
    <div class="hd-modal-header">
        <h5 class="hd-modal-title">Reset Subaccount Password</h5>
        <button type="button" class="hd-close" onclick="closeModal('resetSubPassModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="hd-modal-body">
        <p class="text-muted mb-2" style="font-size: 0.9rem;">Resetting password for subaccount: <strong id="rs-user-display" class="text-main"></strong></p>
        
        <input type="hidden" id="rs-user">
        
        <div class="d-flex justify-content-between align-items-center mb-1 mt-4">
            <span class="fw-bold text-muted" style="font-size: 0.8rem;">NEW PASSWORD <span class="text-danger">*</span></span>
            <a href="javascript:void(0);" onclick="document.getElementById('rs-pass').value = generateSecurePass()" style="color: var(--hd-accent); font-weight: normal; font-size: 0.85rem;">Create random password</a>
        </div>
        <input type="text" id="rs-pass" class="hd-input mb-2" placeholder="Enter a new password">
        <div class="hd-password-note mb-4"><i class="fas fa-info-circle me-1"></i> Copy and securely save your password. It won't be shown again.</div>

        <div class="d-flex justify-content-end" style="gap: 16px;">
            <button type="button" class="hd-btn-outline" onclick="closeModal('resetSubPassModal')">Cancel</button>
            <button type="button" class="hd-btn-primary" id="btn-reset-sub" onclick="submitResetSubPass()">Reset Password</button>
        </div>
    </div>
</div>