<?php

namespace HetznerStorageBox;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class HetznerClient
{
    private $token;
    private $moduleName;
    private $baseUrl = 'https://api.hetzner.com/v1/';

    public function __construct($token, $moduleName = 'hetznerstoragebox')
    {
        $this->token = trim((string) $token);
        $this->moduleName = (string) $moduleName;

        if ($this->token === '') {
            throw new \RuntimeException('Hetzner API token is missing.');
        }
    }

    public function get($endpoint, array $query = [])
    {
        return $this->request('GET', $endpoint, $query);
    }

    public function post($endpoint, array $payload = [])
    {
        return $this->request('POST', $endpoint, $payload);
    }

    public function put($endpoint, array $payload = [])
    {
        return $this->request('PUT', $endpoint, $payload);
    }

    public function delete($endpoint, array $payload = [])
    {
        return $this->request('DELETE', $endpoint, $payload);
    }

    public function waitForAction($endpoint, $timeoutSeconds = 180, $sleepSeconds = 2)
    {
        $timeoutAt = time() + max(10, (int) $timeoutSeconds);

        do {
            $response = $this->get($endpoint);
            $action = (array) ($response['action'] ?? []);
            $status = strtolower((string) ($action['status'] ?? ''));

            if ($status === 'success') {
                return $action;
            }

            if ($status === 'error') {
                $error = (array) ($action['error'] ?? []);
                $message = (string) ($error['message'] ?? 'Hetzner action failed.');
                throw new \RuntimeException($message);
            }

            sleep(max(1, (int) $sleepSeconds));
        } while (time() < $timeoutAt);

        throw new \RuntimeException('Timed out while waiting for the Hetzner action to finish.');
    }

    private function request($method, $endpoint, array $data = [])
    {
        $method = strtoupper((string) $method);
        $url = $this->baseUrl . ltrim((string) $endpoint, '/');

        if ($method === 'GET' && !empty($data)) {
            $url .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($data);
        }

        $attempt = 0;
        $maxAttempts = 3;
        $lastError = 'Unknown API communication error.';

        while ($attempt < $maxAttempts) {
            $attempt++;
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $this->token,
                'Content-Type: application/json',
                'Accept: application/json',
                'User-Agent: WHMCS-HetznerStorageBox/1.0',
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 45);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_HEADER, true);

            if ($method !== 'GET' && !empty($data)) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }

            $raw = curl_exec($ch);
            $curlError = curl_error($ch);
            $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $headerSize = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            curl_close($ch);

            if ($raw === false || $curlError !== '') {
                $lastError = $curlError !== '' ? $curlError : 'Unknown cURL error';
                $this->logCall($method . ' ' . $endpoint, $data, ['curl_error' => $lastError]);

                if ($attempt < $maxAttempts) {
                    sleep($attempt);
                    continue;
                }

                throw new \RuntimeException('Network error while communicating with Hetzner: ' . $lastError);
            }

            $body = substr($raw, $headerSize);
            $decoded = json_decode($body, true);

            if ($httpCode >= 200 && $httpCode < 300) {
                return is_array($decoded) ? $decoded : [];
            }

            $error = is_array($decoded) ? (array) ($decoded['error'] ?? []) : [];
            $lastError = (string) ($error['message'] ?? ('Hetzner API request failed with HTTP ' . $httpCode));
            $this->logCall($method . ' ' . $endpoint, $data, ['http_code' => $httpCode, 'response' => $decoded]);

            if (in_array($httpCode, [429, 500, 503, 504], true) && $attempt < $maxAttempts) {
                sleep($attempt * 2);
                continue;
            }

            throw new \RuntimeException($lastError);
        }

        throw new \RuntimeException($lastError);
    }

    private function maskSensitiveData($value)
    {
        if (!is_array($value)) {
            return $value;
        }

        $sensitive = [
            'password', 'servicepassword', 'serverpassword', 'token', 'api_token',
            'authorization', 'ssh_keys', 'ssh_public_key', 'customvars',
        ];

        foreach ($value as $key => $item) {
            if (is_array($item)) {
                $value[$key] = $this->maskSensitiveData($item);
                continue;
            }

            if (in_array(strtolower((string) $key), $sensitive, true)) {
                $value[$key] = '***REDACTED***';
            }
        }

        return $value;
    }

    private function logCall($action, array $request, array $response)
    {
        if (!function_exists('logModuleCall')) {
            return;
        }

        logModuleCall(
            $this->moduleName,
            $action,
            $this->maskSensitiveData($request),
            $this->maskSensitiveData($response)
        );
    }
}
