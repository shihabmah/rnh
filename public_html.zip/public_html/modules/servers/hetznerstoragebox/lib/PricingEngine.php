<?php

namespace HetznerStorageBox;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class PricingEngine
{
    public static function periodMap()
    {
        return [
            'monthly' => 1,
            'quarterly' => 3,
            'semiannually' => 6,
            'annually' => 12,
            'biennially' => 24,
            'triennially' => 36,
        ];
    }

    public static function periodLabel($period)
    {
        $labels = [
            'monthly' => 'Monthly',
            'quarterly' => 'Quarterly',
            'semiannually' => 'Semi-Annually',
            'annually' => 'Annually',
            'biennially' => 'Biennially',
            'triennially' => 'Triennially',
        ];

        return $labels[$period] ?? ucfirst((string) $period);
    }

    public static function minorUnits($currencyCode)
    {
        $currencyCode = strtoupper((string) $currencyCode);

        $zeroDecimal = [
            'BIF', 'CLP', 'DJF', 'GNF', 'ISK', 'JPY', 'KMF', 'KRW',
            'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF',
        ];
        $threeDecimal = ['BHD', 'IQD', 'JOD', 'KWD', 'LYD', 'OMR', 'TND'];

        if (in_array($currencyCode, $zeroDecimal, true)) {
            return 0;
        }

        if (in_array($currencyCode, $threeDecimal, true)) {
            return 3;
        }

        return 2;
    }

    public static function roundUp($amount, $currencyCode)
    {
        $precision = self::minorUnits($currencyCode);
        $factor = pow(10, $precision);

        return ceil(((float) $amount) * $factor - 0.0000001) / $factor;
    }

    public static function calculatePeriodPrice($monthlyBase, $marginPercent, $conversionRate, $targetCurrencyCode, $multiplier)
    {
        $monthlyBase = (float) $monthlyBase;
        $marginPercent = (float) $marginPercent;
        $conversionRate = (float) $conversionRate;
        $multiplier = (int) $multiplier;

        $monthlyWithMargin = $monthlyBase * (1 + ($marginPercent / 100));
        $convertedMonthly = $monthlyWithMargin * $conversionRate;
        $roundedMonthly = self::roundUp($convertedMonthly, $targetCurrencyCode);
        $periodRaw = $roundedMonthly * $multiplier;
        $periodRounded = self::roundUp($periodRaw, $targetCurrencyCode);

        return [
            'monthly_raw' => $convertedMonthly,
            'monthly_rounded' => $roundedMonthly,
            'period_raw' => $periodRaw,
            'period_rounded' => $periodRounded,
        ];
    }

    public static function format($amount, $currencyCode)
    {
        return number_format((float) $amount, self::minorUnits($currencyCode), '.', '');
    }
}
