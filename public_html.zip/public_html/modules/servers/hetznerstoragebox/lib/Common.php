<?php

namespace HetznerStorageBox;

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class Common
{
    const SERVER_MODULE = 'hetznerstoragebox';
    const ADDON_MODULE = 'hetznerstoragebox_manager';

    public static function ensureSchema()
    {
        $schema = Capsule::schema();

        if (!$schema->hasTable('mod_hetznerstoragebox_services')) {
            $schema->create('mod_hetznerstoragebox_services', function ($table) {
                $table->integer('service_id')->primary();
                $table->integer('product_id')->default(0);
                $table->bigInteger('storage_box_id')->nullable();
                $table->string('username', 64)->nullable();
                $table->string('endpoint', 255)->nullable();
                $table->string('location_name', 32)->nullable();
                $table->string('box_type_name', 32)->nullable();
                $table->string('status', 32)->default('pending');
                $table->bigInteger('last_action_id')->nullable();
                $table->string('last_action_command', 64)->nullable();
                $table->text('meta_json')->nullable();
                $table->dateTime('last_synced')->nullable();
                $table->dateTime('created_at')->nullable();
                $table->dateTime('updated_at')->nullable();
            });
        }

        if (!$schema->hasTable('mod_hetznerstoragebox_catalog')) {
            $schema->create('mod_hetznerstoragebox_catalog', function ($table) {
                $table->increments('id');
                $table->string('type_name', 32)->unique();
                $table->string('description_text', 255)->nullable();
                $table->bigInteger('size_bytes')->default(0);
                $table->integer('snapshot_limit')->nullable();
                $table->integer('automatic_snapshot_limit')->nullable();
                $table->integer('subaccounts_limit')->nullable();
                $table->mediumText('prices_json')->nullable();
                $table->mediumText('raw_json')->nullable();
                $table->dateTime('updated_at')->nullable();
            });
        }

        if (!$schema->hasTable('mod_hetznerstoragebox_product_configs')) {
            $schema->create('mod_hetznerstoragebox_product_configs', function ($table) {
                $table->integer('product_id')->primary();
                $table->mediumText('config_json')->nullable();
                $table->dateTime('updated_at')->nullable();
            });
        }

        if (!$schema->hasTable('mod_hetznerstoragebox_events')) {
            $schema->create('mod_hetznerstoragebox_events', function ($table) {
                $table->increments('id');
                $table->integer('service_id')->nullable()->index();
                $table->string('level', 16)->default('info');
                $table->string('category', 32)->default('general');
                $table->text('message');
                $table->mediumText('context_json')->nullable();
                $table->dateTime('created_at')->nullable();
            });
        }

        if (!$schema->hasTable('mod_hetznerstoragebox_metrics')) {
            $schema->create('mod_hetznerstoragebox_metrics', function ($table) {
                $table->increments('id');
                $table->integer('service_id')->index();
                $table->bigInteger('size_bytes')->default(0);
                $table->bigInteger('size_data_bytes')->default(0);
                $table->bigInteger('size_snapshots_bytes')->default(0);
                $table->dateTime('captured_at')->nullable();
            });
        }
    }

    public static function now()
    {
        return date('Y-m-d H:i:s');
    }

    public static function decodeEntities($value)
    {
        if (is_array($value)) {
            foreach ($value as $key => $item) {
                $value[$key] = self::decodeEntities($item);
            }

            return $value;
        }

        if ($value === null) {
            return null;
        }

        return html_entity_decode(trim((string) $value), ENT_QUOTES, 'UTF-8');
    }

    public static function boolValue($value)
    {
        if (is_bool($value)) {
            return $value;
        }

        return in_array(strtolower(trim((string) $value)), ['1', 'true', 'yes', 'on'], true);
    }

    public static function intValue($value, $default = 0)
    {
        return is_numeric($value) ? (int) $value : (int) $default;
    }

    public static function jsonDecodeArray($value)
    {
        if (is_array($value)) {
            return $value;
        }

        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? $decoded : [];
    }

    public static function jsonEncode(array $value)
    {
        return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    public static function recursiveMerge(array $existing, array $patch)
    {
        foreach ($patch as $key => $value) {
            if (is_array($value) && isset($existing[$key]) && is_array($existing[$key])) {
                $existing[$key] = self::recursiveMerge($existing[$key], $value);
                continue;
            }

            $existing[$key] = self::decodeEntities($value);
        }

        return $existing;
    }

    public static function firstActiveAdminUsername()
    {
        $admin = Capsule::table('tbladmins')->where('disabled', 0)->orderBy('id', 'asc')->first();
        return $admin ? (string) $admin->username : '';
    }

    public static function localApi($command, array $data)
    {
        if (!function_exists('localAPI')) {
            return [];
        }

        $admin = self::firstActiveAdminUsername();
        return localAPI($command, $data, $admin ?: null);
    }

    public static function addonConfig()
    {
        $config = [];

        if (function_exists('getAddonModuleConfiguration')) {
            try {
                $config = (array) getAddonModuleConfiguration(self::ADDON_MODULE);
            } catch (\Throwable $exception) {
                $config = [];
            }
        }

        if (empty($config)) {
            try {
                foreach (Capsule::table('tbladdonmodules')->where('module', self::ADDON_MODULE)->get() as $row) {
                    $config[$row->setting] = $row->value;
                }
            } catch (\Throwable $exception) {
                $config = [];
            }
        }

        return self::decodeEntities($config);
    }

    public static function resolveApiToken(array $params = [])
    {
        $perServer = self::decodeEntities($params['serverpassword'] ?? '');
        if ($perServer !== '') {
            return $perServer;
        }

        $addon = self::addonConfig();
        $token = self::decodeEntities($addon['global_api_token'] ?? '');
        if ($token !== '') {
            return $token;
        }

        throw new \RuntimeException('No Hetzner API token is configured. Set it in the Hetzner Storage Box Manager addon or on the server credential.');
    }

    public static function getApiClient(array $params = [])
    {
        return new HetznerClient(self::resolveApiToken($params), self::SERVER_MODULE);
    }

    public static function defaultProductConfig()
    {
        return [
            'default_location' => 'fsn1',
            'default_storage_box_type' => 'bx11',
            'default_access' => [
                'reachable_externally' => true,
                'ssh_enabled' => true,
                'samba_enabled' => true,
                'webdav_enabled' => true,
                'zfs_enabled' => false,
            ],
            'client_features' => [
                'label_editor' => true,
                'manual_refresh' => true,
                'password_reset' => true,
            ],
            'billing' => [
                'auto_terminate_enabled' => true,
                'overdue_days' => 3,
            ],
            'pricing' => [
                'base_price_mode' => 'net',
                'margin_percent' => '15',
                'selected_currency_ids' => [],
                'selected_periods' => ['monthly'],
                'apply_daily' => false,
            ],
        ];
    }

    public static function fallbackProductConfigFromParams(array $params = [])
    {
        return [
            'default_location' => trim((string) ($params['configoption1'] ?? 'fsn1')),
            'default_storage_box_type' => trim((string) ($params['configoption2'] ?? 'bx11')),
            'default_access' => [
                'reachable_externally' => self::boolValue($params['configoption3'] ?? true),
                'ssh_enabled' => self::boolValue($params['configoption4'] ?? true),
                'samba_enabled' => self::boolValue($params['configoption5'] ?? true),
                'webdav_enabled' => self::boolValue($params['configoption6'] ?? true),
                'zfs_enabled' => self::boolValue($params['configoption7'] ?? false),
            ],
            'client_features' => [
                'label_editor' => self::boolValue($params['configoption8'] ?? true),
                'manual_refresh' => true,
                'password_reset' => self::boolValue($params['configoption9'] ?? true),
            ],
            'billing' => [
                'overdue_days' => self::intValue($params['configoption10'] ?? 3, 3),
                'auto_terminate_enabled' => true,
            ],
            'pricing' => [
                'apply_daily' => self::boolValue($params['configoption11'] ?? false),
            ],
        ];
    }

    public static function loadProductConfig($productId, array $params = [])
    {
        self::ensureSchema();

        $config = self::recursiveMerge(self::defaultProductConfig(), self::fallbackProductConfigFromParams($params));
        $row = Capsule::table('mod_hetznerstoragebox_product_configs')->where('product_id', (int) $productId)->first();

        if ($row && !empty($row->config_json)) {
            $config = self::recursiveMerge($config, self::jsonDecodeArray($row->config_json));
        }

        $config['default_access']['reachable_externally'] = self::boolValue($config['default_access']['reachable_externally'] ?? true);
        $config['default_access']['ssh_enabled'] = self::boolValue($config['default_access']['ssh_enabled'] ?? true);
        $config['default_access']['samba_enabled'] = self::boolValue($config['default_access']['samba_enabled'] ?? true);
        $config['default_access']['webdav_enabled'] = self::boolValue($config['default_access']['webdav_enabled'] ?? true);
        $config['default_access']['zfs_enabled'] = self::boolValue($config['default_access']['zfs_enabled'] ?? false);
        $config['client_features']['label_editor'] = self::boolValue($config['client_features']['label_editor'] ?? true);
        $config['client_features']['manual_refresh'] = self::boolValue($config['client_features']['manual_refresh'] ?? true);
        $config['client_features']['password_reset'] = self::boolValue($config['client_features']['password_reset'] ?? true);
        $config['billing']['auto_terminate_enabled'] = self::boolValue($config['billing']['auto_terminate_enabled'] ?? true);
        $config['billing']['overdue_days'] = max(0, self::intValue($config['billing']['overdue_days'] ?? 3, 3));
        $config['pricing']['apply_daily'] = self::boolValue($config['pricing']['apply_daily'] ?? false);
        $config['pricing']['selected_currency_ids'] = array_values(array_filter(array_map('intval', (array) ($config['pricing']['selected_currency_ids'] ?? []))));
        $config['pricing']['selected_periods'] = array_values(array_filter((array) ($config['pricing']['selected_periods'] ?? ['monthly'])));

        return $config;
    }

    public static function saveProductConfig($productId, array $patch)
    {
        $merged = self::recursiveMerge(self::loadProductConfig($productId), $patch);

        Capsule::table('mod_hetznerstoragebox_product_configs')->updateOrInsert(
            ['product_id' => (int) $productId],
            ['config_json' => self::jsonEncode($merged), 'updated_at' => self::now()]
        );

        return $merged;
    }

    public static function getManagedProducts()
    {
        return Capsule::table('tblproducts')
            ->where('servertype', self::SERVER_MODULE)
            ->orderBy('name', 'asc')
            ->get();
    }

    public static function getServiceRecord($serviceId)
    {
        self::ensureSchema();
        return Capsule::table('mod_hetznerstoragebox_services')->where('service_id', (int) $serviceId)->first();
    }

    public static function saveServiceRecord($serviceId, array $data)
    {
        self::ensureSchema();

        $existing = self::getServiceRecord($serviceId);
        $currentMeta = $existing && !empty($existing->meta_json) ? self::jsonDecodeArray($existing->meta_json) : [];

        if (isset($data['meta_json']) && is_array($data['meta_json'])) {
            $currentMeta = self::recursiveMerge($currentMeta, $data['meta_json']);
        }

        Capsule::table('mod_hetznerstoragebox_services')->updateOrInsert(
            ['service_id' => (int) $serviceId],
            [
                'product_id' => array_key_exists('product_id', $data) ? (int) $data['product_id'] : (int) ($existing->product_id ?? 0),
                'storage_box_id' => array_key_exists('storage_box_id', $data)
                    ? ($data['storage_box_id'] === null ? null : (int) $data['storage_box_id'])
                    : ($existing->storage_box_id ?? null),
                'username' => array_key_exists('username', $data) ? $data['username'] : ($existing->username ?? null),
                'endpoint' => array_key_exists('endpoint', $data) ? $data['endpoint'] : ($existing->endpoint ?? null),
                'location_name' => array_key_exists('location_name', $data) ? $data['location_name'] : ($existing->location_name ?? null),
                'box_type_name' => array_key_exists('box_type_name', $data) ? $data['box_type_name'] : ($existing->box_type_name ?? null),
                'status' => (string) ($data['status'] ?? ($existing->status ?? 'pending')),
                'last_action_id' => array_key_exists('last_action_id', $data)
                    ? ($data['last_action_id'] === null ? null : (int) $data['last_action_id'])
                    : ($existing->last_action_id ?? null),
                'last_action_command' => array_key_exists('last_action_command', $data) ? $data['last_action_command'] : ($existing->last_action_command ?? null),
                'meta_json' => self::jsonEncode($currentMeta),
                'last_synced' => array_key_exists('last_synced', $data) ? $data['last_synced'] : ($existing->last_synced ?? null),
                'created_at' => $existing->created_at ?? self::now(),
                'updated_at' => self::now(),
            ]
        );
    }

    public static function logEvent($serviceId, $level, $category, $message, array $context = [])
    {
        self::ensureSchema();

        Capsule::table('mod_hetznerstoragebox_events')->insert([
            'service_id' => $serviceId ? (int) $serviceId : null,
            'level' => substr((string) $level, 0, 16),
            'category' => substr((string) $category, 0, 32),
            'message' => (string) $message,
            'context_json' => !empty($context) ? self::jsonEncode($context) : null,
            'created_at' => self::now(),
        ]);
    }

    public static function recentEvents($serviceId, $limit = 20)
    {
        return Capsule::table('mod_hetznerstoragebox_events')
            ->where('service_id', (int) $serviceId)
            ->orderBy('id', 'desc')
            ->limit((int) $limit)
            ->get();
    }

    public static function captureMetric($serviceId, array $stats)
    {
        self::ensureSchema();

        $last = Capsule::table('mod_hetznerstoragebox_metrics')
            ->where('service_id', (int) $serviceId)
            ->orderBy('id', 'desc')
            ->first();

        if ($last && strtotime((string) $last->captured_at) > (time() - 43200)) {
            return;
        }

        Capsule::table('mod_hetznerstoragebox_metrics')->insert([
            'service_id' => (int) $serviceId,
            'size_bytes' => (int) ($stats['size'] ?? 0),
            'size_data_bytes' => (int) ($stats['size_data'] ?? 0),
            'size_snapshots_bytes' => (int) ($stats['size_snapshots'] ?? 0),
            'captured_at' => self::now(),
        ]);
    }

    public static function recentMetrics($serviceId, $limit = 14)
    {
        return Capsule::table('mod_hetznerstoragebox_metrics')
            ->where('service_id', (int) $serviceId)
            ->orderBy('id', 'desc')
            ->limit((int) $limit)
            ->get();
    }

    public static function updateKnownCustomFields($productId, $serviceId, array $values)
    {
        foreach ($values as $fieldName => $value) {
            $field = Capsule::table('tblcustomfields')
                ->where('type', 'product')
                ->where('relid', (int) $productId)
                ->where('fieldname', (string) $fieldName)
                ->first();

            if (!$field) {
                continue;
            }

            Capsule::table('tblcustomfieldsvalues')->updateOrInsert(
                ['fieldid' => (int) $field->id, 'relid' => (int) $serviceId],
                ['value' => (string) $value]
            );
        }
    }

    public static function getCustomFieldValue(array $params, array $candidates)
    {
        $customFields = (array) ($params['customfields'] ?? []);
        if (empty($customFields)) {
            return '';
        }

        $normalized = [];
        foreach ($customFields as $key => $value) {
            $normalized[strtolower(trim((string) $key))] = self::decodeEntities($value);
        }

        foreach ($candidates as $candidate) {
            $lookup = strtolower(trim((string) $candidate));
            if (array_key_exists($lookup, $normalized)) {
                return (string) $normalized[$lookup];
            }
        }

        return '';
    }

    public static function getConfigurableOptionValue(array $params, array $candidates)
    {
        $options = (array) ($params['configoptions'] ?? []);
        if (empty($options)) {
            return '';
        }

        $normalized = [];
        foreach ($options as $key => $value) {
            $normalized[strtolower(trim((string) $key))] = self::decodeEntities($value);
        }

        foreach ($candidates as $candidate) {
            $lookup = strtolower(trim((string) $candidate));
            if (array_key_exists($lookup, $normalized)) {
                return (string) $normalized[$lookup];
            }
        }

        return '';
    }

    public static function safeStorageBoxName(array $params)
    {
        return 'hd-storage-' . substr(str_shuffle(md5(microtime())), 0, 10);
    }

    public static function normalizeStorageBoxType($value)
    {
        $value = strtolower(trim((string) $value));
        if ($value === '') {
            return '';
        }

        if (preg_match('/\b(bx\d+)\b/', $value, $matches)) {
            return $matches[1];
        }

        return $value;
    }

    public static function resolveStorageBoxTypeValue($value, $fallback = 'bx11')
    {
        $rawValue = self::decodeEntities($value);
        $candidate = self::normalizeStorageBoxType($rawValue);
        if (preg_match('/^bx\d+$/', $candidate)) {
            return $candidate;
        }

        $generic = [
            'quota',
            'quota level',
            'storage type',
            'storage box type',
            'type',
            'storage',
        ];

        $needle = strtolower(trim((string) $rawValue));
        if ($needle === '' || in_array($needle, $generic, true)) {
            return self::normalizeStorageBoxType($fallback);
        }

        foreach (self::getCatalogItems() as $item) {
            $typeName = strtolower(trim((string) $item->type_name));
            $description = strtolower(trim((string) $item->description_text));
            $sizeBytes = (int) $item->size_bytes;
            $sizeTb = $sizeBytes > 0 ? round($sizeBytes / 1099511627776, 2) : 0;
            $sizeGb = $sizeBytes > 0 ? round($sizeBytes / 1073741824, 2) : 0;

            $aliases = array_filter([
                $typeName,
                $description,
                self::humanBytes($sizeBytes),
                $sizeTb > 0 ? rtrim(rtrim(number_format($sizeTb, 2, '.', ''), '0'), '.') . ' tb' : '',
                $sizeGb > 0 ? rtrim(rtrim(number_format($sizeGb, 2, '.', ''), '0'), '.') . ' gb' : '',
                $typeName . ' - ' . $description,
            ]);

            foreach ($aliases as $alias) {
                $alias = strtolower(trim((string) $alias));
                if ($alias === '') {
                    continue;
                }

                if ($needle === $alias || strpos($needle, $alias) !== false || strpos($alias, $needle) !== false) {
                    return $typeName;
                }
            }
        }

        return self::normalizeStorageBoxType($fallback);
    }

    public static function normalizeLocation($value)
    {
        $value = strtolower(trim((string) $value));
        if ($value === '') {
            return '';
        }

        if (preg_match('/\b([a-z]{3,4}\d)\b/', $value, $matches)) {
            return $matches[1];
        }

        return preg_replace('/[^a-z0-9-]+/', '', $value);
    }

    public static function parseSshKeys($value)
    {
        $keys = preg_split('/\r\n|\r|\n/', (string) $value);
        $result = [];

        foreach ($keys as $line) {
            $line = trim((string) $line);
            if ($line === '' || stripos($line, 'ssh-') !== 0) {
                continue;
            }

            $result[] = $line;
        }

        return array_values(array_unique($result));
    }

    public static function parseLabels($value)
    {
        $labels = [];
        $lines = preg_split('/\r\n|\r|\n/', (string) $value);

        foreach ($lines as $line) {
            $line = trim((string) $line);
            if ($line === '' || strpos($line, '=') === false) {
                continue;
            }

            list($key, $labelValue) = array_pad(explode('=', $line, 2), 2, '');
            $key = trim((string) $key);
            $labelValue = trim((string) $labelValue);

            if ($key === '') {
                continue;
            }

            $labels[$key] = $labelValue;
        }

        return $labels;
    }

    public static function formatLabels(array $labels, array $excludePrefixes = ['whmcs_', 'internal_id'])
    {
        $lines = [];
        foreach ($labels as $key => $value) {
            $skip = false;
            foreach ($excludePrefixes as $prefix) {
                if (strpos((string) $key, (string) $prefix) === 0) {
                    $skip = true;
                    break;
                }
            }

            if ($skip) {
                continue;
            }

            $lines[] = $key . '=' . $value;
        }

        return implode("\n", $lines);
    }

    public static function filterVisibleLabels(array $labels)
    {
        $visible = [];
        foreach ($labels as $key => $value) {
            if (strpos((string) $key, 'whmcs_') === 0 || strpos((string) $key, 'internal_id') === 0) {
                continue;
            }

            $visible[$key] = $value;
        }

        return $visible;
    }

    public static function validateLabels(array $labels)
    {
        $labelPattern = '/^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,61}[A-Za-z0-9])?$/';
        $prefixPattern = '/^(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(?:\.(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?))*$/';

        foreach ($labels as $key => $value) {
            $key = trim((string) $key);
            $value = (string) $value;

            if ($key === '') {
                throw new \RuntimeException('Label keys may not be empty.');
            }

            if (strpos($key, 'hetzner.cloud/') === 0) {
                throw new \RuntimeException('The hetzner.cloud/ label prefix is reserved and cannot be used.');
            }

            $prefix = '';
            $name = $key;
            if (strpos($key, '/') !== false) {
                list($prefix, $name) = array_pad(explode('/', $key, 2), 2, '');
            }

            if ($name === '' || !preg_match($labelPattern, $name)) {
                throw new \RuntimeException('One or more label keys do not match the Hetzner label format.');
            }

            if ($prefix !== '' && !preg_match($prefixPattern, $prefix)) {
                throw new \RuntimeException('One or more label prefixes do not match the Hetzner label format.');
            }

            if ($value !== '' && !preg_match($labelPattern, $value)) {
                throw new \RuntimeException('One or more label values do not match the Hetzner label format.');
            }

            if (strlen($key) > 253 || strlen($value) > 63) {
                throw new \RuntimeException('One or more labels are too long for the Hetzner API.');
            }
        }
    }

    public static function generateStrongPassword($length = 18)
    {
        $length = max(12, (int) $length);
        $upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        $lower = 'abcdefghijkmnopqrstuvwxyz';
        $digits = '23456789';
        $special = '^!$%/()=?+#-.,:~*@{}_&';
        $all = $upper . $lower . $digits . $special;

        $password = [
            $upper[random_int(0, strlen($upper) - 1)],
            $lower[random_int(0, strlen($lower) - 1)],
            $digits[random_int(0, strlen($digits) - 1)],
            $special[random_int(0, strlen($special) - 1)],
        ];

        while (count($password) < $length) {
            $password[] = $all[random_int(0, strlen($all) - 1)];
        }

        shuffle($password);
        return implode('', $password);
    }

    public static function resolveOrderSpec(array $params, array $config = [])
    {
        $locationValue = self::getConfigurableOptionValue($params, ['Location', 'Storage Box Location']);
        $typeValue = self::getConfigurableOptionValue($params, ['Storage Type', 'Storage Box Type', 'Quota Level', 'Quota']);
        $sshKeyValue = self::getCustomFieldValue($params, ['SSH Public Key', 'SSH Public Keys']);
        
        $location = self::normalizeLocation($locationValue ?: ($config['default_location'] ?? 'fsn1'));
        $storageBoxType = self::resolveStorageBoxTypeValue($typeValue, $config['default_storage_box_type'] ?? 'bx11');
        $sshKeys = self::parseSshKeys($sshKeyValue);

        // Logic check: fallback to password if SSH key array is empty
        $accessChoice = !empty($sshKeys) ? 'ssh_key' : 'password';

        $labelValue = self::getCustomFieldValue($params, ['Storage Box Labels', 'Labels']);
        $labels = self::parseLabels($labelValue);
        
        // Standard labels
        $labels['whmcs_service_id'] = (string) (int) ($params['serviceid'] ?? 0);
        $labels['whmcs_product_id'] = (string) (int) ($params['pid'] ?? 0);
        
        // Increment label with 'Hetzner Dedicated' related prefix
        $labels['internal_id'] = 'hd-storagebox-' . (int) ($params['serviceid'] ?? 0);
        
        self::validateLabels($labels);

        // Force all additional access settings to TRUE by default (ZFS is handled by the toggle UI)
        $accessSettings = [
            'reachable_externally' => true,
            'ssh_enabled' => true,
            'samba_enabled' => true,
            'webdav_enabled' => true,
            'zfs_enabled' => false,
        ];

        return [
            'name' => self::safeStorageBoxName($params),
            'location' => $location !== '' ? $location : 'fsn1',
            'storage_box_type' => $storageBoxType !== '' ? $storageBoxType : 'bx11',
            'password' => self::generateStrongPassword(),
            'password_disclosed' => $accessChoice === 'password',
            'access_choice' => $accessChoice,
            'ssh_keys' => $sshKeys,
            'labels' => $labels,
            'access_settings' => $accessSettings,
        ];
    }

    public static function humanBytes($bytes)
    {
        $bytes = (float) $bytes;
        $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        $index = 0;

        while ($bytes >= 1024 && $index < count($units) - 1) {
            $bytes /= 1024;
            $index++;
        }

        return number_format($bytes, $index === 0 ? 0 : 2, '.', '') . ' ' . $units[$index];
    }

    public static function updateServiceDetails($serviceId, array $box, array $extra = [])
    {
        $stats = (array) ($box['stats'] ?? []);
        $type = (array) ($box['storage_box_type'] ?? []);
        $payload = [
            'serviceid' => (int) $serviceId,
            'serviceusername' => (string) ($box['username'] ?? ''),
            'diskusage' => (string) floor(((float) ($stats['size'] ?? 0)) / 1048576),
            'disklimit' => (string) max(0, floor(((float) ($type['size'] ?? 0)) / 1048576)),
        ];

        foreach ($extra as $key => $value) {
            $payload[$key] = $value;
        }

        try {
            self::localApi('UpdateClientProduct', $payload);
        } catch (\Throwable $exception) {
            self::logEvent($serviceId, 'warning', 'sync', 'Unable to update WHMCS service counters.', ['error' => $exception->getMessage()]);
        }
    }

    public static function syncStorageBox(array $params, $serviceId, $storageBoxId, $captureMetric = true)
    {
        $client = self::getApiClient($params);
        $response = $client->get('/storage_boxes/' . (int) $storageBoxId);
        $box = (array) ($response['storage_box'] ?? []);

        if (empty($box)) {
            throw new \RuntimeException('Hetzner did not return a Storage Box payload.');
        }

        self::saveServiceRecord($serviceId, [
            'storage_box_id' => (int) ($box['id'] ?? $storageBoxId),
            'username' => (string) ($box['username'] ?? ''),
            'endpoint' => (string) ($box['server'] ?? ''),
            'location_name' => (string) (($box['location']['name'] ?? '') ?: ''),
            'box_type_name' => (string) (($box['storage_box_type']['name'] ?? '') ?: ''),
            'status' => (string) ($box['status'] ?? 'active'),
            'last_synced' => self::now(),
            'meta_json' => ['box' => $box],
        ]);

        if ($captureMetric) {
            self::captureMetric($serviceId, (array) ($box['stats'] ?? []));
        }

        self::updateServiceDetails($serviceId, $box);
        return $box;
    }

    public static function markTerminationReason($serviceId, $reason, $detail = '')
    {
        self::saveServiceRecord($serviceId, [
            'meta_json' => [
                'termination_context' => [
                    'reason' => (string) $reason,
                    'detail' => (string) $detail,
                    'marked_at' => self::now(),
                ],
            ],
        ]);
    }

    public static function terminationReason($serviceId)
    {
        $record = self::getServiceRecord($serviceId);
        if (!$record) {
            return [];
        }

        $meta = self::jsonDecodeArray($record->meta_json);
        return (array) ($meta['termination_context'] ?? []);
    }

    public static function clearTerminationReason($serviceId)
    {
        $record = self::getServiceRecord($serviceId);
        if (!$record) {
            return;
        }

        $meta = self::jsonDecodeArray($record->meta_json);
        unset($meta['termination_context']);
        self::saveServiceRecord($serviceId, ['meta_json' => $meta]);
    }

    public static function classifyTerminationOutcome($serviceId)
    {
        $context = self::terminationReason($serviceId);
        $reason = strtolower((string) ($context['reason'] ?? ''));

        if ($reason === 'completed') {
            return 'completed';
        }

        if ($reason !== '') {
            return 'terminated';
        }

        $service = Capsule::table('tblhosting')->where('id', (int) $serviceId)->first();
        $status = strtolower((string) ($service->domainstatus ?? ''));

        if (in_array($status, ['cancelled', 'completed'], true) || self::hasCancelRequest($serviceId)) {
            return 'completed';
        }

        return 'terminated';
    }

    public static function hasCancelRequest($serviceId)
    {
        try {
            if (!Capsule::schema()->hasTable('tblcancelrequests')) {
                return false;
            }

            $columns = [];
            foreach (Capsule::schema()->getColumnListing('tblcancelrequests') as $column) {
                $columns[] = strtolower((string) $column);
            }

            $query = Capsule::table('tblcancelrequests');

            if (in_array('relid', $columns, true)) {
                $query->where('relid', (int) $serviceId);
            } elseif (in_array('serviceid', $columns, true)) {
                $query->where('serviceid', (int) $serviceId);
            } else {
                return false;
            }

            return (bool) $query->first();
        } catch (\Throwable $exception) {
            return false;
        }
    }

    public static function productWelcomeTemplate($productId)
    {
        $product = Capsule::table('tblproducts')->where('id', (int) $productId)->first();
        return $product ? trim((string) ($product->welcomeemail ?? '')) : '';
    }

    public static function sendLifecycleEmail($serviceId, $productId, $kind, array $customVars = [], $welcomeEmailName = '')
    {
        $addon = self::addonConfig();
        $templateMap = [
            'ready' => array_filter([
                trim((string) $welcomeEmailName),
                trim((string) ($addon['ready_email_template'] ?? '')),
                'Product/Service Welcome Email',
            ]),
            'hold' => array_filter([
                trim((string) ($addon['hold_email_template'] ?? '')),
                'Service Suspension Notification',
            ]),
            'completed' => array_filter([
                trim((string) ($addon['completed_email_template'] ?? '')),
                'Service Cancellation Request Confirmation',
            ]),
            'terminated' => array_filter([
                trim((string) ($addon['terminated_email_template'] ?? '')),
                'Service Cancellation Request Confirmation',
            ]),
        ];

        $candidates = array_values(array_unique($templateMap[$kind] ?? []));
        
        $payloadBase = [
            'id' => (int) $serviceId,
            'customtype' => 'product',
            'customvars' => $customVars,
        ];

        foreach ($candidates as $templateName) {
            $result = self::localApi('SendEmail', array_merge($payloadBase, ['messagename' => $templateName]));
            if (strtolower((string) ($result['result'] ?? '')) === 'success') {
                self::logEvent($serviceId, 'info', 'email', 'Lifecycle email sent.', ['kind' => $kind, 'template' => $templateName]);
                return true;
            }
        }

        self::logEvent($serviceId, 'warning', 'email', 'No lifecycle email template could be sent.', ['kind' => $kind, 'candidates' => $candidates]);
        return false;
    }

    public static function monitoredServiceRows()
    {
        return Capsule::table('mod_hetznerstoragebox_services')
            ->whereNotNull('storage_box_id')
            ->orderBy('service_id', 'asc')
            ->get();
    }

    public static function syncManagedServices(HetznerClient $client)
    {
        $summary = [];

        foreach (self::monitoredServiceRows() as $row) {
            try {
                $response = $client->get('/storage_boxes/' . (int) $row->storage_box_id);
                $box = (array) ($response['storage_box'] ?? []);
                if (empty($box)) {
                    throw new \RuntimeException('Hetzner returned an empty Storage Box response.');
                }

                self::saveServiceRecord((int) $row->service_id, [
                    'storage_box_id' => (int) ($box['id'] ?? $row->storage_box_id),
                    'username' => (string) ($box['username'] ?? ''),
                    'endpoint' => (string) ($box['server'] ?? ''),
                    'location_name' => (string) (($box['location']['name'] ?? '') ?: ''),
                    'box_type_name' => (string) (($box['storage_box_type']['name'] ?? '') ?: ''),
                    'status' => (string) ($box['status'] ?? 'active'),
                    'last_synced' => self::now(),
                    'meta_json' => ['box' => $box],
                ]);

                self::captureMetric((int) $row->service_id, (array) ($box['stats'] ?? []));
                self::updateServiceDetails((int) $row->service_id, $box);
                $summary[] = ['service_id' => (int) $row->service_id, 'status' => (string) ($box['status'] ?? 'active')];
            } catch (\Throwable $exception) {
                self::logEvent((int) $row->service_id, 'error', 'sync', 'Storage Box sync failed.', ['error' => $exception->getMessage()]);
                $summary[] = ['service_id' => (int) $row->service_id, 'error' => $exception->getMessage()];
            }
        }

        return $summary;
    }

    public static function syncCatalog(HetznerClient $client)
    {
        self::ensureSchema();

        $page = 1;
        $updated = 0;

        do {
            $response = $client->get('/storage_box_types', ['page' => $page, 'per_page' => 50]);
            $items = (array) ($response['storage_box_types'] ?? []);
            $meta = (array) (($response['meta'] ?? [])['pagination'] ?? []);

            foreach ($items as $item) {
                $type = (array) $item;
                $typeName = (string) ($type['name'] ?? '');
                if ($typeName === '') {
                    continue;
                }

                Capsule::table('mod_hetznerstoragebox_catalog')->updateOrInsert(
                    ['type_name' => $typeName],
                    [
                        'description_text' => (string) ($type['description'] ?? $typeName),
                        'size_bytes' => (int) ($type['size'] ?? 0),
                        'snapshot_limit' => isset($type['snapshot_limit']) ? (int) $type['snapshot_limit'] : null,
                        'automatic_snapshot_limit' => isset($type['automatic_snapshot_limit']) ? (int) $type['automatic_snapshot_limit'] : null,
                        'subaccounts_limit' => isset($type['subaccounts_limit']) ? (int) $type['subaccounts_limit'] : null,
                        'prices_json' => self::jsonEncode((array) ($type['prices'] ?? [])),
                        'raw_json' => self::jsonEncode($type),
                        'updated_at' => self::now(),
                    ]
                );

                $updated++;
            }

            $page = (int) ($meta['next_page'] ?? 0);
        } while ($page > 0);

        return ['updated' => $updated];
    }

    public static function getCatalogItems()
    {
        self::ensureSchema();
        return Capsule::table('mod_hetznerstoragebox_catalog')->orderBy('size_bytes', 'asc')->orderBy('type_name', 'asc')->get();
    }

    public static function getCatalogItemByType($typeName)
    {
        self::ensureSchema();
        return Capsule::table('mod_hetznerstoragebox_catalog')->where('type_name', (string) $typeName)->first();
    }

    public static function getWhmcsCurrencies()
    {
        return Capsule::table('tblcurrencies')->orderBy('default', 'desc')->orderBy('id', 'asc')->get();
    }

    public static function defaultCurrencyCode($currencies)
    {
        foreach ($currencies as $currency) {
            if ((int) ($currency->default ?? 0) === 1) {
                return strtoupper((string) $currency->code);
            }
        }

        return isset($currencies[0]) ? strtoupper((string) $currencies[0]->code) : 'USD';
    }

    public static function currencyRowsByCode($currencies)
    {
        $map = [];
        foreach ($currencies as $currency) {
            $map[strtoupper((string) $currency->code)] = $currency;
        }

        return $map;
    }

    public static function conversionRate($baseCurrencyCode, $targetCurrency, array $rowsByCode, $defaultCurrencyCode)
    {
        $baseCurrencyCode = strtoupper((string) $baseCurrencyCode);
        $targetCode = strtoupper((string) $targetCurrency->code);

        if ($baseCurrencyCode === $targetCode) {
            return 1.0;
        }

        $baseRate = 1.0;
        if ($baseCurrencyCode !== strtoupper((string) $defaultCurrencyCode) && isset($rowsByCode[$baseCurrencyCode])) {
            $baseRate = (float) $rowsByCode[$baseCurrencyCode]->rate;
        }

        $targetRate = 1.0;
        if ($targetCode !== strtoupper((string) $defaultCurrencyCode) && isset($rowsByCode[$targetCode])) {
            $targetRate = (float) $rowsByCode[$targetCode]->rate;
        }

        if ($baseRate <= 0 || $targetRate <= 0) {
            return 1.0;
        }

        return $targetRate / $baseRate;
    }

    public static function resolveCatalogPricingBase(array $config)
    {
        $typeName = (string) ($config['default_storage_box_type'] ?? '');
        $location = (string) ($config['default_location'] ?? '');
        $mode = strtolower((string) ($config['pricing']['base_price_mode'] ?? 'net'));
        $catalog = self::getCatalogItemByType($typeName);

        if (!$catalog) {
            throw new \RuntimeException('No synced Storage Box type was found for pricing: ' . $typeName);
        }

        $prices = self::jsonDecodeArray($catalog->prices_json);
        $selectedPrice = null;

        foreach ($prices as $price) {
            if (strtolower((string) ($price['location'] ?? '')) === strtolower($location)) {
                $selectedPrice = $price;
                break;
            }
        }

        if ($selectedPrice === null && !empty($prices)) {
            $selectedPrice = $prices[0];
        }

        if ($selectedPrice === null) {
            throw new \RuntimeException('No pricing is available for the synced Storage Box type.');
        }

        $addon = self::addonConfig();
        $sourceCurrency = strtoupper((string) ($addon['source_currency_code'] ?? 'EUR'));
        $monthlyKey = $mode === 'gross' ? 'gross' : 'net';
        $monthlyBase = (float) (($selectedPrice['price_monthly'][$monthlyKey] ?? 0));

        return [
            'type_name' => $typeName,
            'location' => (string) ($selectedPrice['location'] ?? $location),
            'base_currency' => $sourceCurrency,
            'monthly_base' => $monthlyBase,
        ];
    }

    public static function buildPricingPreview($productId, array $configOverride = [], array $params = [])
    {
        $config = self::loadProductConfig($productId, $params);
        if (!empty($configOverride)) {
            $config = self::recursiveMerge($config, $configOverride);
        }

        $base = self::resolveCatalogPricingBase($config);
        $currencies = self::getWhmcsCurrencies();
        $selectedPeriods = array_values(array_filter((array) ($config['pricing']['selected_periods'] ?? ['monthly'])));
        $selectedCurrencyIds = array_values(array_filter(array_map('intval', (array) ($config['pricing']['selected_currency_ids'] ?? []))));

        if (empty($selectedPeriods)) {
            $selectedPeriods = ['monthly'];
        }

        if (empty($selectedCurrencyIds) && isset($currencies[0])) {
            $selectedCurrencyIds = [(int) $currencies[0]->id];
        }

        $defaultCode = self::defaultCurrencyCode($currencies);
        $rowsByCode = self::currencyRowsByCode($currencies);
        $margin = (float) ($config['pricing']['margin_percent'] ?? 0);
        $previewRows = [];

        foreach ($currencies as $currency) {
            if (!in_array((int) $currency->id, $selectedCurrencyIds, true)) {
                continue;
            }

            $rate = self::conversionRate($base['base_currency'], $currency, $rowsByCode, $defaultCode);
            $row = [
                'currency_id' => (int) $currency->id,
                'currency_code' => strtoupper((string) $currency->code),
                'periods' => [],
            ];

            foreach ($selectedPeriods as $period) {
                $multiplier = PricingEngine::periodMap()[$period] ?? 1;
                $calculation = PricingEngine::calculatePeriodPrice(
                    $base['monthly_base'],
                    $margin,
                    $rate,
                    $row['currency_code'],
                    $multiplier
                );

                $row['periods'][$period] = PricingEngine::format($calculation['period_rounded'], $row['currency_code']);
            }

            $previewRows[] = $row;
        }

        return [
            'base' => $base,
            'rows' => $previewRows,
            'margin_percent' => $margin,
        ];
    }

    public static function pricingRowDefaults($productId, $currencyId)
    {
        return [
            'type' => 'product',
            'currency' => (int) $currencyId,
            'relid' => (int) $productId,
            'msetupfee' => '0.00',
            'qsetupfee' => '0.00',
            'ssetupfee' => '0.00',
            'asetupfee' => '0.00',
            'bsetupfee' => '0.00',
            'tsetupfee' => '0.00',
            'monthly' => '-1.00',
            'quarterly' => '-1.00',
            'semiannually' => '-1.00',
            'annually' => '-1.00',
            'biennially' => '-1.00',
            'triennially' => '-1.00',
        ];
    }

    public static function applyPricingNow($productId, array $configOverride = [], array $params = [])
    {
        $preview = self::buildPricingPreview($productId, $configOverride, $params);
        $changes = [];

        foreach ($preview['rows'] as $row) {
            $existing = Capsule::table('tblpricing')
                ->where('type', 'product')
                ->where('relid', (int) $productId)
                ->where('currency', (int) $row['currency_id'])
                ->first();

            $payload = self::pricingRowDefaults($productId, $row['currency_id']);
            if ($existing) {
                $payload = array_merge($payload, (array) $existing);
            }

            foreach ($row['periods'] as $period => $amount) {
                $payload[$period] = (string) $amount;
            }

            if ($existing) {
                Capsule::table('tblpricing')->where('id', (int) $existing->id)->update($payload);
            } else {
                Capsule::table('tblpricing')->insert($payload);
            }

            $changes[] = ['currency' => $row['currency_code'], 'periods' => $row['periods']];
        }

        return ['preview' => $preview, 'changes' => $changes];
    }

    public static function applyDailyPricing(HetznerClient $client)
    {
        // ADDED: Prune old logs and metrics to keep the WHMCS database fast
        try {
            $cutoffDate = date('Y-m-d H:i:s', strtotime('-60 days'));
            Capsule::table('mod_hetznerstoragebox_events')->where('created_at', '<', $cutoffDate)->delete();
            Capsule::table('mod_hetznerstoragebox_metrics')->where('captured_at', '<', $cutoffDate)->delete();
        } catch (\Throwable $e) {
            // Silently ignore pruning errors to not interrupt the cron
        }

        $summary = [];
        self::syncCatalog($client);

        foreach (Capsule::table('mod_hetznerstoragebox_product_configs')->get() as $row) {
            $config = self::loadProductConfig((int) $row->product_id);
            if (!self::boolValue($config['pricing']['apply_daily'] ?? false)) {
                continue;
            }

            try {
                $result = self::applyPricingNow((int) $row->product_id);
                $summary[] = ['product_id' => (int) $row->product_id, 'updated' => count($result['changes'])];
            } catch (\Throwable $exception) {
                $summary[] = ['product_id' => (int) $row->product_id, 'error' => $exception->getMessage()];
            }
        }

        return $summary;
    }

    public static function autoTerminateOverdueServices()
    {
        $rows = Capsule::table('tblhosting')
            ->join('tblproducts', 'tblproducts.id', '=', 'tblhosting.packageid')
            ->where('tblproducts.servertype', self::SERVER_MODULE)
            ->whereIn('tblhosting.domainstatus', ['Active', 'Suspended'])
            ->select('tblhosting.id as service_id', 'tblhosting.packageid as product_id')
            ->get();

        $summary = [];

        foreach ($rows as $row) {
            $config = self::loadProductConfig((int) $row->product_id);
            if (!self::boolValue($config['billing']['auto_terminate_enabled'] ?? true)) {
                continue;
            }

            $days = max(0, self::intValue($config['billing']['overdue_days'] ?? 3, 3));
            $cutoff = date('Y-m-d', strtotime('-' . $days . ' days'));

            $invoice = Capsule::table('tblinvoiceitems')
                ->join('tblinvoices', 'tblinvoices.id', '=', 'tblinvoiceitems.invoiceid')
                ->where('tblinvoiceitems.type', 'Hosting')
                ->where('tblinvoiceitems.relid', (int) $row->service_id)
                ->where('tblinvoices.status', 'Unpaid')
                ->where('tblinvoices.duedate', '<=', $cutoff)
                ->orderBy('tblinvoices.duedate', 'asc')
                ->select('tblinvoices.id as invoice_id', 'tblinvoices.duedate')
                ->first();

            if (!$invoice) {
                continue;
            }

            self::markTerminationReason((int) $row->service_id, 'overdue_unpaid', 'Invoice #' . (int) $invoice->invoice_id . ' overdue since ' . $invoice->duedate);
            $result = self::localApi('ModuleTerminate', ['serviceid' => (int) $row->service_id]);
            $summary[] = ['service_id' => (int) $row->service_id, 'result' => (string) ($result['result'] ?? 'unknown')];
        }

        return $summary;
    }

    public static function verifyClientOwnership($serviceId)
    {
        $uid = isset($_SESSION['uid']) ? (int) $_SESSION['uid'] : 0;
        if (!$uid) {
            return false;
        }

        return (bool) Capsule::table('tblhosting')->where('id', (int) $serviceId)->where('userid', $uid)->first();
    }
}