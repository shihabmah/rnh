<?php

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

require_once __DIR__ . '/lib/PricingEngine.php';
require_once __DIR__ . '/lib/HetznerClient.php';
require_once __DIR__ . '/lib/Common.php';

use HetznerStorageBox\Common;
use Illuminate\Database\Capsule\Manager as Capsule;

function hetznerstoragebox_MetaData()
{
    return [
        'DisplayName' => 'Hetzner Storage Box',
        'APIVersion' => '1.1',
        'RequiresServer' => true,
    ];
}

function hetznerstoragebox_ConfigOptions()
{
    Common::ensureSchema();

    return [
        'Default Location' => [
            'Type' => 'text',
            'Size' => '12',
            'Default' => 'fsn1',
            'Description' => 'Fallback location code, for example fsn1.',
        ],
        'Default Storage Box Type' => [
            'Type' => 'text',
            'Size' => '16',
            'Default' => 'bx11',
            'Description' => 'Fallback quota/type, for example bx11.',
        ],
        'Reachable Externally' => [
            'Type' => 'yesno',
            'Description' => 'Allow access from outside the host network.',
        ],
        'Enable SSH' => [
            'Type' => 'yesno',
            'Default' => true,
            'Description' => 'Provision the primary account with SSH access enabled.',
        ],
        'Enable SMB' => [
            'Type' => 'yesno',
            'Description' => 'Enable Samba/SMB access by default.',
        ],
        'Enable WebDAV' => [
            'Type' => 'yesno',
            'Description' => 'Enable WebDAV access by default.',
        ],
        'Expose ZFS Snapshots' => [
            'Type' => 'yesno',
            'Description' => 'Show the snapshot folder for the primary account.',
        ],
        'Enable Client Label Editor' => [
            'Type' => 'yesno',
            'Description' => 'Allow customers to update custom labels in the client area.',
        ],
        'Allow Client Password Reset' => [
            'Type' => 'yesno',
            'Description' => 'Show the password reset workflow in the client area.',
        ],
        'Overdue Grace Days' => [
            'Type' => 'text',
            'Size' => '5',
            'Default' => '3',
            'Description' => 'Terminate unpaid services after this many overdue days.',
        ],
        'Auto Apply Pricing Daily' => [
            'Type' => 'yesno',
            'Description' => 'Allow DailyCron to refresh pricing for this product.',
        ],
    ];
}

function hetznerstoragebox_TestConnection(array $params)
{
    try {
        $client = Common::getApiClient($params);
        $client->get('/storage_boxes', ['per_page' => 1]);

        return ['success' => true];
    } catch (\Throwable $exception) {
        return ['success' => false, 'error' => $exception->getMessage()];
    }
}

function hetznerstoragebox_AdminServicesTabFields(array $params)
{
    $record = Common::getServiceRecord((int) $params['serviceid']);
    if (!$record) {
        return ['Storage Box State' => 'No module record exists yet'];
    }

    $meta = Common::jsonDecodeArray($record->meta_json);
    $box = (array) ($meta['box'] ?? []);
    $provisioning = (array) ($meta['provisioning'] ?? []);
    $stats = (array) ($box['stats'] ?? []);
    $type = (array) ($box['storage_box_type'] ?? []);
    $termination = (array) ($meta['termination'] ?? []);
    $suspension = (array) ($meta['suspension'] ?? []);

    return [
        'Storage Box ID' => (string) ($record->storage_box_id ?: '--'),
        'Username' => (string) ($record->username ?: '--'),
        'Endpoint' => (string) ($record->endpoint ?: '--'),
        'Location' => (string) ($record->location_name ?: (($box['location']['name'] ?? '') ?: '--')),
        'Type' => (string) ($record->box_type_name ?: (($type['name'] ?? '') ?: '--')),
        'Status' => (string) ($record->status ?: '--'),
        'Access Method' => (string) (($provisioning['access_choice'] ?? '') ?: '--'),
        'Used Storage' => Common::humanBytes((int) ($stats['size'] ?? 0)),
        'Quota' => Common::humanBytes((int) ($type['size'] ?? 0)),
        'Hold Snapshot' => !empty($suspension['previous_access_settings']) ? 'Captured' : 'None',
        'Last Action' => (string) ($record->last_action_command ?: '--'),
        'Termination Marker' => (string) (($termination['kind'] ?? '') ?: '--'),
        'Last Synced' => (string) ($record->last_synced ?: '--'),
    ];
}

function hetznerstoragebox_CreateAccount(array $params)
{
    try {
        Common::ensureSchema();

        $record = Common::getServiceRecord((int) $params['serviceid']);
        if ($record && !empty($record->storage_box_id)) {
            hetznerstoragebox_syncStorageBox($params, (int) $record->storage_box_id);
            return 'success';
        }

        $config = hetznerstoragebox_resolveProductConfig($params);
        $spec = Common::resolveOrderSpec($params, $config);
        
        $spec['name'] = 'rnh-cloud-storage-' . mt_rand(10000, 99999);
        
        $client = Common::getApiClient($params);

        $payload = [
            'name' => $spec['name'],
            'location' => $spec['location'],
            'storage_box_type' => $spec['storage_box_type'],
            'password' => $spec['password'],
            'labels' => $spec['labels'],
            'access_settings' => $spec['access_settings'],
        ];

        if (!empty($spec['ssh_keys'])) {
            $payload['ssh_keys'] = $spec['ssh_keys'];
        }

        $response = $client->post('/storage_boxes', $payload);
        $box = (array) ($response['storage_box'] ?? []);
        $action = (array) ($response['action'] ?? []);
        $storageBoxId = (int) ($box['id'] ?? 0);

        if ($storageBoxId <= 0) {
            throw new \RuntimeException('Storage Provider did not return a valid identifier.');
        }

        Common::saveServiceRecord((int) $params['serviceid'], [
            'product_id' => (int) $params['pid'],
            'storage_box_id' => $storageBoxId,
            'status' => (string) ($box['status'] ?? 'initializing'),
            'last_action_id' => isset($action['id']) ? (int) $action['id'] : null,
            'last_action_command' => (string) ($action['command'] ?? ''),
            'meta_json' => [
                'provisioning' => [
                    'name' => $spec['name'],
                    'requested_location' => $spec['location'],
                    'requested_type' => $spec['storage_box_type'],
                    'access_choice' => $spec['access_choice'],
                    'password_disclosed' => $spec['password_disclosed'],
                    'ssh_key_count' => count($spec['ssh_keys']),
                ],
            ],
        ]);

        hetznerstoragebox_waitForAction($client, $action, $storageBoxId);
        
        $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId);
        $retries = 8;
        while ((empty($box['username']) || empty($box['server'])) && $retries > 0) {
            sleep(3);
            $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId);
            $retries--;
        }

        $accessChoice = (string) ($spec['access_choice'] ?? 'password');

        $coreUpdate = [
            'domain' => (string) ($box['server'] ?? ''),
            'username' => (string) ($box['username'] ?? '')
        ];
        if (!empty($spec['password_disclosed'])) {
            $coreUpdate['password'] = encrypt($spec['password']);
        }
        Capsule::table('tblhosting')->where('id', (int) $params['serviceid'])->update($coreUpdate);

        Common::updateKnownCustomFields((int) $params['pid'], (int) $params['serviceid'], [
            'Storage Box ID' => (string) $storageBoxId,
            'Storage Box Username' => (string) ($box['username'] ?? ''),
            'Storage Box Endpoint' => (string) ($box['server'] ?? ''),
            'Storage Box Type' => (string) (($box['storage_box_type']['name'] ?? '') ?: $spec['storage_box_type']),
            'Storage Box Location' => (string) (($box['location']['name'] ?? '') ?: $spec['location']),
            'Storage Box Access Method' => $accessChoice,
        ]);

        hetznerstoragebox_SendCustomEmail((int) $params['serviceid'], 'Storage Box Welcome Email');

        Common::logEvent((int) $params['serviceid'], 'info', 'provision', 'Storage Box provisioned successfully.', [
            'storage_box_id' => $storageBoxId,
            'type' => $spec['storage_box_type'],
            'location' => $spec['location'],
            'access_choice' => $accessChoice,
        ]);

        return 'success';
    } catch (\Throwable $exception) {
        Common::logEvent((int) ($params['serviceid'] ?? 0), 'error', 'provision', 'Provisioning failed.', [
            'error' => $exception->getMessage(),
        ]);

        return 'Create failed: ' . $exception->getMessage();
    }
}

function hetznerstoragebox_SuspendAccount(array $params)
{
    try {
        $storageBoxId = hetznerstoragebox_resolveStorageBoxId((int) $params['serviceid']);
        if ($storageBoxId <= 0) {
            return 'success';
        }

        $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
        $currentAccess = (array) ($box['access_settings'] ?? []);
        $client = Common::getApiClient($params);
        $response = $client->post('/storage_boxes/' . $storageBoxId . '/actions/update_access_settings', [
            'reachable_externally' => false,
            'samba_enabled' => false,
            'ssh_enabled' => false,
            'webdav_enabled' => false,
            'zfs_enabled' => false,
        ]);

        hetznerstoragebox_waitForAction($client, (array) ($response['action'] ?? []), $storageBoxId);

        Common::saveServiceRecord((int) $params['serviceid'], [
            'status' => 'hold',
            'meta_json' => [
                'suspension' => [
                    'active' => true,
                    'previous_access_settings' => $currentAccess,
                    'suspended_at' => Common::now(),
                ],
            ],
        ]);

        $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId);
        Common::saveServiceRecord((int) $params['serviceid'], [
            'status' => 'hold',
            'meta_json' => [
                'suspension' => [
                    'active' => true,
                    'previous_access_settings' => $currentAccess,
                    'suspended_at' => Common::now(),
                ],
            ],
        ]);

        Common::sendLifecycleEmail(
            (int) $params['serviceid'],
            (int) $params['pid'],
            'hold',
            hetznerstoragebox_lifecycleVars($params, $box, [
                'hold_reason' => 'Service suspended in WHMCS',
                'hold_active' => 'yes',
            ])
        );

        Common::logEvent((int) $params['serviceid'], 'warning', 'hold', 'Storage Box placed on hold by disabling primary access.', [
            'storage_box_id' => $storageBoxId,
        ]);

        return 'success';
    } catch (\Throwable $exception) {
        Common::logEvent((int) ($params['serviceid'] ?? 0), 'error', 'hold', 'Failed to place Storage Box on hold.', [
            'error' => $exception->getMessage(),
        ]);

        return 'Suspend failed: ' . $exception->getMessage();
    }
}

function hetznerstoragebox_UnsuspendAccount(array $params)
{
    try {
        $storageBoxId = hetznerstoragebox_resolveStorageBoxId((int) $params['serviceid']);
        if ($storageBoxId <= 0) {
            return 'success';
        }

        $config = hetznerstoragebox_resolveProductConfig($params);
        $record = Common::getServiceRecord((int) $params['serviceid']);
        $meta = $record ? Common::jsonDecodeArray($record->meta_json) : [];
        $previous = (array) (($meta['suspension']['previous_access_settings'] ?? []) ?: []);
        $restore = !empty($previous) ? $previous : [
            'reachable_externally' => Common::boolValue($config['default_access']['reachable_externally'] ?? true),
            'samba_enabled' => Common::boolValue($config['default_access']['samba_enabled'] ?? false),
            'ssh_enabled' => Common::boolValue($config['default_access']['ssh_enabled'] ?? true),
            'webdav_enabled' => Common::boolValue($config['default_access']['webdav_enabled'] ?? false),
            'zfs_enabled' => Common::boolValue($config['default_access']['zfs_enabled'] ?? false),
        ];

        $client = Common::getApiClient($params);
        $response = $client->post('/storage_boxes/' . $storageBoxId . '/actions/update_access_settings', $restore);
        hetznerstoragebox_waitForAction($client, (array) ($response['action'] ?? []), $storageBoxId);

        Common::saveServiceRecord((int) $params['serviceid'], [
            'status' => 'active',
            'meta_json' => [
                'suspension' => [
                    'active' => false,
                    'previous_access_settings' => $restore,
                    'released_at' => Common::now(),
                ],
            ],
        ]);

        hetznerstoragebox_syncStorageBox($params, $storageBoxId);
        Common::logEvent((int) $params['serviceid'], 'info', 'hold', 'Storage Box hold released and access settings restored.', [
            'storage_box_id' => $storageBoxId,
        ]);

        return 'success';
    } catch (\Throwable $exception) {
        Common::logEvent((int) ($params['serviceid'] ?? 0), 'error', 'hold', 'Failed to release Storage Box hold.', [
            'error' => $exception->getMessage(),
        ]);

        return 'Unsuspend failed: ' . $exception->getMessage();
    }
}

function hetznerstoragebox_TerminateAccount(array $params)
{
    try {
        $serviceId = (int) $params['serviceid'];
        $record = Common::getServiceRecord($serviceId);
        $storageBoxId = hetznerstoragebox_resolveStorageBoxId($serviceId);
        $kind = Common::classifyTerminationOutcome($serviceId);
        $box = $record ? hetznerstoragebox_lastKnownBox($record) : [];
        $action = [];

        if ($storageBoxId > 0) {
            try {
                $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
            } catch (\Throwable $exception) {
            }

            try {
                $client = Common::getApiClient($params);
                $response = $client->delete('/storage_boxes/' . $storageBoxId);
                $action = (array) ($response['action'] ?? []);
                hetznerstoragebox_waitForAction($client, $action, $storageBoxId);
            } catch (\Throwable $e) {
                if (stripos($e->getMessage(), 'not found') === false && strpos($e->getMessage(), '404') === false) {
                    throw $e;
                }
            }
        }

        Common::updateKnownCustomFields((int) $params['pid'], $serviceId, [
            'Storage Box ID' => '',
            'Storage Box Username' => '',
            'Storage Box Endpoint' => '',
            'Storage Box Type' => '',
            'Storage Box Location' => '',
            'Storage Box Access Method' => '',
        ]);

        Common::saveServiceRecord($serviceId, [
            'storage_box_id' => null,
            'username' => null,
            'endpoint' => null,
            'status' => 'deleted',
            'last_action_id' => isset($action['id']) ? (int) $action['id'] : null,
            'last_action_command' => (string) ($action['command'] ?? 'delete'),
            'last_synced' => Common::now(),
            'meta_json' => [
                'termination' => [
                    'kind' => $kind,
                    'deleted_at' => Common::now(),
                    'storage_box_id' => $storageBoxId,
                ],
                'box' => $box,
            ],
        ]);

        Common::sendLifecycleEmail($serviceId, (int) $params['pid'], $kind, []);

        Common::logEvent($serviceId, 'info', 'terminate', 'Storage Box termination completed.', [
            'storage_box_id' => $storageBoxId,
            'email_kind' => $kind,
        ]);

        Common::clearTerminationReason($serviceId);

        return 'success';
    } catch (\Throwable $exception) {
        Common::logEvent((int) ($params['serviceid'] ?? 0), 'error', 'terminate', 'Storage Box termination failed.', [
            'error' => $exception->getMessage(),
        ]);

        return 'Terminate failed: ' . $exception->getMessage();
    }
}

function hetznerstoragebox_ChangePassword(array $params)
{
    try {
        $storageBoxId = hetznerstoragebox_resolveStorageBoxId((int) $params['serviceid']);
        if ($storageBoxId <= 0) {
            throw new \RuntimeException('No Storage Box is attached to this service yet.');
        }

        $password = Common::generateStrongPassword();
        $client = Common::getApiClient($params);
        $response = $client->post('/storage_boxes/' . $storageBoxId . '/actions/reset_password', [
            'password' => $password,
        ]);

        hetznerstoragebox_waitForAction($client, (array) ($response['action'] ?? []), $storageBoxId);
        $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId);

        Capsule::table('tblhosting')->where('id', (int) $params['serviceid'])->update([
            'password' => encrypt($password)
        ]);

        Common::localApi('UpdateClientProduct', [
            'serviceid' => (int) $params['serviceid'],
            'servicepassword' => $password,
        ]);


        Common::logEvent((int) $params['serviceid'], 'info', 'password', 'Storage Box password rotated by admin.', [
            'storage_box_id' => $storageBoxId,
        ]);

        return 'success';
    } catch (\Throwable $exception) {
        return 'Password reset failed: ' . $exception->getMessage();
    }
}

function hetznerstoragebox_isAutomaticSnapshot(array $snapshot)
{
    foreach (['type', 'snapshot_type', 'kind', 'source', 'created_by', 'origin'] as $key) {
        $value = strtolower(trim((string) ($snapshot[$key] ?? '')));

        if ($value === '') {
            continue;
        }

        if (
            strpos($value, 'auto') !== false ||
            strpos($value, 'schedule') !== false ||
            strpos($value, 'plan') !== false
        ) {
            return true;
        }

        if (strpos($value, 'manual') !== false) {
            return false;
        }
    }

    foreach (['automatic', 'is_automatic', 'auto', 'from_snapshot_plan'] as $key) {
        if (array_key_exists($key, $snapshot)) {
            return Common::boolValue($snapshot[$key]);
        }
    }

    $description = trim((string) (($snapshot['description'] ?? '') ?: ($snapshot['name'] ?? '')));

    /*
     * Manual snapshots created by this module always have a description.
     * Hetzner automatic snapshots can be returned without one.
     */
    return $description === '';
}

function hetznerstoragebox_prepareSnapshotsForTemplate(array $snapshots)
{
    $prepared = [];

    foreach ($snapshots as $snapshot) {
        $snapshot = (array) $snapshot;

        $isAutomatic = hetznerstoragebox_isAutomaticSnapshot($snapshot);

        $snapshot['is_automatic'] = $isAutomatic;
        $snapshot['type'] = $isAutomatic ? 'Automatic' : 'Manual';
        $snapshot['type_label'] = $isAutomatic ? 'Automatic' : 'Manual';

        if (trim((string) (($snapshot['description'] ?? '') ?: ($snapshot['name'] ?? ''))) === '') {
            $snapshot['description'] = $isAutomatic ? 'Automatic snapshot' : 'Manual snapshot';
        }

        $prepared[] = $snapshot;
    }

    return $prepared;
}

function hetznerstoragebox_countAutomaticSnapshots(array $snapshots)
{
    $count = 0;

    foreach ($snapshots as $snapshot) {
        if (hetznerstoragebox_isAutomaticSnapshot((array) $snapshot)) {
            $count++;
        }
    }

    return $count;
}

function hetznerstoragebox_ClientArea(array $params)
{
    $serviceId = (int) $params['serviceid'];

    $vars = [
        'errorMessage' => '',
        'successMessage' => '',
        'serviceId' => $serviceId,
        'systemUrl' => (string) ($params['systemurl'] ?? ''),
        'rzCustomToken' => hetznerstoragebox_clientToken($serviceId),
        'box' => [],
        'accessChoice' => 'password',
        'labelEditorEnabled' => false,
        'allowPasswordReset' => false,
        'labelsText' => '',
        'visibleLabels' => [],
        'recentEvents' => [],
        'recentMetrics' => [],
        'snapshots' => [],
        'subaccounts' => [],
        'storageDirectories' => [],
        'storageDirectoriesJson' => '[]',
        'usagePercent' => 0,
        'quotaDisplay' => '0 B',
        'usedDisplay' => '0 B',
        'dataDisplay' => '0 B',
        'snapshotDisplay' => '0 B',
        'snapshotBaseName' => '',
        'snapshotSuggestedDescription' => '',
        'snapshotMaxAmount' => 10,
        'autoSnapshotFrequency' => 'daily',
        'autoSnapshotMaxAmount' => 10,
        'autoSnapshotCurrentAmount' => 0,
        'autoSnapshotEnabled' => false,
        'autoSnapshotHour' => '00',
        'autoSnapshotMinute' => '00',
        'autoSnapshotDayOfWeek' => 1,
        'autoSnapshotDayOfMonth' => 1,
        'lastSynced' => '',
        'serverStatus' => 'unknown',
        'storageUsername' => '',
        'storageEndpoint' => '',
        'storageType' => '',
        'storageLocation' => '',
        'accessSettings' => [
            'reachable_externally' => false,
            'ssh_enabled' => false,
            'samba_enabled' => false,
            'webdav_enabled' => false,
            'zfs_enabled' => false,
        ],
        'connectionHost' => '',
        'sftpUri' => '',
        'webdavUri' => '',
        'smbTarget' => '',
    ];

    try {
        if (!Common::verifyClientOwnership($serviceId)) {
            throw new \RuntimeException('You are not authorized to access this Storage Box service.');
        }

        $config = hetznerstoragebox_resolveProductConfig($params);
        $vars['labelEditorEnabled'] = Common::boolValue($config['client_features']['label_editor'] ?? true);
        $vars['allowPasswordReset'] = Common::boolValue($config['client_features']['password_reset'] ?? true);

        if (!empty($_REQUEST['customAction'])) {
            $result = hetznerstoragebox_handleClientAction($params, $config);

            if (($result['mode'] ?? '') === 'json') {
                header('Content-Type: application/json');
                echo json_encode($result['payload']);
                exit;
            }

            if (!empty($result['success'])) {
                $vars['successMessage'] = $result['success'];
            }

            if (!empty($result['error'])) {
                $vars['errorMessage'] = $result['error'];
            }
        }

        $record = Common::getServiceRecord($serviceId);

        if (!$record || empty($record->storage_box_id)) {
            $vars['errorMessage'] = $vars['errorMessage'] ?: 'This service has not been provisioned yet.';
            return ['templatefile' => 'templates/clientarea', 'vars' => $vars];
        }

        /*
         * Performance fix:
         * Do not recursively fetch folders on normal page load.
         * Folders are fetched only when the directory picker calls list_storage_box_folders.
         */
        $isSilentSync = !empty($_GET['_hd_sync']);
        $box = hetznerstoragebox_syncStorageBox($params, (int) $record->storage_box_id, false);
        $record = Common::getServiceRecord($serviceId) ?: $record;

        $client = Common::getApiClient($params);

        try {
            $snapResponse = $client->get('/storage_boxes/' . $record->storage_box_id . '/snapshots');
            $vars['snapshots'] = hetznerstoragebox_prepareSnapshotsForTemplate((array) ($snapResponse['snapshots'] ?? []));
            $vars['autoSnapshotCurrentAmount'] = hetznerstoragebox_countAutomaticSnapshots((array) $vars['snapshots']);
        } catch (\Throwable $e) {
            $vars['snapshots'] = [];
            $vars['autoSnapshotCurrentAmount'] = 0;
        }

        try {
            $subResponse = $client->get('/storage_boxes/' . $record->storage_box_id . '/subaccounts');
            $vars['subaccounts'] = (array) ($subResponse['subaccounts'] ?? []);
        } catch (\Throwable $e) {
            $vars['subaccounts'] = [];
        }

        /*
         * Fast fallback only.
         * Do not call hetznerstoragebox_fetchStorageBoxFoldersRecursive() here.
         */
        $vars['storageDirectories'] = hetznerstoragebox_directoryPathsFromSubaccounts((array) $vars['subaccounts']);

        $vars = array_merge($vars, hetznerstoragebox_templateState($serviceId, $record, $box, $config));

        $vars['snapshots'] = hetznerstoragebox_prepareSnapshotsForTemplate((array) $vars['snapshots']);
        $vars['autoSnapshotCurrentAmount'] = hetznerstoragebox_countAutomaticSnapshots((array) $vars['snapshots']);
        $vars['storageDirectoriesJson'] = json_encode(array_values((array) $vars['storageDirectories']));
        $vars['snapshotSuggestedDescription'] = hetznerstoragebox_suggestManualSnapshotDescription($box, (array) $vars['snapshots']);
    } catch (\Throwable $exception) {
        $vars['errorMessage'] = $exception->getMessage();
    }

    return ['templatefile' => 'templates/clientarea', 'vars' => $vars];
}

function hetznerstoragebox_handleClientAction(array $params, array $config)
{
    $serviceId = (int) $params['serviceid'];
    $action = trim((string) ($_REQUEST['customAction'] ?? ''));
    $token = (string) ($_REQUEST['rz_token'] ?? '');

    if (!hetznerstoragebox_verifyClientToken($serviceId, $token)) {
        return [
            'mode' => 'json',
            'payload' => ['status' => 'error', 'error' => 'Invalid session token. Please refresh the page and try again.'],
        ];
    }

    try {
        $storageBoxId = hetznerstoragebox_resolveStorageBoxId($serviceId);
        if ($storageBoxId <= 0) {
            throw new \RuntimeException('This service does not have a Cloud Storage instance attached yet.');
        }

        switch ($action) {
            case 'status_poll':
                $record = Common::getServiceRecord($serviceId);
                $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId);
                $state = hetznerstoragebox_templateState($serviceId, $record ?: Common::getServiceRecord($serviceId), $box, $config);

                return [
                    'mode' => 'json',
                    'payload' => [
                        'status' => 'success',
                        'serverStatus' => $state['serverStatus'],
                        'usedDisplay' => $state['usedDisplay'],
                        'quotaDisplay' => $state['quotaDisplay'],
                        'dataDisplay' => $state['dataDisplay'],
                        'snapshotDisplay' => $state['snapshotDisplay'],
                        'usagePercent' => $state['usagePercent'],
                        'lastSynced' => $state['lastSynced'],
                        'storageUsername' => $state['storageUsername'],
                        'storageEndpoint' => $state['storageEndpoint'],
                        'storageType' => $state['storageType'],
                        'storageLocation' => $state['storageLocation'],
                        'accessSettings' => $state['accessSettings'],
                    ],
                ];

            case 'update_labels':
                if (!Common::boolValue($config['client_features']['label_editor'] ?? true)) {
                    throw new \RuntimeException('Label editing is disabled for this product.');
                }
                $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                $labels = Common::parseLabels((string) ($_POST['labels'] ?? ''));
                $labels['whmcs_service_id'] = (string) $serviceId;
                $labels['whmcs_product_id'] = (string) (int) $params['pid'];
                $labels['internal_id'] = 'hd-storagebox-' . $serviceId;
                Common::validateLabels($labels);

                $client = Common::getApiClient($params);
                $response = $client->put('/storage_boxes/' . $storageBoxId, [
                    'name' => (string) ($box['name'] ?? Common::safeStorageBoxName($params)),
                    'labels' => $labels,
                ]);

                $updatedBox = (array) ($response['storage_box'] ?? []);
                if (!empty($updatedBox)) {
                    Common::saveServiceRecord($serviceId, ['meta_json' => ['box' => $updatedBox]]);
                }

                return [
                    'mode' => 'json',
                    'payload' => ['status' => 'success', 'message' => 'Labels updated successfully.', 'labelsText' => Common::formatLabels($labels)],
                ];

            case 'save_settings':
                $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                $currentAccess = (array) ($box['access_settings'] ?? []);
                
                $accessSettings = [
                    'samba_enabled' => Common::boolValue($_POST['samba_enabled'] ?? false),
                    'webdav_enabled' => Common::boolValue($_POST['webdav_enabled'] ?? false),
                    'ssh_enabled' => Common::boolValue($_POST['ssh_enabled'] ?? false),
                    'reachable_externally' => Common::boolValue($_POST['reachable_externally'] ?? false),
                    'zfs_enabled' => Common::boolValue($currentAccess['zfs_enabled'] ?? false),
                ];

                $client = Common::getApiClient($params);
                $client->post('/storage_boxes/' . $storageBoxId . '/actions/update_access_settings', $accessSettings);
                
                $retries = 15; 
                $isApplied = false;
                
                while ($retries > 0 && !$isApplied) {
                    sleep(3);
                    try {
                        $checkResponse = $client->get('/storage_boxes/' . $storageBoxId);
                        $checkAccess = (array) ($checkResponse['storage_box']['access_settings'] ?? []);
                        
                        if (
                            Common::boolValue($checkAccess['samba_enabled'] ?? false) === $accessSettings['samba_enabled'] &&
                            Common::boolValue($checkAccess['ssh_enabled'] ?? false) === $accessSettings['ssh_enabled'] &&
                            Common::boolValue($checkAccess['reachable_externally'] ?? false) === $accessSettings['reachable_externally'] &&
                            Common::boolValue($checkAccess['webdav_enabled'] ?? false) === $accessSettings['webdav_enabled']
                        ) {
                            $isApplied = true;
                        }
                    } catch (\Throwable $e) {}
                    $retries--;
                }

                if (!$isApplied) {
                    throw new \RuntimeException('The storage provider is taking too long to apply the setting. Please check back in a few minutes.');
                }

                hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                
                return [
                    'mode' => 'json',
                    'payload' => ['status' => 'success', 'message' => 'Access settings updated successfully.']
                ];

            case 'toggle_zfs':
                $enable = Common::boolValue($_POST['zfs_enabled'] ?? false);
                $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                $currentAccess = (array) ($box['access_settings'] ?? []);
                $currentAccess['zfs_enabled'] = $enable;

                $client = Common::getApiClient($params);
                $response = $client->post('/storage_boxes/' . $storageBoxId . '/actions/update_access_settings', $currentAccess);
                if (!empty($response['action'])) {
                    hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                }
                
                $retries = 15;
                $isApplied = false;
                
                while ($retries > 0 && !$isApplied) {
                    sleep(3); 
                    try {
                        $checkResponse = $client->get('/storage_boxes/' . $storageBoxId);
                        $checkAccess = (array) ($checkResponse['storage_box']['access_settings'] ?? []);
                        
                        if (Common::boolValue($checkAccess['zfs_enabled'] ?? false) === $enable) {
                            $isApplied = true;
                        }
                    } catch (\Throwable $e) {}
                    $retries--;
                }

                if (!$isApplied) {
                    throw new \RuntimeException('The storage provider is taking too long to apply the setting. Please check back in a few minutes.');
                }

                $syncedBox = hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                $syncedAccess = (array) ($syncedBox['access_settings'] ?? []);
                
                return [
                    'mode' => 'json',
                    'payload' => [
                        'status' => 'success',
                        'message' => 'Snapshot directory visibility updated successfully.',
                        'zfs_enabled' => Common::boolValue($syncedAccess['zfs_enabled'] ?? $enable),
                    ],
                ];

            case 'custom_reset_password':
                if (!Common::boolValue($config['client_features']['password_reset'] ?? true)) {
                    throw new \RuntimeException('Password reset is disabled for this product.');
                }

                $newPassword = trim((string) ($_POST['new_password'] ?? ''));
                if ($newPassword === '') {
                    $newPassword = Common::generateStrongPassword();
                } else {
                    if (strlen($newPassword) < 8 || strlen($newPassword) > 32) {
                        throw new \RuntimeException('Password must be between 8 and 32 characters long.');
                    }
                    if (!preg_match('/[A-Z]/', $newPassword) || !preg_match('/[a-z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
                        throw new \RuntimeException('Password must contain at least one uppercase, one lowercase, and one number.');
                    }
                }

                $client = Common::getApiClient($params);
                $response = $client->post('/storage_boxes/' . $storageBoxId . '/actions/reset_password', [
                    'password' => $newPassword,
                ]);

                hetznerstoragebox_waitForAction($client, (array) ($response['action'] ?? []), $storageBoxId);
                $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId);

                Capsule::table('tblhosting')->where('id', $serviceId)->update([
                    'password' => encrypt($newPassword)
                ]);

                Common::localApi('UpdateClientProduct', [
                    'serviceid' => $serviceId,
                    'servicepassword' => $newPassword,
                ]);


                return [
                    'mode' => 'json',
                    'payload' => [
                        'status' => 'success',
                        'message' => 'Password updated successfully in the Cloud Storage. No email was sent because the customer set the password in the client area.',
                    ],
                ];

            case 'create_snapshot':
                $desc = trim((string) ($_POST['description'] ?? ''));
                if ($desc === '') throw new \RuntimeException('Snapshot description is required.');
                $client = Common::getApiClient($params);
                
                try {
                    $response = $client->post('/storage_boxes/' . $storageBoxId . '/snapshots', ['description' => $desc]);
                    
                    if (!empty($response['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                    } else {
                        sleep(3);
                    }
                    
                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, true);
                    return ['mode' => 'json', 'payload' => ['status' => 'success', 'message' => 'Snapshot created successfully.']];
                } catch (\Throwable $e) {
                    throw new \RuntimeException('We could not complete this request right now. Please refresh the page and try again.');
                }

            case 'delete_snapshot':
                $snapId = (string) ($_POST['snapshot_id'] ?? '');
                if ($snapId === '') throw new \RuntimeException('Snapshot ID is required.');
                
                $client = Common::getApiClient($params);
                
                try {
                    $response = $client->delete('/storage_boxes/' . $storageBoxId . '/snapshots/' . $snapId);
                    
                    if (!empty($response['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                    } else {
                        sleep(3);
                    }
                    
                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, true);
                    return ['mode' => 'json', 'payload' => ['status' => 'success', 'message' => 'Snapshot deleted permanently.']];
                } catch (\Throwable $e) {
                    throw new \RuntimeException('We could not complete this request right now. Please refresh the page and try again.');
                }

            case 'restore_snapshot':
                $snapId = (string) ($_POST['snapshot_id'] ?? '');
                if ($snapId === '') throw new \RuntimeException('Snapshot ID is required.');
                
                $client = Common::getApiClient($params);
                
                try {
                    $response = $client->post('/storage_boxes/' . $storageBoxId . '/actions/rollback_snapshot', [
                        'snapshot' => $snapId
                    ]);
                    
                    if (!empty($response['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                    } else {
                        sleep(5); 
                    }
                    
                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, true);
                    
                    return [
                        'mode' => 'json', 
                        'payload' => [
                            'status' => 'success', 
                            'message' => 'Storage box reverted to snapshot.'
                        ]
                    ];
                } catch (\Throwable $e) {
                    throw new \RuntimeException('We could not complete this request right now. Please refresh the page and try again.');
                }
                
            case 'enable_auto_snapshot':
                $client = Common::getApiClient($params);

                try {
                    $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                    $type = (array) ($box['storage_box_type'] ?? []);
                    $typeName = (string) (($type['name'] ?? '') ?: ($config['default_storage_box_type'] ?? 'bx11'));
                    $maxAllowed = hetznerstoragebox_snapshotMaxAmountForType($typeName, $type);

                    $limit = (int) ($_POST['max_amount'] ?? $maxAllowed);
                    if ($limit < 1 || $limit > $maxAllowed) {
                        throw new \RuntimeException('Max Amount must be between 1 and ' . $maxAllowed . ' for ' . strtoupper($typeName) . '.');
                    }

                    $hourStr = trim((string)($_POST['hour'] ?? ''));
                    $minuteStr = trim((string)($_POST['minute'] ?? ''));

                    if ($hourStr === '' || $minuteStr === '') {
                        throw new \RuntimeException('Execution time (hour and minute) is required to schedule automatic snapshots.');
                    }

                    if (!preg_match('/^(?:[01]?\d|2[0-3])$/', $hourStr) || !preg_match('/^[0-5]?\d$/', $minuteStr)) {
                        throw new \RuntimeException('Execution time must be a valid hour (00-23) and minute (00-59).');
                    }

                    $hour = (int) $hourStr;
                    $minute = (int) $minuteStr;

                    $interval = trim((string) ($_POST['interval'] ?? 'daily'));
                    if (!in_array($interval, ['daily', 'weekly', 'monthly'], true)) {
                        throw new \RuntimeException('Frequency must be Daily, Weekly, or Monthly.');
                    }

                    // Hetzner requires the snapshot plan fields directly on the enable_snapshot_plan action payload.
                    // day_of_week starts at 1 for Monday and ends at 7 for Sunday. Null means every day.
                    // day_of_month starts at 1. Null means every day of the month.
                    $snapshotPlan = [
                        'max_snapshots' => $limit,
                        'hour' => $hour,
                        'minute' => $minute,
                        'day_of_week' => null,
                        'day_of_month' => null,
                    ];

                    if ($interval === 'weekly') {
                        $dayOfWeek = (int) ($_POST['day_of_week'] ?? 1);
                        if ($dayOfWeek < 1 || $dayOfWeek > 7) {
                            throw new \RuntimeException('Day of week must be between Monday and Sunday.');
                        }
                        $snapshotPlan['day_of_week'] = $dayOfWeek;
                    } elseif ($interval === 'monthly') {
                        $dayOfMonth = (int) ($_POST['day_of_month'] ?? 1);
                        if ($dayOfMonth < 1 || $dayOfMonth > 31) {
                            throw new \RuntimeException('Day of month must be between 1 and 31.');
                        }
                        $snapshotPlan['day_of_month'] = $dayOfMonth;
                    }

                    $response = $client->post('/storage_boxes/' . $storageBoxId . '/actions/enable_snapshot_plan', $snapshotPlan);
                    if (!empty($response['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                    }

                    $verified = false;
                    for ($attempt = 0; $attempt < 12; $attempt++) {
                        if ($attempt > 0) {
                            sleep(2);
                        }

                        $checkResponse = $client->get('/storage_boxes/' . $storageBoxId);
                        $lastPlan = (array) ($checkResponse['storage_box']['snapshot_plan'] ?? []);

                        $actualDayOfWeek = array_key_exists('day_of_week', $lastPlan) ? $lastPlan['day_of_week'] : null;
                        $actualDayOfMonth = array_key_exists('day_of_month', $lastPlan) ? $lastPlan['day_of_month'] : null;

                        if (
                            !empty($lastPlan) &&
                            (int) ($lastPlan['max_snapshots'] ?? 0) === $limit &&
                            (int) ($lastPlan['hour'] ?? -1) === $hour &&
                            (int) ($lastPlan['minute'] ?? -1) === $minute &&
                            (($actualDayOfWeek === null && $snapshotPlan['day_of_week'] === null) || (int) $actualDayOfWeek === (int) $snapshotPlan['day_of_week']) &&
                            (($actualDayOfMonth === null && $snapshotPlan['day_of_month'] === null) || (int) $actualDayOfMonth === (int) $snapshotPlan['day_of_month'])
                        ) {
                            $verified = true;
                            break;
                        }
                    }

                    if (!$verified) {
                        throw new \RuntimeException('Cloud Storage did not confirm that automatic snapshots are active yet. Please try again in a few minutes.');
                    }

                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                    return [
                        'mode' => 'json',
                        'payload' => [
                            'status' => 'success',
                            'message' => 'Auto snapshot policy updated successfully. Please refresh the page.',
                            'auto_snapshot_enabled' => true,
                        ],
                    ];
                } catch (\Throwable $e) {
                    throw new \RuntimeException('We could not complete this request right now. Please refresh the page and try again.');
                }

            case 'disable_auto_snapshot':
                $client = Common::getApiClient($params);

                try {
                    $response = $client->post('/storage_boxes/' . $storageBoxId . '/actions/disable_snapshot_plan');
                    if (!empty($response['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                    }

                    $verified = false;
                    for ($attempt = 0; $attempt < 12; $attempt++) {
                        if ($attempt > 0) {
                            sleep(2);
                        }

                        $checkResponse = $client->get('/storage_boxes/' . $storageBoxId);
                        $plan = $checkResponse['storage_box']['snapshot_plan'] ?? null;
                        if ($plan === null || $plan === [] || $plan === '') {
                            $verified = true;
                            break;
                        }
                    }

                    if (!$verified) {
                        throw new \RuntimeException('Cloud Storage did not confirm that automatic snapshots are disabled yet. Please try again in a few minutes.');
                    }

                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                    return [
                        'mode' => 'json',
                        'payload' => [
                            'status' => 'success',
                            'message' => 'Automatic snapshots disabled successfully. Please refresh the page.',
                            'auto_snapshot_enabled' => false,
                        ],
                    ];
                } catch (\Throwable $e) {
                    throw new \RuntimeException('We could not complete this request right now. Please refresh the page and try again.');
                }

            case 'list_storage_box_folders':
                $client = Common::getApiClient($params);
                $folders = hetznerstoragebox_fetchStorageBoxFoldersRecursive($client, $storageBoxId);
                return [
                    'mode' => 'json',
                    'payload' => ['status' => 'success', 'folders' => array_values($folders)],
                ];

            case 'create_storage_directory':
                $path = hetznerstoragebox_validateDirectoryPathForStorageAction((string) ($_POST['path'] ?? ''));
                $client = Common::getApiClient($params);
                hetznerstoragebox_ensureStorageDirectory($params, $storageBoxId, $path);
                $folders = hetznerstoragebox_waitForDirectoryPath($client, $storageBoxId, $path, 6);
                return [
                    'mode' => 'json',
                    'payload' => ['status' => 'success', 'message' => 'Directory created in Cloud Storage.', 'folders' => array_values($folders)],
                ];
            case 'rename_storage_directory':
            case 'delete_storage_directory':
                throw new \RuntimeException('Directory rename and delete are disabled in the client panel. Customers can only select existing directories or create new directories.');

            case 'create_subaccount':
                $client = Common::getApiClient($params);
                $box = hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                $subaccountsNow = hetznerstoragebox_fetchSubaccounts($client, $storageBoxId);
                $subaccountLimit = hetznerstoragebox_subaccountLimitFromBox($box);
                if ($subaccountLimit > 0 && count($subaccountsNow) >= $subaccountLimit) {
                    throw new \RuntimeException('You already exceed the subaccount limit. Please open a ticket for requesting more subaccount slots.');
                }

                $homeDir = hetznerstoragebox_validateDirectoryPathForStorageAction((string) ($_POST['home_directory'] ?? 'subaccount'));
                $accessSettings = hetznerstoragebox_subaccountAccessSettingsFromPost($_POST);
                $description = trim((string) ($_POST['comment'] ?? ($_POST['description'] ?? '')));
                $pass = trim((string) ($_POST['password'] ?? ''));

                if ($pass === '') {
                    throw new \RuntimeException('Please enter a password or generate a random one.');
                }

                try {
                    $directoryExists = false;
                    try {
                        $knownFolders = hetznerstoragebox_fetchStorageBoxFoldersRecursive($client, $storageBoxId);
                        $knownFoldersLower = array_map('strtolower', $knownFolders);
                        $directoryExists = in_array(strtolower($homeDir), $knownFoldersLower, true);
                    } catch (\Throwable $ignoredFolderLookup) {
                        $directoryExists = false;
                    }
                    if (!$directoryExists) {
                        hetznerstoragebox_ensureStorageDirectory($params, $storageBoxId, $homeDir);
                    }
                } catch (\Throwable $directoryException) {
                    throw new \RuntimeException('Could not create/sync the selected base directory in Cloud Storage: ' . $directoryException->getMessage());
                }

                $payload = [
                    'home_directory' => $homeDir,
                    'password' => $pass,
                    'description' => $description,
                    'access_settings' => $accessSettings,
                ];

                try {
                    $response = $client->post('/storage_boxes/' . $storageBoxId . '/subaccounts', $payload);
                    $createdSubaccount = (array) ($response['subaccount'] ?? []);
                    $newSubUsername = (string) (($createdSubaccount['username'] ?? '') ?: ($createdSubaccount['name'] ?? ''));

                    if (!empty($response['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                    } else {
                        sleep(2);
                    }

                    $subaccounts = hetznerstoragebox_fetchSubaccounts($client, $storageBoxId);
                    if ($newSubUsername === '' && !empty($subaccounts)) {
                        $latest = end($subaccounts);
                        $newSubUsername = (string) (($latest['username'] ?? '') ?: ($latest['name'] ?? ''));
                    }

                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);

                    return [
                        'mode' => 'json',
                        'payload' => [
                            'status' => 'success',
                            'message' => 'Subaccount created successfully.',
                            'new_username' => $newSubUsername,
                        ],
                    ];
                } catch (\Throwable $e) {
                    $apiMessage = $e->getMessage();
                    if (stripos($apiMessage, 'limit') !== false || stripos($apiMessage, 'maximum') !== false || stripos($apiMessage, 'subaccount') !== false && stripos($apiMessage, 'exceed') !== false) {
                        throw new \RuntimeException('You already exceed the subaccount limit. Please open a ticket for requesting more subaccount slots.');
                    }
                    throw new \RuntimeException('We could not create this subaccount right now. Please refresh the page and try again.');
                }

            case 'update_subaccount':
                $subUsername = trim((string) ($_POST['subaccount_username'] ?? ''));
                if ($subUsername === '') {
                    throw new \RuntimeException('Subaccount username is required.');
                }

                $client = Common::getApiClient($params);
                $homeDir = hetznerstoragebox_validateDirectoryPathForStorageAction((string) ($_POST['home_directory'] ?? 'subaccount'));
                $description = trim((string) ($_POST['comment'] ?? ($_POST['description'] ?? '')));
                $accessSettings = hetznerstoragebox_subaccountAccessSettingsFromPost($_POST);

                try {
                    $subaccount = hetznerstoragebox_findSubaccountByUsername($client, $storageBoxId, $subUsername);
                    $subId = hetznerstoragebox_subaccountIdentifier($subaccount, $subUsername);
                    $currentHomeDir = hetznerstoragebox_normalizeSubaccountHomeDirectory((string) (($subaccount['home_directory'] ?? $subaccount['homedirectory'] ?? $subaccount['directory'] ?? '')));

                    $updateResponse = $client->put('/storage_boxes/' . $storageBoxId . '/subaccounts/' . rawurlencode($subId), [
                        'description' => $description,
                    ]);

                    if (!empty($updateResponse['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $updateResponse['action'], $storageBoxId);
                    }

                    if ($homeDir !== '' && $homeDir !== $currentHomeDir) {
                        try {
                            $directoryExists = false;
                            try {
                                $knownFolders = hetznerstoragebox_fetchStorageBoxFoldersRecursive($client, $storageBoxId);
                                $knownFoldersLower = array_map('strtolower', $knownFolders);
                                $directoryExists = in_array(strtolower($homeDir), $knownFoldersLower, true);
                            } catch (\Throwable $ignoredFolderLookup) {
                                $directoryExists = false;
                            }
                            if (!$directoryExists) {
                                hetznerstoragebox_ensureStorageDirectory($params, $storageBoxId, $homeDir);
                            }
                        } catch (\Throwable $directoryException) {
                            throw new \RuntimeException('Could not create/sync the selected base directory in Cloud Storage: ' . $directoryException->getMessage());
                        }

                        $homeResponse = $client->post('/storage_boxes/' . $storageBoxId . '/subaccounts/' . rawurlencode($subId) . '/actions/change_home_directory', [
                            'home_directory' => $homeDir,
                        ]);
                        if (!empty($homeResponse['action'])) {
                            hetznerstoragebox_waitForAction($client, (array) $homeResponse['action'], $storageBoxId);
                        }
                    }

                    $accessResponse = $client->post('/storage_boxes/' . $storageBoxId . '/subaccounts/' . rawurlencode($subId) . '/actions/update_access_settings', $accessSettings);
                    if (!empty($accessResponse['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $accessResponse['action'], $storageBoxId);
                    }

                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                    return ['mode' => 'json', 'payload' => ['status' => 'success', 'message' => 'Subaccount settings updated.']];
                } catch (\Throwable $e) {
                    $updateMessage = $e->getMessage();
                    if (stripos($updateMessage, 'Could not create/sync') !== false || stripos($updateMessage, 'directory') !== false || stripos($updateMessage, 'Whitespace is not allowed') !== false || stripos($updateMessage, 'Storage Box username') !== false || stripos($updateMessage, 'Reset the Storage Box password') !== false) {
                        throw new \RuntimeException($updateMessage);
                    }
                    throw new \RuntimeException('We could not update this subaccount right now. Please refresh the page and try again.');
                }

            case 'delete_subaccount':
                $subUsername = trim((string) ($_POST['subaccount_username'] ?? ''));
                if ($subUsername === '') {
                    throw new \RuntimeException('Subaccount username is required.');
                }

                $client = Common::getApiClient($params);
                try {
                    $subaccount = hetznerstoragebox_findSubaccountByUsername($client, $storageBoxId, $subUsername);
                    $subId = hetznerstoragebox_subaccountIdentifier($subaccount, $subUsername);
                    $response = $client->delete('/storage_boxes/' . $storageBoxId . '/subaccounts/' . rawurlencode($subId));
                    if (!empty($response['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                    } else {
                        sleep(2);
                    }
                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                    return ['mode' => 'json', 'payload' => ['status' => 'success', 'message' => 'Subaccount permanently deleted.']];
                } catch (\Throwable $e) {
                    throw new \RuntimeException('We could not delete this subaccount right now. Please refresh the page and try again.');
                }

            case 'reset_subaccount_password':
                $subUsername = trim((string) ($_POST['subaccount_username'] ?? ''));
                if ($subUsername === '') {
                    throw new \RuntimeException('Subaccount username is required.');
                }

                $pass = trim((string) ($_POST['password'] ?? ''));
                if ($pass === '') {
                    $pass = Common::generateStrongPassword();
                }

                $client = Common::getApiClient($params);
                try {
                    $subaccount = hetznerstoragebox_findSubaccountByUsername($client, $storageBoxId, $subUsername);
                    $subId = hetznerstoragebox_subaccountIdentifier($subaccount, $subUsername);
                    $response = $client->post('/storage_boxes/' . $storageBoxId . '/subaccounts/' . rawurlencode($subId) . '/actions/reset_subaccount_password', [
                        'password' => $pass,
                    ]);

                    if (!empty($response['action'])) {
                        hetznerstoragebox_waitForAction($client, (array) $response['action'], $storageBoxId);
                    } else {
                        sleep(2);
                    }

                    hetznerstoragebox_syncStorageBox($params, $storageBoxId, false);
                    return ['mode' => 'json', 'payload' => ['status' => 'success', 'message' => 'Subaccount password securely updated.', 'new_password' => $pass]];
                } catch (\Throwable $e) {
                    throw new \RuntimeException('We could not reset this subaccount password right now. Please refresh the page and try again.');
                }

        }

        throw new \RuntimeException('Unknown client action.');
    } catch (\Throwable $exception) {
        return [
            'mode' => 'json',
            'payload' => ['status' => 'error', 'error' => hetznerstoragebox_clientFriendlyError($exception->getMessage())],
        ];
    }
}




function hetznerstoragebox_subaccountLimitFromBox(array $box)
{
    $type = (array) ($box['storage_box_type'] ?? []);
    foreach (['subaccounts_limit', 'max_subaccounts', 'subaccount_limit'] as $key) {
        $limit = (int) ($type[$key] ?? 0);
        if ($limit > 0) {
            return $limit;
        }
    }
    return 100;
}

function hetznerstoragebox_directoryPathsFromSubaccounts(array $subaccounts)
{
    $paths = [];
    foreach ($subaccounts as $subaccount) {
        $subaccount = (array) $subaccount;
        $path = hetznerstoragebox_normalizeSubaccountHomeDirectory((string) (($subaccount['home_directory'] ?? $subaccount['homedirectory'] ?? $subaccount['directory'] ?? '')));
        if ($path !== '' && !in_array($path, $paths, true)) {
            $paths[] = $path;
        }
    }
    sort($paths, SORT_NATURAL | SORT_FLAG_CASE);
    return $paths;
}

function hetznerstoragebox_fetchStorageBoxFoldersRecursive($client, $storageBoxId, $path = '', $depth = 0, array &$seen = [])
{
    $storageBoxId = (int) $storageBoxId;
    if ($storageBoxId <= 0) {
        return [];
    }

    $depth = (int) $depth;
    if ($depth > 20) {
        return [];
    }

    $parent = hetznerstoragebox_normalizeSubaccountHomeDirectory($path);
    if ($parent === 'subaccount' && trim((string) $path) === '') {
        $parent = '';
    }

    $query = [];
    if ($parent !== '') {
        $query['path'] = $parent;
    }

    $response = $client->get('/storage_boxes/' . $storageBoxId . '/folders', $query);
    $folders = (array) ($response['folders'] ?? []);
    $result = [];

    foreach ($folders as $folder) {
        $folder = hetznerstoragebox_normalizeSubaccountHomeDirectory((string) $folder);
        if ($folder === '') {
            continue;
        }

        $fullPath = $folder;
        if ($parent !== '' && stripos($folder, $parent . '/') !== 0 && strcasecmp($folder, $parent) !== 0) {
            $fullPath = $parent . '/' . $folder;
        }
        $fullPath = hetznerstoragebox_normalizeSubaccountHomeDirectory($fullPath);

        if ($fullPath === '' || isset($seen[strtolower($fullPath)])) {
            continue;
        }

        $seen[strtolower($fullPath)] = true;
        $result[] = $fullPath;

        try {
            $childPaths = hetznerstoragebox_fetchStorageBoxFoldersRecursive($client, $storageBoxId, $fullPath, $depth + 1, $seen);
            foreach ($childPaths as $childPath) {
                if (!in_array($childPath, $result, true)) {
                    $result[] = $childPath;
                }
            }
        } catch (\Throwable $e) {
            // Keep the folders already fetched. Some folders may be unavailable due to permissions or API timing.
        }
    }

    sort($result, SORT_NATURAL | SORT_FLAG_CASE);
    return $result;
}


function hetznerstoragebox_waitForDirectoryPath($client, $storageBoxId, $path, $attempts = 6)
{
    $target = strtolower(hetznerstoragebox_validateDirectoryPathForStorageAction($path));
    $folders = [];

    for ($attempt = 0; $attempt < max(1, (int) $attempts); $attempt++) {
        if ($attempt > 0) {
            sleep(1);
        }

        try {
            $folders = hetznerstoragebox_fetchStorageBoxFoldersRecursive($client, (int) $storageBoxId);
            $known = array_map(static function ($folder) {
                return strtolower(hetznerstoragebox_normalizeSubaccountHomeDirectory((string) $folder));
            }, $folders);
            if (in_array($target, $known, true)) {
                return $folders;
            }
        } catch (\Throwable $e) {
            // If the list endpoint is delayed, still return the last folder list after the retry loop.
        }
    }

    if (!in_array($path, $folders, true)) {
        $folders[] = $path;
        sort($folders, SORT_NATURAL | SORT_FLAG_CASE);
    }

    return $folders;
}

function hetznerstoragebox_validateDirectoryPathForStorageAction($path)
{
    $original = str_replace('\\', '/', (string) $path);
    if ($original !== trim($original)) {
        throw new \RuntimeException('Whitespace is not allowed at the beginning or end of a directory path.');
    }

    $trimmed = trim($original, '/');
    if ($trimmed === '') {
        throw new \RuntimeException('Directory path is required.');
    }

    $parts = explode('/', $trimmed);
    $clean = [];
    foreach ($parts as $part) {
        if ($part === '' || $part === '.' || $part === '..') {
            throw new \RuntimeException('Directory path contains an invalid folder name.');
        }
        if ($part !== trim($part)) {
            throw new \RuntimeException('Whitespace is not allowed at the beginning or end of a directory name.');
        }
        if (preg_match('/[\\\\]/', $part)) {
            throw new \RuntimeException('Directory names cannot contain backslashes.');
        }
        $clean[] = $part;
    }

    return implode('/', $clean);
}

function hetznerstoragebox_storageBoxWebDavCredentials(array $params, $storageBoxId)
{
    $serviceId = (int) ($params['serviceid'] ?? 0);
    $record = Common::getServiceRecord($serviceId);
    $username = trim((string) ($record->username ?? ($params['username'] ?? '')));
    $endpoint = trim((string) ($record->endpoint ?? ($params['domain'] ?? '')));
    $password = '';

    $hosting = Capsule::table('tblhosting')->where('id', $serviceId)->first(['password']);
    if ($hosting && !empty($hosting->password) && function_exists('decrypt')) {
        try {
            $password = (string) decrypt($hosting->password);
        } catch (\Throwable $e) {
            $password = '';
        }
    }

    if ($password === '' && !empty($params['password'])) {
        $password = (string) $params['password'];
    }

    if (($username === '' || $endpoint === '') && (int) $storageBoxId > 0) {
        try {
            $box = hetznerstoragebox_syncStorageBox($params, (int) $storageBoxId, false);
            $username = $username ?: trim((string) ($box['username'] ?? ''));
            $endpoint = $endpoint ?: trim((string) ($box['server'] ?? ''));
        } catch (\Throwable $e) {}
    }

    if ($username === '' || $endpoint === '' || $password === '') {
        throw new \RuntimeException('Live directory changes require the Storage Box username, endpoint, and password to be stored for this service. Reset the Storage Box password first, then try again.');
    }

    return [$username, $endpoint, $password];
}

function hetznerstoragebox_webdavDirectoryUrl($endpoint, $path)
{
    $segments = array_map('rawurlencode', explode('/', hetznerstoragebox_validateDirectoryPathForStorageAction($path)));
    return 'https://' . trim((string) $endpoint, '/') . '/' . implode('/', $segments) . '/';
}

function hetznerstoragebox_webdavRequest(array $params, $storageBoxId, $method, $path, array $headers = [])
{
    [$username, $endpoint, $password] = hetznerstoragebox_storageBoxWebDavCredentials($params, $storageBoxId);
    $url = hetznerstoragebox_webdavDirectoryUrl($endpoint, $path);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper((string) $method));
    curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($ch, CURLOPT_TIMEOUT, 45);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    $raw = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($raw === false || $curlError !== '') {
        throw new \RuntimeException('Network error while changing the directory: ' . ($curlError ?: 'Unknown cURL error'));
    }

    return $httpCode;
}

function hetznerstoragebox_ensureStorageDirectory(array $params, $storageBoxId, $path)
{
    $path = hetznerstoragebox_validateDirectoryPathForStorageAction($path);
    $parts = explode('/', $path);
    $current = [];

    foreach ($parts as $part) {
        $current[] = $part;
        $currentPath = implode('/', $current);
        $httpCode = hetznerstoragebox_webdavRequest($params, $storageBoxId, 'MKCOL', $currentPath);
        if (in_array($httpCode, [200, 201, 204, 405], true)) {
            continue;
        }
        throw new \RuntimeException('Cloud Storage rejected directory creation for /' . $currentPath . '/ (HTTP ' . $httpCode . ').');
    }

    return true;
}

function hetznerstoragebox_renameStorageDirectory(array $params, $storageBoxId, $oldPath, $newPath)
{
    [$username, $endpoint, $password] = hetznerstoragebox_storageBoxWebDavCredentials($params, $storageBoxId);
    $sourceUrl = hetznerstoragebox_webdavDirectoryUrl($endpoint, $oldPath);
    $destinationUrl = hetznerstoragebox_webdavDirectoryUrl($endpoint, $newPath);

    $ch = curl_init($sourceUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'MOVE');
    curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Destination: ' . $destinationUrl, 'Overwrite: F']);
    $raw = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($raw === false || $curlError !== '') {
        throw new \RuntimeException('Network error while renaming the directory: ' . ($curlError ?: 'Unknown cURL error'));
    }
    if (!in_array($httpCode, [200, 201, 204], true)) {
        throw new \RuntimeException('Cloud Storage rejected the directory rename (HTTP ' . $httpCode . ').');
    }

    return true;
}

function hetznerstoragebox_deleteStorageDirectory(array $params, $storageBoxId, $path)
{
    $httpCode = hetznerstoragebox_webdavRequest($params, $storageBoxId, 'DELETE', $path);
    if (!in_array($httpCode, [200, 202, 204, 404], true)) {
        throw new \RuntimeException('Cloud Storage rejected the directory deletion (HTTP ' . $httpCode . ').');
    }
    return true;
}

function hetznerstoragebox_normalizeSubaccountHomeDirectory($path)
{
    $path = str_replace('\\', '/', trim((string) $path));
    $parts = array_values(array_filter(array_map('trim', explode('/', $path)), static function ($part) {
        return $part !== '' && $part !== '.';
    }));

    if (empty($parts)) {
        return 'subaccount';
    }

    return implode('/', $parts);
}

function hetznerstoragebox_subaccountAccessSettingsFromPost(array $source)
{
    return [
        'reachable_externally' => Common::boolValue($source['external_reachability'] ?? $source['reachable_externally'] ?? false),
        'readonly' => Common::boolValue($source['readonly'] ?? $source['read_only'] ?? false),
        'samba_enabled' => Common::boolValue($source['samba'] ?? $source['samba_enabled'] ?? false),
        'ssh_enabled' => Common::boolValue($source['ssh'] ?? $source['ssh_enabled'] ?? false),
        'webdav_enabled' => Common::boolValue($source['webdav'] ?? $source['webdav_enabled'] ?? false),
    ];
}

function hetznerstoragebox_fetchSubaccounts($client, $storageBoxId)
{
    $response = $client->get('/storage_boxes/' . (int) $storageBoxId . '/subaccounts');
    return (array) ($response['subaccounts'] ?? []);
}

function hetznerstoragebox_findSubaccountByUsername($client, $storageBoxId, $username)
{
    $username = trim((string) $username);
    foreach (hetznerstoragebox_fetchSubaccounts($client, $storageBoxId) as $subaccount) {
        $subaccount = (array) $subaccount;
        if ((string) ($subaccount['username'] ?? '') === $username || (string) ($subaccount['name'] ?? '') === $username) {
            return $subaccount;
        }
    }

    throw new \RuntimeException('Subaccount was not found. Please refresh the page and try again.');
}

function hetznerstoragebox_subaccountIdentifier(array $subaccount, $fallbackUsername)
{
    $id = (int) ($subaccount['id'] ?? 0);
    if ($id > 0) {
        return (string) $id;
    }

    $name = trim((string) ($subaccount['name'] ?? ''));
    if ($name !== '') {
        return $name;
    }

    return trim((string) $fallbackUsername);
}

function hetznerstoragebox_clientFriendlyError($message)
{
    $message = trim((string) $message);
    $fallback = 'We could not complete this request right now. Please refresh the page and try again.';

    if ($message === '') {
        return $fallback;
    }

    if (
        stripos($message, 'subaccount limit') !== false ||
        stripos($message, 'open a ticket') !== false ||
        stripos($message, 'directory') !== false ||
        stripos($message, 'Whitespace is not allowed') !== false ||
        stripos($message, 'Storage Box username') !== false ||
        stripos($message, 'Reset the Storage Box password') !== false
    ) {
        return $message;
    }

    if (
        stripos($message, 'Storage Provider API Error') !== false ||
        stripos($message, 'storage provider') !== false ||
        stripos($message, 'hetzner') !== false ||
        stripos($message, 'hcloud') !== false ||
        stripos($message, 'api error') !== false ||
        stripos($message, 'curl') !== false ||
        stripos($message, 'json') !== false ||
        preg_match('/\b(?:401|403|404|409|422|429|500|502|503|504)\b/', $message)
    ) {
        return $fallback;
    }

    return $message;
}

/**
 * Ensures emails send securely by bypassing standard bugs using native WHMCS core
 */
function hetznerstoragebox_SendCustomEmail($serviceId, $templateName, array $customVars = [])
{
    $admin = Capsule::table('tbladmins')->where('disabled', 0)->orderBy('id', 'asc')->first();
    $adminUser = $admin ? $admin->username : null;

    $postData = [
        'messagename' => $templateName,
        'id' => $serviceId,
        'customtype' => 'product',
    ];

    if (!empty($customVars)) {
        $postData['customvars'] = base64_encode(serialize($customVars)); 
    }

    if (function_exists('localAPI')) {
        $response = localAPI('SendEmail', $postData, $adminUser);
        if (($response['result'] ?? '') !== 'success') {
            \logActivity("RapidNetHosting Notice: Failed to send template '{$templateName}'. Reason: " . ($response['message'] ?? 'Unknown'));
        }
        return $response;
    }
    return false;
}

function hetznerstoragebox_resolveProductConfig(array $params)
{
    return Common::loadProductConfig((int) $params['pid'], $params);
}

function hetznerstoragebox_resolveStorageBoxId($serviceId)
{
    $record = Common::getServiceRecord((int) $serviceId);
    if ($record && !empty($record->storage_box_id)) {
        return (int) $record->storage_box_id;
    }

    return 0;
}

function hetznerstoragebox_waitForAction($client, array $action, $storageBoxId = 0)
{
    $actionId = (int) ($action['id'] ?? 0);
    if ($actionId <= 0) {
        return $action;
    }

    try {
        return $client->waitForAction('/actions/' . $actionId);
    } catch (\Throwable $exception) {
        if ($storageBoxId > 0) {
            return $client->waitForAction('/storage_boxes/' . (int) $storageBoxId . '/actions/' . $actionId);
        }

        throw $exception;
    }
}

function hetznerstoragebox_syncStorageBox(array $params, $storageBoxId, $captureMetric = true)
{
    return Common::syncStorageBox($params, (int) $params['serviceid'], (int) $storageBoxId, (bool) $captureMetric);
}

function hetznerstoragebox_lastKnownBox($record)
{
    if (!$record) {
        return [];
    }

    $meta = Common::jsonDecodeArray($record->meta_json);
    return (array) ($meta['box'] ?? []);
}

function hetznerstoragebox_clientToken($serviceId)
{
    if (!isset($_SESSION['htsb_tokens']) || !is_array($_SESSION['htsb_tokens'])) {
        $_SESSION['htsb_tokens'] = [];
    }

    if (empty($_SESSION['htsb_tokens'][$serviceId])) {
        $_SESSION['htsb_tokens'][$serviceId] = bin2hex(random_bytes(24));
    }

    return (string) $_SESSION['htsb_tokens'][$serviceId];
}

function hetznerstoragebox_verifyClientToken($serviceId, $token)
{
    $expected = hetznerstoragebox_clientToken($serviceId);
    return is_string($token) && $token !== '' && hash_equals($expected, $token);
}


function hetznerstoragebox_snapshotMaxAmountForType($storageBoxType, array $type = [])
{
    $apiLimit = (int) ($type['automatic_snapshot_limit'] ?? ($type['snapshot_limit'] ?? 0));
    if ($apiLimit > 0) {
        return $apiLimit;
    }

    $normalized = strtolower(trim((string) $storageBoxType));
    $limits = [
        'bx11' => 10,
        'bx21' => 20,
        'bx31' => 30,
        'bx41' => 40,
    ];

    if (isset($limits[$normalized])) {
        return $limits[$normalized];
    }

    if (preg_match('/\bbx([1-4])1\b/i', $normalized, $matches)) {
        return ((int) $matches[1]) * 10;
    }

    return 10;
}

function hetznerstoragebox_autoSnapshotFrequencyFromPlan(array $plan)
{
    if (array_key_exists('day_of_month', $plan) && $plan['day_of_month'] !== null && $plan['day_of_month'] !== '') {
        return 'monthly';
    }

    if (array_key_exists('day_of_week', $plan) && $plan['day_of_week'] !== null && $plan['day_of_week'] !== '') {
        return 'weekly';
    }

    return 'daily';
}

function hetznerstoragebox_suggestManualSnapshotDescription(array $box, array $snapshots)
{
    $boxName = trim((string) ($box['name'] ?? ''));
    if ($boxName === '') {
        $boxName = trim((string) ($box['username'] ?? 'storage-box'));
    }

    $base = 'snapshot-' . preg_replace('/[^A-Za-z0-9._-]+/', '-', $boxName);
    $used = [];

    foreach ($snapshots as $snapshot) {
        $description = trim((string) (($snapshot['description'] ?? '') ?: ($snapshot['name'] ?? '')));
        if (preg_match('/^' . preg_quote($base, '/') . '-(\d+)$/', $description, $matches)) {
            $used[(int) $matches[1]] = true;
        }
    }

    $next = 1;
    while (isset($used[$next])) {
        $next++;
    }

    return $base . '-' . $next;
}

function hetznerstoragebox_templateState($serviceId, $record, array $box, array $config)
{
    $meta = $record ? Common::jsonDecodeArray($record->meta_json) : [];
    $provisioning = (array) ($meta['provisioning'] ?? []);
    $suspension = (array) ($meta['suspension'] ?? []);
    $stats = (array) ($box['stats'] ?? []);
    $type = (array) ($box['storage_box_type'] ?? []);
    $quotaBytes = (int) ($type['size'] ?? 0);
    $usedBytes = (int) ($stats['size'] ?? 0);
    $dataBytes = (int) ($stats['size_data'] ?? 0);
    $snapshotBytes = (int) ($stats['size_snapshots'] ?? 0);
    $usagePercent = $quotaBytes > 0 ? min(100, round(($usedBytes / $quotaBytes) * 100, 2)) : 0;
    $labels = Common::filterVisibleLabels((array) ($box['labels'] ?? []));
    $endpoint = (string) ($box['server'] ?? ($record->endpoint ?? ''));
    $username = (string) ($box['username'] ?? ($record->username ?? ''));
    $metricRows = [];
    $serverStatus = !empty($suspension['active']) ? 'hold' : (string) ($box['status'] ?? ($record->status ?? 'unknown'));

    foreach (Common::recentMetrics($serviceId, 14) as $metric) {
        $metricRows[] = [
            'captured_at' => (string) $metric->captured_at,
            'size' => Common::humanBytes((int) $metric->size_bytes),
            'size_data' => Common::humanBytes((int) $metric->size_data_bytes),
            'size_snapshots' => Common::humanBytes((int) $metric->size_snapshots_bytes),
        ];
    }

    return [
        'box' => $box,
        'accessChoice' => (string) ($provisioning['access_choice'] ?? 'password'),
        'labelsText' => Common::formatLabels((array) ($box['labels'] ?? [])),
        'visibleLabels' => $labels,
        'recentEvents' => Common::recentEvents($serviceId, 12),
        'recentMetrics' => $metricRows,
        'usagePercent' => $usagePercent,
        'quotaDisplay' => Common::humanBytes($quotaBytes),
        'usedDisplay' => Common::humanBytes($usedBytes),
        'dataDisplay' => Common::humanBytes($dataBytes),
        'snapshotDisplay' => Common::humanBytes($snapshotBytes),
        'snapshotBaseName' => 'snapshot-' . preg_replace('/[^A-Za-z0-9._-]+/', '-', trim((string) (($box['name'] ?? '') ?: ($username ?: 'storage-box')))),
        'snapshotMaxAmount' => hetznerstoragebox_snapshotMaxAmountForType((string) (($type['name'] ?? '') ?: ($record->box_type_name ?? ($config['default_storage_box_type'] ?? 'bx11'))), $type),
        'autoSnapshotEnabled' => !empty($box['snapshot_plan']) && is_array($box['snapshot_plan']),
        'autoSnapshotFrequency' => hetznerstoragebox_autoSnapshotFrequencyFromPlan((array) ($box['snapshot_plan'] ?? [])),
        'autoSnapshotMaxAmount' => min(hetznerstoragebox_snapshotMaxAmountForType((string) (($type['name'] ?? '') ?: ($record->box_type_name ?? ($config['default_storage_box_type'] ?? 'bx11'))), $type), max(1, (int) (($box['snapshot_plan']['max_snapshots'] ?? 0) ?: hetznerstoragebox_snapshotMaxAmountForType((string) (($type['name'] ?? '') ?: ($record->box_type_name ?? ($config['default_storage_box_type'] ?? 'bx11'))), $type)))),
        'autoSnapshotHour' => sprintf('%02d', max(0, min(23, (int) (($box['snapshot_plan']['hour'] ?? 0))))),
        'autoSnapshotMinute' => sprintf('%02d', max(0, min(59, (int) (($box['snapshot_plan']['minute'] ?? 0))))),
        'autoSnapshotDayOfWeek' => max(1, min(7, (int) (($box['snapshot_plan']['day_of_week'] ?? 1) ?: 1))),
        'autoSnapshotDayOfMonth' => max(1, min(31, (int) (($box['snapshot_plan']['day_of_month'] ?? 1) ?: 1))),
        'lastSynced' => (string) ($record->last_synced ?? ''),
        'serverStatus' => $serverStatus,
        'storageUsername' => $username,
        'storageEndpoint' => $endpoint,
        'storageType' => (string) (($type['name'] ?? '') ?: ($record->box_type_name ?? '')),
        'storageLocation' => (string) (($box['location']['name'] ?? '') ?: ($record->location_name ?? '')),
        'accessSettings' => [
            'reachable_externally' => Common::boolValue($box['access_settings']['reachable_externally'] ?? false),
            'ssh_enabled' => Common::boolValue($box['access_settings']['ssh_enabled'] ?? false),
            'samba_enabled' => Common::boolValue($box['access_settings']['samba_enabled'] ?? false),
            'webdav_enabled' => Common::boolValue($box['access_settings']['webdav_enabled'] ?? false),
            'zfs_enabled' => Common::boolValue($box['access_settings']['zfs_enabled'] ?? false),
        ],
        'connectionHost' => $endpoint,
        'sftpUri' => ($username !== '' && $endpoint !== '') ? ('sftp://' . $username . '@' . $endpoint) : '',
        'webdavUri' => $endpoint !== '' ? ('https://' . $endpoint) : '',
        'smbTarget' => $endpoint !== '' ? ('\\\\' . str_replace('.', '\\', $endpoint)) : '',
    ];
}

function hetznerstoragebox_lifecycleVars(array $params, array $box, array $extra = [])
{
    $labels = Common::filterVisibleLabels((array) ($box['labels'] ?? []));
    $type = (array) ($box['storage_box_type'] ?? []);
    $location = (array) ($box['location'] ?? []);
    $access = (array) ($box['access_settings'] ?? []);

    $vars = [
        'storage_box_id' => (string) ($box['id'] ?? ''),
        'storage_box_name' => (string) ($box['name'] ?? ''),
        'storage_box_username' => (string) ($box['username'] ?? ''),
        'storage_box_endpoint' => (string) ($box['server'] ?? ''),
        'storage_box_type' => (string) ($type['name'] ?? ''),
        'storage_box_location' => (string) ($location['name'] ?? ''),
        'storage_box_status' => (string) ($box['status'] ?? ''),
        'storage_box_labels' => Common::formatLabels($labels, []),
        'storage_box_labels_visible' => Common::formatLabels($labels, []),
        'storage_box_used' => Common::humanBytes((int) ($box['stats']['size'] ?? 0)),
        'storage_box_quota' => Common::humanBytes((int) ($type['size'] ?? 0)),
        'storage_box_access_reachable' => Common::boolValue($access['reachable_externally'] ?? false) ? 'yes' : 'no',
        'storage_box_access_ssh' => Common::boolValue($access['ssh_enabled'] ?? false) ? 'yes' : 'no',
        'storage_box_access_smb' => Common::boolValue($access['samba_enabled'] ?? false) ? 'yes' : 'no',
        'storage_box_access_webdav' => Common::boolValue($access['webdav_enabled'] ?? false) ? 'yes' : 'no',
        'storage_box_access_zfs' => Common::boolValue($access['zfs_enabled'] ?? false) ? 'yes' : 'no',
        'whmcs_service_id' => (string) (int) ($params['serviceid'] ?? 0),
    ];

    return array_merge($vars, $extra);
}
